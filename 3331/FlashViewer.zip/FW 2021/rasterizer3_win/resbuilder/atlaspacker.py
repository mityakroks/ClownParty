#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
sys.dont_write_bytecode = True  # noqa: E402

import os
import shutil
import argparse
import re
import fnmatch
import glob
from lxml import etree
import json  # для hash(json)
import traceback
import logging

import collections
from collections import OrderedDict

import pyscript
from pyscript import GX, Packer, Image, Compress, xml

from rescache import ResourceCache

import threading
import multiprocessing

if sys.version_info[0] >= 3:
    import queue as Queue
    unicode = str  # костыль, т.к. в py3 unicode превратился в str
else:
    import Queue

# ----------------------------------------------------------------------
# Скрипт упаковывает ресурсы в атласы и сжимает текстуры.
# ----------------------------------------------------------------------


# Вспомогательная функция для чтения булевых флагов из xml
def bool_attr(v, strict=True):
    if v is None:
        return v
    if type(v) == bool:
        return v
    if type(v) == str:
        vv = v.strip().lower()
        if vv == 'true' or vv == '1':
            return True
        if vv == 'false' or vv == '0':
            return False
    if strict:
        raise Exception("Bool value expected: '%r'" % (v))
    else:
        return v


# Проверка на соответствие шаблону
def wildcard_match(pat, s):
    if pat.startswith('^'):
        return re.match(r"\A(" + pat[1:] + r")\Z", s)
    # else:
    return fnmatch.fnmatch(s, pat)


# Вспомогательная функция для получения настройки exact (она же pma, blendadd)
def get_exact_setting(settings, default_v=False):
    for key in ('exact', 'pma', 'blendAdd'):
        v = settings.get(key)
        if v is not None:
            return bool_attr(v)
    return default_v


# Вспомогательная функция для чтения xml
def xml_read(filename, root_path=None):
    if root_path is None:
        root_path = ""
    doc = etree.parse(normpath(os.path.join(root_path, filename)), parser=etree.XMLParser(
        remove_comments=True, remove_blank_text=True))
    doc.docinfo.URL = normpath(filename)  # Путь относительно root_path
    return doc


# Возвращает имя файла и номер строки для lxml ноды. Для сообщений об ошибках.
def lxml_cur_pos(node):
    if node is None:
        return ""
    return str(node.base) + ":" + str(node.sourceline)


def FileNameWithoutExt(path):
    (res, ext) = os.path.splitext(path)
    return res


# Приводим путь к фиксированному формату с прямыми слешами
def normpath(path):
    if path is None:
        return path
    return os.path.normpath(path).replace('\\', '/')


def utf8_encode(path):
    if sys.version_info[0] < 3:
        if isinstance(path, unicode):
            path = path.encode('utf-8')
    return path


# Вспомогательная функция для форматирования логов для TeamCity
def tc_escaped(msg):
    res = msg
    res = res.replace('|', '||')
    res = res.replace('[', '|[')
    res = res.replace(']', '|]')
    res = res.replace("'", "|'")
    res = res.replace('\n', '|n')
    return res


# Функция для печати объектов в строку. Должна работать одинаково везде.
# json.dumps(v, sort_keys=True) работает по-разному в python2 и python3, так что делаем всё вручную
def tostr(v):
    if isinstance(v, str):
        return '"%s"' % v
    elif isinstance(v, unicode):
        return '"%s"' % v.encode('utf-8')
    elif isinstance(v, float):
        return "%g" % v
    elif isinstance(v, int):
        return "%s" % v
    elif v is None:
        return "%s" % v
    elif isinstance(v, list) or isinstance(v, tuple) or isinstance(v, set):
        return "[" + str.join(", ", [tostr(x) for x in v]) + "]"
    elif isinstance(v, dict):
        return "{" + str.join(", ", [tostr(x) + ":" + tostr(v[x]) for x in sorted(v.keys())]) + "}"
    elif '__dict__' in dir(v):  # объекты (в том числе из C++)
        v = {x: getattr(v, x) for x in dir(v) if not x.startswith("__") and not callable(getattr(v, x))}
        return "{" + str.join(", ", [tostr(x) + ":" + tostr(v[x]) for x in sorted(v.keys())]) + "}"
    else:
        raise Exception("tostr: unexpected value: %r (%s)" % (v, type(v)))

# ----------------------------------------------------------------------


# Вспомогательный класс для многопоточной работы
class ThreadPool:
    class Worker(threading.Thread):
        def __init__(self, queue, thread_local, n):
            threading.Thread.__init__(self)
            self.queue = queue  # Берём задачи из очереди и выполняем
            self.thread_local = thread_local
            self.index_n = n
            self.daemon = True  # прибивать при завершении основного треда
            self.start()

        def run(self):
            self.thread_local.worker = self
            while True:
                func, args = self.queue.get()
                try:
                    func(*args)
                finally:
                    self.queue.task_done()

    def __init__(self, num_threads=None):
        if num_threads is None:
            num_threads = multiprocessing.cpu_count()
        # ограничиваем кол-во тредов, т.к. может быть мало памяти
        if pyscript.Compress.HasHyperThreading():
            num_threads = max(1, num_threads // 2)
        self.queue = Queue.Queue(num_threads * 2)  # Немного ограничиваем очередь
        self.thread_local = threading.local()
        # launch threads
        self.workers = []
        for n in range(num_threads):
            worker = ThreadPool.Worker(self.queue, self.thread_local, n)
            self.workers.append(worker)

    def add_task(self, func, args=()):
        self.queue.put((func, args))

    def join(self):
        self.queue.join()


# Класс-заглушка
class Dummy():
    def __init__(self):
        pass

    # Dummy scope manager for cache_lock
    def __enter__(self):
        pass

    def __exit__(self, exc_type, exc_val, tb):
        if exc_val and exc_type != SystemExit:
            raise

# ----------------------------------------------------------------------


# Класс для фильтрации логов
class LogFilter:
    def __init__(self, is_teamcity=False, only_level=None):
        self.is_teamcity = is_teamcity
        self.only_level = only_level

    def filter(self, record):
        # Фильтр по log_level (для warning log)
        if self.only_level is not None and record.levelno != self.only_level:
            return 0  # не пропускаем

        if 'blockClosed' in record.__dict__:
            if not self.is_teamcity:
                # По умолчанию не печатаем закрытие блока. Печатаем только для TeamCity
                #  или если указано явно (например, для очень больших блоков).
                if not record.__dict__.get('printClose'):
                    return 0  # не пропускаем

        return 1  # passed filter


# Класс для форматирования логов
class LogFormatter(logging.Formatter):
    def __init__(self, is_teamcity=False):
        logging.Formatter.__init__(self)
        self.is_teamcity = is_teamcity

    def format(self, record):
        message = logging.Formatter.format(self, record)
        if record.levelno >= logging.ERROR:  # ERROR or CRITICAL(unused)
            if self.is_teamcity:
                message = "##teamcity[message text='%s' status='ERROR']" % tc_escaped(message)
            else:
                message = ("[%s] " % record.levelname) + message  # prepend with "[ERROR] "
        elif record.levelno == logging.WARNING:
            if self.is_teamcity:
                message = "##teamcity[message text='%s' status='WARNING']" % tc_escaped(message)
            else:
                message = ("[%s] " % record.levelname) + message  # prepend with "[WARNING] "

        if 'blockOpened' in record.__dict__:  # passed via extra={'blockOpened': True}
            if self.is_teamcity:
                message = "##teamcity[blockOpened name='%s']" % tc_escaped(message)
            else:
                message = ">> " + message  # block opened
        elif 'blockClosed' in record.__dict__:
            if self.is_teamcity:
                message = "##teamcity[blockClosed name='%s']" % tc_escaped(message)
            else:
                # По умолчанию не печатаем закрытие блока. Печатаем только для TeamCity (выше)
                #  или если указано явно (например, для очень больших блоков).
                assert record.__dict__.get('printClose')  # Это должен обеспечивать LogFilter!
                message = "<< " + message

        if 'padding' in record.__dict__:
            pad_prefix = ("  " * record.__dict__.get('padding'))
            message = str.join("\n", [pad_prefix + line for line in message.splitlines()])

        return message


class StreamToLogger(object):
    """
    Класс для замены stdout и stderr для перехвата вывода в logger
    """
    def __init__(self, parent, log_level=logging.INFO):
        self.parent = parent
        self.log_level = log_level
        self.linebuf = ''

    def write(self, buf):
        #~ sys.__stdout__.write("!!! %r\n" % buf)  # для отладки
        buf = self.linebuf + buf.rstrip()
        for line in buf.splitlines(True):
            self.parent.log(self.log_level, line.rstrip())
        self.linebuf = ''
    
    def flush(self):
        if self.linebuf != '':
            self.write(self.linebuf)
        self.linebuf = ''

# Инициализируем логгер в соответствии с настройками.
# Эту функцию можно вызывать повторно.
# (Вынес в глобальную функцию, чтобы использовать с другими классами - например, swlpacker.)
def setupLogger(logger, settings):
    is_teamcity = settings.get('is_teamcity', False)

    # Логгируем в stdout
    if not hasattr(logger, 'log_stdout_handler'):
        logger.log_stdout_handler = logging.StreamHandler(sys.__stdout__)
        logger.log_stdout_handler.addFilter(LogFilter(is_teamcity=is_teamcity))
        logger.log_stdout_handler.setFormatter(LogFormatter(is_teamcity=is_teamcity))
        logger.addHandler(logger.log_stdout_handler)
    if hasattr(logger, 'log_stdout_handler'):
        logger.log_stdout_handler.setLevel(settings.get('log_level_stdout', logging.INFO))

    # Логгируем в файл
    log_abs_path = settings.get('log_abs_path')
    if log_abs_path and not hasattr(logger, 'log_file_handler'):
        if settings.get('log_backup') and os.path.exists(log_abs_path):
            shutil.move(log_abs_path, log_abs_path + ".bak")
        logger.log_file_handler = logging.FileHandler(log_abs_path, 'w', 'utf-8')
        logger.log_file_handler.addFilter(LogFilter())
        logger.log_file_handler.setFormatter(LogFormatter(is_teamcity=is_teamcity))
        logger.addHandler(logger.log_file_handler)
    if hasattr(logger, 'log_file_handler'):
        logger.log_file_handler.setLevel(settings.get('log_level_log', logging.DEBUG))

    # Дополнительный отдельный лог для ошибок (может быть полезно на teamcity)
    log_errors_abs_path = settings.get('log_errors_abs_path')
    if log_errors_abs_path and not hasattr(logger, 'log_err_handler'):
        logger.log_err_handler = logging.FileHandler(log_errors_abs_path, 'w', 'utf-8')
        logger.log_err_handler.addFilter(LogFilter())
        logger.log_err_handler.setFormatter(LogFormatter(is_teamcity=is_teamcity))
        logger.addHandler(logger.log_err_handler)
        logger.log_err_handler.setLevel(logging.ERROR)

    # Дополнительный отдельный лог для предупреждений (может быть полезно на teamcity)
    log_warnings_abs_path = settings.get('log_warnings_abs_path')
    if log_warnings_abs_path and not hasattr(logger, 'log_warn_handler'):
        logger.log_warn_handler = logging.FileHandler(log_warnings_abs_path, 'w', 'utf-8')
        logger.log_warn_handler.addFilter(LogFilter(only_level=logging.WARNING))
        logger.log_warn_handler.setFormatter(LogFormatter(is_teamcity=is_teamcity))
        logger.addHandler(logger.log_warn_handler)
        logger.log_warn_handler.setLevel(logging.WARNING)

# Аналог logging.LogRecord.getMessage()
def logGetMessage(msg, *args):
    message = str(msg)
    if args and len(args) == 1 and isinstance(args[0], collections.abc.Mapping):
        args = args[0]
    if args:
        message = message % args
    return message


# Добавляем свои уровни логгирования
# WARNING == 30
LOG_PROGRESS = 26  # Шаги работы скрипта
LOG_SKIP = 24  # Пропускаемые шаги
LOG_WRITE = 22  # Запись файлов на диск
# INFO == 20
# DEBUG == 10
LOG_VERBOSE = 5  # На этом уровне выводим, например, абсолютные пути (их не должно быть в тестах).

# ----------------------------------------------------------------------


# Основной класс
class AtlasPacker:
    def __init__(self, repo_abs_path=".", platform=None):
        # Все пути указываются относительно репозитория игры. Исключение составляют
        # repo_abs_path, dst_abs_path, cache_path, log_abs_path - они указываются
        # абсолютным путём, т.к. не привязаны к репозиторию.
        self.repo_abs_path = normpath(repo_abs_path)  # путь к корневой директории игры
        self.dst_abs_path = self.repo_abs_path  # куда записывать генерируемые файлы (по умолчанию прямо в репозиторий = repo_abs_path)
        self.base_path = "base"  # Основной каталог base (путь относительно repo_abs_path)
        self.main_base = None  # Костыль для эффектов из другого base
        self.platform = (platform or "")  # ios, android, win, mac, ...
        # (Параметр platform по умолчанию =None для того, чтобы удобно было передавать в него args.platform как есть.)

        # каталог, в который сохраняются атласы (относительно repo_abs_path).
        self.atlas_output_dir = None  # default: "atlases"

        #  Параметры чтения ресурсов
        # Игнорируемые ресурсы (можно использовать маски с *)
        self.ignore_resource_path = []
        # Не читать атласы из ресурсных xml.
        self.ignore_sheet_resources = True
        # Не читать ModelAnimations из ресурсных xml (вдруг они будут паковаться как-то по-другому)
        self.ignore_model_animation_resources = False

        # Опции
        self.only_package = None  # Собираем только один пакет.
        self.only_group = None  # Собираем только указанные группы.
        self.only_atlas = None  # Собрать один атлас (по id)
        self.dry_run = False  # Ничего не записывать на диск (для тестирования)
        self.dry_run_fast = False  # Не записывать на диск и вообще ничего не делать (только проверка настроек)
        # Только восстанавливать из кэша, пропускать остальное (быстрый режим для скачанных с сервера атласов)
        self.copy_only = False

        # Кэш (см. rescache.py)
        self.cache = None  # rescache.ResourceCache
        self.cache_path = None  # (абсолютный путь)
        self.cache_out_path = None  # (абсолютный путь)
        self.cache_hashes_file = 'hashes.xml'  # (относительно cache_path и cache_out_path)
        self.cache_deps_file = None  # (абсолютный путь)
        self.cache_thumb = None  # костыль для замены cache.thumb (используется при тестировании)
        self.cache_clean = None  # Очистить кэш в конце Run (применять при inplace кэше при полной пересборке)

        self.global_hash_salt = None   # Можно задать, чтобы изменить хэш и вызвать пересборку (trigger)
        self.atlas_hash_salt = None    # ^
        self.compress_hash_salt = None  # ^
        self.mask_hash_salt = None     # ^

        #  Настройки регистрации атласов в AtlasResources.xml
        # В этом файле регистрируются собранные атласы. None - не регистрировать вообще.
        self.atlas_resources_xml = None  # default: base_path/AtlasResources.xml
        self.atlas_resources_xml_rel_package = True  # В каждом пакете свой AtlasResources.xml
        self.atlas_register_id = True  # Записывать атрибут id в описание атласа в AtlasResources.xml
        self.atlas_register_group = True  # Записывать атрибут group в описание атласов в AtlasResources.xml
        # Записывать информацию о сжатии в описание атласа.
        # (Это не очень нужно, т.к. эта информация всё равно берётся из AtlasSettings.xml.)
        self.atlas_register_compress = False

        #  Настройки упаковки атласов
        # Сжимать изображения атласа сразу после упаковки (позволяет не хранить png)
        self.compress_atlas_immediately = True
        # Требовать степень двойки для кубических атласов (ограничение для старого железа)
        self.require_cube_pot = True

        # Настройки сжатия текстур
        self.allow_auto_etc_opaque = True
        self.compress_remove_atlas_png = True  # Удалять png собранных атласов после сжатия
        # Удалять png из dst_abs_path после сжатия (осторожнее, если dst_abs_path == repo_abs_path!)
        self.compress_remove_dst_png = False

        # Настройки масок текстур
        self.default_mask_format = 'msk2'
        self.default_mask_limit = 60

        # Логгирование и ошибки
        # Очень рекомендуется всегда писать в лог файл!
        self.log_abs_path = None  # Имя файла логов
        self.log_backup = True  # переименовывать старый лог в .bak
        # Дополнительный отдельный лог для ошибок (может быть полезно на teamcity)
        self.log_errors_abs_path = None
        # Дополнительный отдельный лог для предупреждений (может быть полезно на teamcity)
        self.log_warnings_abs_path = None
        
        self.capture_to_log = False  # Перехват stdout и stderr в лог
        self.capture_stdin_level = logging.INFO
        self.prev_stdout = None
        self.prev_stderr = None

        self.log_level_stdout = logging.INFO  # С какого уровня выводить в stdout
        self.log_level_log = logging.DEBUG  # С какого уровня выводить в лог-файл
        self.log_error_stack = True  # Добавлять стек к сообщениям об ошибке
        # Форматирование логов в стиле teamcity
        self.is_teamcity = (os.getenv('TEAMCITY', 'false') == 'true')

        # logger инициализируется при первом использовании
        self.logger = None

        # Настройки предупреждений
        self.on_error = None  # Можно установить функцию-колбек
        self.stop_on_error = True
        self.exit_on_stop = False  # Кидать sys.exit(1) или Exception при ошибке
        self.on_warning = None  # Можно установить функцию-колбек
        self.stop_on_warning = False
        # предупреждение о ресурсах с одинаковым id. Если duplicate_res_id == 'error', то будет вызываться log_error.
        self.warn_duplicate_res_id = False

        # Пакеты
        self.package_id_to_path = {}  # {package_id: путь относительно repo_abs_path}
        self.package_path_to_id = None  # OrderedDict{path: package_id} - сначала длинные, потом короткие
        self.resources_rel_package = False  # Пути к ресурсам указываются относительно пакета (TS)

        self.atlas_output_dir_rel_package = True  # Записывать атласы в директорию пакета
        self.atlas_output_subdir_package_id = None  # Записывать пакеты в подкаталог atlases/package_id

        # Результат
        self.generated_atlas_resources_xml = set()  # Сюда будут добавлены все сгенерированные файлы AtlasResources.xml

        self.warnings = []  # Сюда добавляются все предупреждения, возникшие в ходе работы.
        self.errors = []  # Сюда добавляются все ошибки, возникшие в ходе работы.

        # threading
        self.threading_enabled = False  # Попытка использования многопоточности. Виснет, зараза!
        self.thread_max = None  # По умолчанию будет использоваться cpu_count()
        self.thread_local = Dummy()  # В каждом треде своё содержимое.
        self.thread_local.log_padding = 0  # Счётчик для отступа внутри секций (см. log_section)
        self.cache_lock = Dummy()

        # Коллекция всех ресурсов из *Resources.xml
        # resources_by_group[package_id][group_id] = [{id:”...”, path:".../file.png", ...}]
        self.resources_by_group = {}
        self.resources_by_id = {}  # resources_by_id[resource_id] = [{id:”...”, path:".../file.png", ...}]

        # Описания атласов, которые закоммичены в репозиторий и не собираются автоматически (вдруг такие есть)
        self.resources_atlases = []  # атласы из репозитория, атласы отдельных флеш-анимаций
        self.resources_in_atlases = set()  # Изображения в атласах из репозитория, set(img_path)

        # Солюшены партикловых эффектов
        self.effect_solutions = {}  # self.effect_solutions[package_id][s_id] = node

        # swl
        self.swlgroups = []  # group name -> group_settings - для групп, которые упаковываются в атлас
        self.swl_by_id = {}  # swl id -> settings - для тех, которые не упаковываются в групповой атлас
        self.swlGroupCounter = 0  # уникальный номер для каждого отдельного swl, чтобы swl целиком попадало в один атлас
        self.swl_sheets_xml = None  # default: base_path/SwlSheets.xml
        self.swl_sheets_xml_rel_package = True  # В каждом пакете свой SwlSheets.xml

        # Настройки атласов из AtlasSettings.xml
        self.atlas_default = []  # <AtlasDefault> без id
        self.atlas_default_by_id = {}  # <AtlasDefault> с id
        self.atlas_decls = []  # ноды <Atlas>
        self.atlas_settings_xml_loaded = []  # чтобы не загружать <include> дважды

        # Настройки сжатия из AtlasSettings.xml
        self.compress_settings = {}  # compress_settings[id] = [node, ]

        # колбеки (хуки)
        self.on_pack_atlas_start = None  # on_pack_atlas_start(atlas_id, package_id, group_id, out_name, pack_settings, compress_settings, content, loc)
        self.on_pack_atlas_end = None  # on_pack_atlas_end(atlas_id, package_id, group_id, out_name, from_cache, out_sheets, out_files, loc)
        self.on_compress_start = None  # on_compress_start(file, src_path, fmt, settings, out_name, dbg_info)
        self.on_compress_end = None  # on_compress_end(file, src_path, fmt, settings, out_files, from_cache, dbg_info)

        # Список поддерживаемых атрибутов (для валидации)
        self._all_pack_settings_attrs = set()
        self._pack_settings_attrs = {'width', 'height', 'size', 'split_min_size', 'max_divisions',
                                     'side_div', 'round_size', 'pot', 'round', 'trim', 'padding', 'processing',
                                     'effect_downscale_thr', 'pack_append', 'pma', 'blendAdd', 'exact',
                                     'effect_filter_hidden', 'effect_filter_pma'}
        # + all from GX.PackSettings:
        self._pack_settings_attrs.update({attr for attr in dir(GX.PackSettings) if not attr.startswith("__")})
        self._all_pack_settings_attrs.update(self._pack_settings_attrs)
        # preprocessing attrs:
        self._content_pack_attrs = {'pack', 'needRectangle', 'needRect', 'need_rect', 'noCut', 'cut',
                                    'alpha_threshold', 'thr', 'pma', 'blendAdd', 'exact', 'pack_separate',
                                    'join', 'joinLeft', 'joinRight', 'joinTop', 'joinBottom', 'join_rect',
                                    'add', 'dup', 'gap', 'dup_in_gap', 'fix', 'prescale', 'prescale_x', 'prescale_y'}
        self._all_pack_settings_attrs.update(self._content_pack_attrs)
        # result attrs:
        self._pack_result_attrs = {'subdir', 'subdir_pkg', 'prefix', 'atlasName', 'out_dir', 'out_name', 'atlas_rel_pkg',
                                   'cube', 'xml_add_id', 'xml_add_path', 'reg_xml', 'swl_sheets_xml', 'reg_rel_pkg',
                                   'register_swl_by_path'}
        self._all_pack_settings_attrs.update(self._pack_result_attrs)
        self._all_pack_settings_attrs.update({'group_id', 'rootPath', 'pixelType'})  # настройки для AtlasResources.xml
        # mask attrs:
        self._all_pack_settings_attrs.add('mask')  # также все с префиксом mask_

        # Атрибуты-фильтры
        self._filter_attribs = {'platform', 'package', 'for_poly', 'for_cube', 'for_compress', 'for_swl', 'for_swlgroup'}
        self._filter_attribs_ps = {'resource_id', 'file', 'folder', 'type'}  # для отдельных ресурсов

        # Атрибуты, по которым определяется шаблон атласа:
        self._atlas_template_attribs = {'group', 'swlgroup', 'resource', 'effect', 'swl', 'dir'}

        # Дополнительные форматы сжатия изображений (заменяет функцию compress_image)
        self.compress_functions = {}  # compress_functions['fmt'] = func(self, filename, fmt_name, settings=None, out_name=None)

    def __del__(self):
        self.release_logger()

    @property
    def pack_settings_attrs(self):
        return self._pack_settings_attrs

    @property
    def content_pack_attrs(self):
        return self._content_pack_attrs

    def init_logger(self):
        if not self.logger:
            self.logger = logging.Logger("atlaspacker")

        setupLogger(self.logger, self.__dict__)
        
        if self.capture_to_log:  # перехватываем запись в stdout и stderr для перенаправления в лог
            self.prev_stdout = sys.stdout
            self.prev_stderr = sys.stdout
            sys.stdout = StreamToLogger(self, self.capture_stdin_level)
            sys.stderr = StreamToLogger(self, logging.ERROR)
            if pyscript.Log.OutputLogSinkReinit:
                pyscript.Log.OutputLogSinkReinit()  # чтобы PythonOutputLogSink заново взял sys.stdout и sys.stderr

    def release_logger(self):
        if self.logger is None:
            return
        if self.prev_stdout:
            sys.stdout = self.prev_stdout
            self.prev_stdout = None
        if self.prev_stderr:
            sys.stderr = self.prev_stderr
            self.prev_stderr = None
        if pyscript.Log.OutputLogSinkReinit:
            pyscript.Log.OutputLogSinkReinit()  # чтобы PythonOutputLogSink заново взял sys.stdout и sys.stderr
        handlers = self.logger.handlers[:]
        for handler in handlers:
            handler.close()
            self.logger.removeHandler(handler)
        self.logger = None

    # Логгирование
    def log(self, log_level, msg, *args, **kws):
        if log_level == logging.NOTSET:
            return

        if not self.logger:
            self.init_logger()  # инициализируем при первом обращении

        if not self.logger.isEnabledFor(log_level):
            return

        # Отступ, задаваемый log_section
        padding = self.thread_local.log_padding
        if padding > 0:
            if 'extra' not in kws:
                kws['extra'] = {}
            kws['extra']['padding'] = padding

        # Чтобы вывод не смешивался, откладываем его до завершения работы треда.
        if hasattr(self.thread_local, 'print_buf'):  # мы в одном из тредов
            self.thread_local.print_buf.append((log_level, msg, args, kws))
            return

        self.logger.log(log_level, msg, *args, **kws)

    def log_progress(self, msg, *args):
        self.log(LOG_PROGRESS, msg, *args)

    def log_skip(self, msg, *args):
        self.log(LOG_SKIP, msg, *args)

    def log_write(self, msg, *args):
        self.log(LOG_WRITE, msg, *args)

    def log_info(self, msg, *args):
        self.log(logging.INFO, msg, *args)

    # Предупреждение
    def log_warning(self, msg, *args):
        self.log(logging.WARNING, msg, *args)

        # Запоминаем все предупреждения в специальном списке
        message = logGetMessage(msg, *args)
        self.warnings.append(message)

        if self.on_warning and callable(self.on_warning):
            self.on_warning(message)

        if self.stop_on_warning:
            if self.exit_on_stop:
                sys.exit(1)
            else:
                raise Exception(message)

    # Сообщение об ошибке
    def log_error(self, msg, *args, **kws):
        self.log(logging.ERROR, msg, *args)

        # добавляем стек к сообщению
        if self.log_error_stack:
            if 'trace' in kws:
                stack = str.join('', traceback.format_list(traceback.extract_stack()[:-2]))
                stack += "\n"
                stack += str.join('', traceback.format_tb(kws['trace']))
            else:
                # Используем текущий стек
                stack = str.join('', traceback.format_stack())
            stack = stack.rstrip("\n\r")
            self.log(logging.DEBUG, stack)

        # Запоминаем все ошибки в специально списке
        message = logGetMessage(msg, *args)
        self.errors.append(message)

        if self.on_error and callable(self.on_error):
            self.on_error(message)

        if self.stop_on_error:
            if self.exit_on_stop:
                sys.exit(1)
            else:
                raise Exception(message)

    def log_debug(self, msg, *args):
        self.log(logging.DEBUG, msg, *args)

    def log_verbose(self, msg, *args):
        self.log(LOG_VERBOSE, msg, *args)

    # Добавляет отступ логам, используется с 'with' statement
    def log_section(self, name, log_level=logging.NOTSET, print_close=False):
        class LogSection:  # scope manager
            def __enter__(_self):
                self.log(log_level, name, extra={'blockOpened': True})

                self.thread_local.log_padding += 1

            def __exit__(_self, exc_type, exc_val, tb):
                self.thread_local.log_padding -= 1

                if exc_val and exc_type != SystemExit:
                    raise

                self.log(log_level, name, extra={'blockClosed': True, 'printClose': print_close})

        return LogSection()

    def init_threading(self):
        assert self.threading_enabled is None
        self.threading_enabled = True
        self.thread_pool = ThreadPool(num_threads=self.thread_max)
        self.thread_local = threading.local()  # В каждом треде своё содержимое.
        self.thread_local.log_padding = 0
        self.print_buf = []  # Буфер основного треда, в который рабочие треды перекладывают накопленные логи
        self.print_buf_lock = threading.Lock()  # для доступа из тредов
        self.cache_lock = threading.Lock()

    # Вспомогательная функция для запуска действий в thread_pool.
    def _job_wrapper(self, f, args=()):
        if self.threading_enabled is None:
            self.init_threading()  # по умолчанию включен
        if not self.threading_enabled:
            return f(*args)

        self.log_verbose("job_wrapper %r %.160r" % (f.__name__, args))

        self._flush_print_buf()

        def task():  # выполняется в треде
            thread_print_buf = []
            self.thread_local.print_buf = thread_print_buf
            self.thread_local.log_padding = 0
            try:
                try:
                    f(*args)
                finally:
                    del self.thread_local.print_buf
                    del self.thread_local.log_padding
                    if thread_print_buf:
                        with self.print_buf_lock:
                            self.print_buf.append((logging.DEBUG, '--- vvv async vvv ---', (), {}))
                            self.print_buf.extend(thread_print_buf)
                            self.print_buf.append((logging.DEBUG, '--- ^^^ async ^^^ ---', (), {}))
                            del thread_print_buf[:]  # clear
            except Exception:
                # Хоть мы и в треде, но всё равно выводим self.print_buf в лог,
                # чтобы было понятно, про что exception
                self._flush_print_buf()
                raise  # перебрасываем

        self.thread_pool.add_task(task)  # Запускаем через thread_pool

    # Ждём завершения всех запущенных задач в self.thread_pool
    def _wait_pool_completion(self):
        self.log_info("wait_pool_completion")
        all_done = False
        while not all_done:
            if self.thread_pool.queue.empty():
                self.log_info("wait_pool_completion join")
                self.thread_pool.join()  # Доделываем остаток работы (блокируется).
                # Жаль, что нет неблокирующей функции вместо join, но тут это некритично.
                all_done = True

            self._flush_print_buf()

        self.log_info("wait_pool_completion done")

    def _flush_print_buf(self):
        with self.print_buf_lock:
            if self.print_buf:
                if not self.logger:
                    self.init_logger()
                for row in self.print_buf:
                    (log_level, message, args, kws) = row
                    self.logger.log(log_level, message, *args, **kws)
                del self.print_buf[:]  # clear

    # Костыль для запуска функций T8 в отдельном процессе,
    # т.к. они не могут работать в тредах (не реентерабельны).
    # Это синхронный вызов, несмотря на отдельный процесс.
    # (Многопоточность достигается использованием тредов.)
    def _process_wrapper(self, f):
        if self.threading_enabled is None:
            self.init_threading()  # по умолчанию включен
        if not self.threading_enabled:
            return f()

        p = multiprocessing.Process(target=f)
        p.daemon = True
        p.start()
        p.join()  # Тут же дожидаемся завершения процесса

    # Парсим выражение, определяющее Parse.Direction (left, right, bottom, top)
    # Результат записывается в obj (Packer.Direction). (Не перезаписывает поля, если они не заданы в v.)
    def parse_direction(self, v, obj=None):
        if v is None:
            return None

        if obj is None:
            obj = Packer.Direction()

        assert type(v) == str

        v = v.strip()
        if v == "":
            return obj

        # Вспомогательная функция для parse_direction - парсит число из строки.
        # True и False преобразовываются в 1 и 0, т.к. Parse.Direction может хранить только числа.
        def parse_direction_value(v):
            v = v.strip().lower()
            if v == 'true':
                return 1
            if v == 'false':
                return 0
            return int(v)

        a = re.split('[;,]', v)

        if all(re.match(r'^(left|right|bottom|top|l|r|t|b)$', x.strip().lower()) for x in a):  # e.g. join="left,top"
            a = [x + ":true" for x in a]  # превращаем в ["left:true", "top:true"]

        if re.match(r'^[lrtb]+$', v.lower()):
            a = [x + ":true" for x in v]  # превращаем в ["l:true", "r:true"]

        if not any(re.search(':', x) for x in a):
            if len(a) == 1:  # e.g. gap="2"
                obj.left = obj.right = obj.bottom = obj.top = parse_direction_value(a[0])
            elif len(a) == 2:  # e.g. gap="2;4"
                obj.left = obj.right = parse_direction_value(a[0])
                obj.bottom = obj.top = parse_direction_value(a[1])
            elif len(a) == 3:  # такое не будем поддерживать
                self.log_error("Wrong direction value: %r " % v)
            elif len(a) == 4:  # e.g. gap="1;2;2;2"
                obj.left = parse_direction_value(a[0])
                obj.right = parse_direction_value(a[1])
                obj.bottom = parse_direction_value(a[2])  # !!!
                obj.top = parse_direction_value(a[3])
            else:
                self.log_error("Failed to parse direction: %r" % v)
        else:
            # ожидаем что-то вроде "left: 4; top: 2"
            for x in a:
                m = re.match(r'^\s*(\w+)\s*:\s*(\S+)\s*$', x)
                if not m:
                    self.log_error("Failed to parse direction %r in %r" % (x, v))
                    continue
                key = m.group(1).lower()
                val = m.group(2)
                if key == 'left' or key == 'l':
                    obj.left = parse_direction_value(val)
                elif key == 'right' or key == 'r':
                    obj.right = parse_direction_value(val)
                elif key == 'bottom' or key == 'b':
                    obj.bottom = parse_direction_value(val)
                elif key == 'top' or key == 't':
                    obj.top = parse_direction_value(val)
                else:
                    self.log_error("Failed to parse direction: unknown key %r: %r" % (key, v))
        return obj

    # Создаём директорию при необходимости
    def ensure_dir(self, path, root_path=None):
        if root_path is None:
            root_path = self.dst_abs_path
        if not os.path.exists(os.path.join(root_path, path)):
            self.log_write("Make dirs: " + path)
            if not self.dry_run:
                os.makedirs(os.path.join(root_path, path))

    # Устанавливаем список пакетов. package_id_to_path[package_id] = path
    # Считается, что некоторые подкаталоги являются пакетами, и для них упаковка может делаться по-особому (или нет).
    # Пути указываются относительно repo_abs_path
    def set_packages(self, package_id_to_path):
        self.package_id_to_path = package_id_to_path.copy()

        self.package_path_to_id = OrderedDict()
        # Используем OrderedDict с ключами, отсортированными от длинных к коротким, на случай вложенных пакетов
        for package_id in sorted(self.package_id_to_path.keys(), key=lambda package_id: self.package_id_to_path[package_id], reverse=True):
            path = normpath(self.package_id_to_path[package_id])
            self.package_path_to_id[path] = package_id
            self.log_debug("set_package %r %r" % (package_id, path))

    # Инициализация кэша (rescache.py)
    def init_cache(self):
        self.log_verbose("Init cache: %r %r %r" % (self.cache_path, self.cache_hashes_file, self.cache_out_path))
        self.cache = ResourceCache(os.path.abspath(self.dst_abs_path), self.cache_path,
                                   self.cache_hashes_file, self.cache_out_path, copy_to_repo=True)
        if self.cache_thumb is not None:
            self.cache.thumb = self.cache_thumb
        else:
            self.cache.thumb = self._init_cache_hash()
        self.cache.init(self.cache_deps_file)

        self.cache.on_error = lambda text: self.log_warning("[cache error] " + str(text))
        self.cache.on_print = lambda text: self.log_debug(text)

    # Собираем хэш для кэша (cache.thumb)
    def _init_cache_hash(self):
        result = ""
        result += self.platform
        # resbuilder version:
        result += "|" + pyscript.string.hash(pyscript.Version)
        # rescache.py text:
        cur_dir = os.path.dirname(os.path.realpath(__file__))
        result += "|" + pyscript.fs.hash_text(normpath(os.path.join(cur_dir, "rescache.py")))
        result += "|" + pyscript.fs.hash_text(re.sub(r"\.py\w+$", ".py", os.path.realpath(__file__)))
        self.log_debug("cache thumb %r" % result)
        return result

    # Обходим каталог cur_path (например, base) в поисках ресурсных xml
    def find_resource_xmls(self, cur_path):
        with self.log_section("find_resource_xmls %r" % cur_path, LOG_PROGRESS):
            cur_path = normpath(os.path.join(self.repo_abs_path, cur_path))
            result = []
            for root, dirs, items in os.walk(cur_path):
                for name in items:
                    if name.endswith('.xml'):
                        file = normpath(os.path.join(root, name))

                        ok = True
                        with open(file, 'rb') as f:
                            head = f.read(4096)
                            ok = (head.find(b'<Resources>') >= 0 or head.find(b'<EffectSolution') >= 0)
                        if not ok:
                            continue

                        file = normpath(os.path.relpath(file, self.repo_abs_path))
                        result.append(file)
                        self.log_verbose("resource xml found: %r" % file)
            result.sort()
            return result

    # Читаем найденные ресурсные xml и собираем из них ресурсы
    def gather_resources(self, base_path=None):
        if base_path is None:
            self._gather_resources_impl(self.base_path)
            # Проверяем пакеты, если они не в base:
            if self.package_id_to_path:
                for k, path in sorted(self.package_id_to_path.items()):
                    if os.path.commonprefix([normpath(path) + "/", self.base_path + "/"]) != self.base_path + "/":
                        self._gather_resources_impl(path)
        else:
            self._gather_resources_impl(base_path)

    # Вспомогательная функция для gather_resources
    def _gather_resources_impl(self, base_path=None):
        with self.log_section("gather_resources: %r" % base_path, LOG_PROGRESS):
            # Ищем ресурсные xml:
            res_xmls = self.find_resource_xmls(base_path)
            # Собираем ресурсы
            for filename in res_xmls:
                # Проверяем ignore_resource_path
                if self.ignore_resource_path:
                    skip = False
                    for pat in self.ignore_resource_path:
                        if os.path.commonprefix([filename + "/", normpath(pat) + "/"]) == normpath(pat) + "/" \
                                or self.wildcard_match(filename, pat):
                            self.log_debug("Skip ignored resource path %r" % filename)
                            skip = True
                            break
                    if skip:
                        continue
                package_id = self.detect_package(filename)
                if package_id:
                    self.log_debug("detected package %r for file %r" % (package_id, filename))
                cur_base = base_path
                if self.resources_rel_package:  # Пути к ресурсам указываются относительно пакета (TS)
                    if package_id and package_id in self.package_id_to_path:
                        cur_base = self.package_id_to_path[package_id]
                self.collect_resources(filename, cur_base, package_id)

    def run(self, pack_atlases=True, compress=True, resources_path=None):
        # обходим каталог base и собираем ресурсы из ресурсных xml
        self.gather_resources(resources_path)
        # подготавливаем настройки атласов со списком текстур
        atlases = self.prepare_atlases()
        if compress is False:
            self.compress_atlas_immediately = False
        # Пакуем атласы
        if pack_atlases:
            self.pack_all_atlases(atlases)
        # Сжимаем изображения
        if compress:
            self.compress_all(atlases)
        # Завершаем работу
        # Очищаем кэш от лишних файлов
        if self.cache:
            if self.cache_clean:
                self.cache.clean()
            self.cache.save()
        # Выводим финально количество ошибок/предупреждений
        if self.warnings:
            self.log_info("Warnings: %d" % len(self.warnings))
        if self.errors:
            self.log_info("Errors: %d" % len(self.errors))

        self.release_logger()

    # Добавляет ресурс в списки ресурсов. У ресурса должен быть id, full_path до изображения, package, group.
    def add_resource(self, res):
        self.log_debug("add_resource %s" % tostr(res))

        package_id = res.get('package')
        if package_id is None:
            package_id = ''

        group_id = res.get('group')
        if group_id is None:
            group_id = ''

        full_path = res.get('full_path')  # (путь относительно repo_abs_path)
        if res.get('type') == 'texture' or res.get('type') == 'sprite':
            # Проверяем наличие файла
            if not os.path.exists(os.path.join(self.repo_abs_path, full_path)):
                # Если файл не найден, пробуем другие расширения
                tmp_path = FileNameWithoutExt(full_path)
                for ext in ('.png', '.webp', '.jpg', '.jpeg', '.JPG'):
                    if os.path.exists(os.path.join(self.repo_abs_path, tmp_path + ext)):
                        full_path = res['full_path'] = tmp_path + ext
                        self.log_debug("  adjust file ext: " + full_path)
                        break
                # проверяем ещё раз
                if not os.path.exists(os.path.join(self.repo_abs_path, full_path)):  # ничего не нашлось
                    self.log_error("No resource file %r: %r @ %s" % (res.get('id'), full_path, res.get('@loc')))
                    return

        # add to resources_by_group
        if package_id not in self.resources_by_group:
            self.resources_by_group[package_id] = {}
        if group_id not in self.resources_by_group[package_id]:
            self.resources_by_group[package_id][group_id] = []
        self.resources_by_group[package_id][group_id].append(res)

        # add to resources_by_id
        res_id = res.get('id')
        if res_id is None:
            self.log_error("No resource id: %r" % res)
            return

        if res_id not in self.resources_by_id:
            self.resources_by_id[res_id] = [res]
        else:
            # Уже есть такой res_id в resources_by_id.

            # Не добавляем ресурс с таким же id и full_path:
            if full_path and any(r.get('full_path') == full_path for r in self.resources_by_id[res_id]):
                self.log_warning("Ignore duplicate resource %r: %r @ %r" % (res_id, full_path, res.get('@loc')))
                return

            if self.warn_duplicate_res_id:
                res0 = self.resources_by_id[res_id][0]
                if self.warn_duplicate_res_id == 'error':
                    self.log_error("Duplicate resource %r @ %r vs %r" % (res_id, res.get('@loc'), res0.get('@loc')))
                else:
                    self.log_warning("Duplicate resource %r @ %r vs %r" % (res_id, res.get('@loc'), res0.get('@loc')))

            # Всё-таки добавляем ресурс
            self.resources_by_id[res_id].append(res)

    # Вытаскиваем текстуры и прочие ресурсы из Resources.xml
    def collect_resources(self, filename, base_path, package=None):
        with self.log_section("collect_resources %r (%r) (%r)" % (filename, base_path, package or ""), logging.DEBUG):
            doc = xml_read(filename, self.repo_abs_path)

            if doc.getroot().tag == 'EffectSolution':
                s_id = doc.getroot().get('id', filename)
                package_id = doc.getroot().get('package', package)
                if package_id is None:
                    package_id = self.detect_package(filename, s_id)
                if package_id not in self.effect_solutions:
                    self.effect_solutions[package_id] = {}
                if s_id in self.effect_solutions[package_id]:
                    self.log_warning("Overwrite EffectSolution: %s with %s",
                                     lxml_cur_pos(self.effect_solutions[package_id][s_id]), lxml_cur_pos(doc.getroot()))
                self.effect_solutions[package_id][s_id] = doc.getroot()
                doc.getroot().set('_path', filename)  # запоминаем путь к файлу
                doc.getroot().set('_base_path', base_path)  # запоминаем base_path
                self.log_debug("solution %r (%r)" % (s_id, package_id))
                return

            for group_node in doc.getroot().findall('Textures') + doc.getroot().findall('Sprites'):
                self.get_textures_info(group_node, base_path, package)

            for group_node in doc.getroot().findall('SWL') + doc.getroot().findall('SWLGroup'):
                self.get_swlgroup_info(group_node, base_path, package)

            if not self.ignore_model_animation_resources:
                for group_node in doc.getroot().findall('ModelAnimations'):
                    self.get_modelanim_info(group_node, base_path, package)

            if not self.ignore_sheet_resources:  # по умолчанию False
                # Атласы читаем только для того, чтобы позже не сжимать текстуры, упакованные в эти атласы.
                for group_node in doc.getroot().findall('Sheets'):
                    self.get_sheet_info(group_node, base_path, package)

    # Читаем описания атласов из тега <Sheets> (group_node)
    # Только для того, чтобы в compress_all не сжимать текстуры, упакованные в эти атласы.
    def get_sheet_info(self, group_node, base_path, package):
        with self.log_section("get_sheet_info %r @ %r" % (lxml_cur_pos(group_node), base_path), logging.DEBUG):
            parent_group = group_node.get('group')
            for node in group_node.findall('sheet'):
                path = node.get('path')
                if path:
                    # Записываем в resources_atlases, для сжатия в compress_res_atlases
                    item = {}
                    item['@loc'] = lxml_cur_pos(node)
                    item['type'] = 'atlas'
                    item['id'] = node.get('id')
                    item['package_id'] = package
                    item['group_id'] = node.get('group') or parent_group
                    item['full_path'] = normpath(os.path.join(base_path, path))
                    for k, v in node.attrib.items():
                        if k in self._all_pack_settings_attrs or k.startswith("compress"):
                            item[k] = v
                    self.resources_atlases.append(item)
                    self.log_debug("resources_atlases add %r @ %r" % (tostr(item), item['@loc']))
                else:
                    self.log_warning("No path in atlas description: %r" % lxml_cur_pos(node))

                xml_path = node.get('xml')
                if not xml_path:
                    self.log_warning("No 'xml' attribute in sheet: %r" % lxml_cur_pos(node))
                    continue
                xml_path = normpath(os.path.join(base_path, xml_path))

                if not os.path.exists(os.path.join(self.repo_abs_path, xml_path)):
                    self.log_error("%r: file doesn't exist: %r" % (lxml_cur_pos(node), xml_path))
                    continue
                # читаем содержимое атласа
                doc = xml_read(xml_path, self.repo_abs_path)
                for frames in doc.getroot():
                    frames_path = frames.get('path', "")
                    for frame in frames:
                        tex_path = frame.get('path')
                        if not tex_path:
                            self.log_error(lxml_cur_pos(frame) + ": no 'path' attribute")
                            continue
                        tex_path = normpath(os.path.join(base_path, frames_path, tex_path))
                        # Запоминаем содержимое атласа. Эти файлы не сжимаем, т.к. они в атласе.
                        self.resources_in_atlases.add(tex_path)  # rel repo_abs_path
                        self.log_debug("resources_in_atlases add %r @ %r" % (tex_path, lxml_cur_pos(frame)))

    # Читаем описания текстур из тега <Textures> (group_node)
    def get_textures_info(self, group_node, base_path, package):
        with self.log_section("get_textures_info %r" % lxml_cur_pos(group_node), logging.DEBUG):
            self.log_debug("base_path=%r, package=%r" % (base_path, package))
            basePath = group_node.get('basePath', default="")
            group_path = normpath(os.path.join(base_path, basePath))
            group_package = group_node.get('package', package)
            group_group = group_node.get('group')
            group_alphaLimit = group_node.get('alphaLimit')

            for node in group_node.findall('texture') + group_node.findall('sprite'):
                res = {}
                res['@loc'] = lxml_cur_pos(node)
                res['type'] = node.tag

                res['id'] = node.get('id')

                res['path'] = normpath(node.get('path'))
                if not res['path']:
                    self.log_error("No 'path' for texture: %r" % lxml_cur_pos(node))
                    continue
                # full_path - путь относительно repo_abs_path
                res['full_path'] = normpath(os.path.join(group_path, res['path']))

                group_id = node.get('group', group_group)
                if group_id:
                    res['group'] = group_id

                package_id = node.get('package', group_package)
                if package_id is None:
                    package_id = self.detect_package(res['full_path'], res['id'])
                if package_id:
                    res['package'] = package_id

                self._copy_content_attrs([res], group_node.attrib)
                self._copy_content_attrs([res], node.attrib)

                alphaLimit = node.get('alphaLimit', group_alphaLimit)
                if alphaLimit is not None:
                    res['mask_limit'] = alphaLimit

                self.add_resource(res)

    # Сохраняем информацию о SWLGroup из ресурсной xml
    def get_swlgroup_info(self, group_node, base_path, package):
        with self.log_section("get_swlgroup_info %r" % lxml_cur_pos(group_node), logging.DEBUG):
            self.log_debug("base_path=%r, package=%r" % (base_path, package))
            group_settings = dict(group_node.attrib)
            group_settings['@loc'] = lxml_cur_pos(group_node)
            group_settings['base'] = base_path
            if package:
                if group_settings.get('package') and group_settings.get('package') != package:
                    self.log_warning("Change package %r -> %r @ %s" % (group_settings.get('package'), package, group_settings.get('@loc')))
                group_settings['package'] = package
            # Упаковывается ли группа в атлас
            atlas = bool_attr(group_settings.get('atlas')) or group_settings.get('atlasName')
            if atlas:
                self.swlgroups.append(group_settings)

            self.log_verbose("swl group %r @ %s" % (group_settings, lxml_cur_pos(group_node)))

            children = []
            for node in group_node.findall('SWLib') + group_node.findall('swl'):
                settings = group_settings.copy()
                settings.update(dict(node.attrib))
                settings['@loc'] = lxml_cur_pos(node)

                if not settings.get('path'):
                    self.log_warning("No swl path @ %s" % lxml_cur_pos(node))
                    continue

                children.append(settings)
                self.log_verbose("  swl item %r @ %s" % (settings, lxml_cur_pos(node)))

                # Сохраняем swl, которые не упаковываются в групповой атлас, в swl_by_id.
                if not atlas:
                    swl_id = settings.get('id')
                    if swl_id:
                        if swl_id in self.swl_by_id:
                            self.log_warning("Duplicate swl id %r @ %s vs %s" % (swl_id, self.swl_by_id[swl_id].get('@loc'), settings.get('@loc')))
                        self.swl_by_id[swl_id] = settings

                    atlas_path = self.swl_full_path(settings) + ".png"
                    if os.path.exists(os.path.join(self.repo_abs_path, atlas_path)):
                        # Записываем в resources_atlases, для сжатия в compress_res_atlases
                        item = {}
                        item['@loc'] = settings.get('@loc')
                        item['type'] = 'swlatlas'
                        item['id'] = settings.get('id')
                        item['package_id'] = package
                        item['group_id'] = settings.get('group')
                        item['full_path'] = atlas_path
                        for k, v in settings.items():
                            if k in self._all_pack_settings_attrs or k.startswith("compress"):
                                item[k] = v
                        self.resources_atlases.append(item)
                        self.log_debug("resources_atlases add %r @ %r" % (tostr(item), item['@loc']))
            group_settings['children'] = children

    # Вспомогательная функция для определения пакета по пути
    def detect_package(self, check_path, res_id=None, def_v=""):
        if self.package_path_to_id:
            for path, package_id in self.package_path_to_id.items():  # package_path_to_id - OrderedDict
                if os.path.commonprefix([check_path, path + '/']) == path + '/':
                    return package_id
        return def_v

    # Проверка на соответствие шаблону (этот метод чисто заглушка)
    def wildcard_match(self, pat, s):
        return wildcard_match(pat, s)

    # Обёртка над glob
    def glob(self, pathname):
        if "**/" in pathname:  # костыль для рекурсивного glob
            result = []
            (path, name) = pathname.split('**/', 1)  # maxsplit = 1
            for curdir, folders, items in os.walk(path):
                for f in items:
                    if fnmatch.fnmatch(f, name):
                        result.append(normpath(os.path.join(curdir, f)))
            result.sort()
            return result
        # else:
        result = glob.glob(pathname)
        result.sort()
        return result

    # Читаем анимации из тега <ModelAnimations>
    def get_modelanim_info(self, group_node, root_path, package=None, group=None):
        with self.log_section("get_modelanim_info %r @ %r" % (root_path, lxml_cur_pos(group_node)), logging.DEBUG):
            for node in group_node.findall('animation'):
                res = {}
                res['@loc'] = lxml_cur_pos(node)
                res['type'] = 'model'
                res['id'] = node.get('id')
                if not res['id']:
                    self.log_warning("No 'id' at %s", item.get('@loc'))
                
                res['path'] = node.get('path')
                if not res['path']:
                    self.log_error("No 'path' at %s", lxml_cur_pos(node))
                    continue
                res['full_path'] = normpath(os.path.join(root_path, res['path']))
                
                res['package'] = node.get('package', package)
                res['group'] = node.get('group', group)
                
                if root_path != self.base_path:
                    res['_base_path'] = root_path
                
                for k, v in node.attrib.items():
                    if k in self._all_pack_settings_attrs or k.startswith("compress"):
                        res[k] = v
                
                #~ res['node'] = node
                
                self.add_resource(res)
    
    def collect_model_textures(self, content):
        for item in content[:]:  # итерируемся по копии, чтобы делать remove
            if item.get('type') == 'model':
                
                idx = content.index(item)
                content.remove(item)
                
                path = item.get('path')
                root_path = item.get('_base_path', self.base_path)
                
                package_id = item.get('package')
                group = item.get('group')
                
                xml_paths = None
                if os.path.exists(os.path.join(self.repo_abs_path, root_path, path)):
                    xml_paths = [path]
                elif os.path.exists(os.path.join(self.repo_abs_path, root_path, path + ".xml")):
                    xml_paths = [path + ".xml"]
                if not xml_paths:
                    # LoadSplittedModel
                    files = self.glob(os.path.join(self.repo_abs_path, root_path, path + ".*.xml"))
                    if files:
                        xml_paths = [normpath(os.path.relpath(f, os.path.join(self.repo_abs_path, root_path))) for f in files];
                if not xml_paths:
                    # Ищем в подкаталоге xml/ (Township old)
                    (dirname, fname) = os.path.split(path)
                    f = normpath(os.path.join(dirname, "xml", fname))
                    if os.path.exists(os.path.join(self.repo_abs_path, root_path, f)):
                        xml_paths = [f]
                
                if not xml_paths:
                    if os.path.exists(os.path.join(self.repo_abs_path, root_path, path + ".bin")):
                        # ~ TODO: научить resbuilder читать список текстур из бинарных анимаций.
                        self.log_skip("Skip binary model: %r @ %s" % (path + ".bin", item.get('@loc')))
                    else:
                        self.log_error("Missing file: %r @ %s" % (resolved_path, item.get('@loc')))
                    continue
                
                for filename in xml_paths:
                    with self.log_section("collect_model_textures %r / %r @ %s" % (root_path, filename, item.get('@loc')), logging.DEBUG):
                        local_dir = os.path.dirname(os.path.join(root_path, filename))
                        doc = xml_read(os.path.join(root_path, filename), self.repo_abs_path)
                        for node in doc.getroot().findall('.//material/texture'):
                            res = {}
                            res['@loc'] = lxml_cur_pos(node)
                            res['type'] = 'texture'
                            name = node.get('name')
                            if not name:
                                self.log_error("No 'name' at: " + lxml_cur_pos(node))
                                continue
                            res['id'] = name
                            path = normpath(FileNameWithoutExt(name) + ".png")
                            res['path'] = path
                            # full_path - путь относительно repo_abs_path
                            if os.path.exists(os.path.join(self.repo_abs_path, local_dir, path)):  # file in local directory
                                res['full_path'] = normpath(os.path.join(local_dir, path))
                            elif os.path.exists(os.path.join(self.repo_abs_path, root_path, path)):  # rel base (Township)
                                res['full_path'] = normpath(os.path.join(root_path, path))
                            else:
                                self.log_error("Missing file: %r @ %s" % (path, lxml_cur_pos(node)))

                            if package_id is None:
                                package_id = self.detect_package(res['full_path'], res['id'])
                            if package_id:
                                res['package'] = package_id

                            if group:
                                res['group'] = group
                            
                            # Переносим настройки упаковки из описания эффекта
                            self._copy_content_attrs([res], item)
                            
                            self.log_debug("resource %s" % tostr(res))
                            
                            content.insert(idx, res)
                            idx += 1

    # Читаем настройки из файла AtlasSettings.xml
    def read_settings_xml(self, filename, dbg_info=""):
        with self.log_section("read_settings_xml: %r" % utf8_encode(filename), logging.DEBUG):
            if os.path.exists(os.path.join(self.repo_abs_path, filename)):
                pass
            elif os.path.exists(filename):  # На случай, если вдруг попадётся абсолютный путь
                filename = normpath(os.path.relpath(filename, self.repo_abs_path))
            else:
                self.log_error("Can't find file: %r %s" % (utf8_encode(filename), dbg_info))
                return

            # Проверяем, чтобы файл не загружался дважды. (Спасает от рекурсивного инклуда.)
            if filename in self.atlas_settings_xml_loaded:
                self.log_warning("Don't include %r again, skip. %s" % (utf8_encode(filename), dbg_info))
                return
            self.atlas_settings_xml_loaded.append(filename)

            doc = xml_read(filename, self.repo_abs_path)
            for node in doc.getroot():
                self.read_settings_xml_node(node)

    def read_settings_xml_node(self, node):
        if node.tag == 'Settings':
            self.read_global_settings_xml_node(node)
        elif node.tag == 'AtlasDefault':
            atlas_id = node.get('id')
            if atlas_id is None:
                self.atlas_default.append(node)  # <AtlasDefault> без id
            else:
                if atlas_id in self.atlas_default_by_id:
                    self.log_error(lxml_cur_pos(node) + " conflicts with previous declaration " +
                                   lxml_cur_pos(self.atlas_default_by_id[atlas_id]))
                self.atlas_default_by_id[atlas_id] = node  # <AtlasDefault> с id
        elif node.tag == 'Atlas':
            atlas_id = node.get('id')
            if node.find('Content') is not None:  # <Atlas> с тегом <Content>
                if not atlas_id:
                    self.log_error("%s: attribute 'id' expected" % lxml_cur_pos(node))
                # проверяем, чтобы не было атрибутов шаблонов
                for attr in self._atlas_template_attribs:
                    if node.get(attr) is not None:
                        self.log_error("%s: attribute %r conflicts with <Content>" % (lxml_cur_pos(node), attr))
                self.atlas_decls.append(node)
            else:
                # <Atlas> без тега <Content>, ожидаем шаблон упаковки (e.g. <Atlas group=".*">)
                template_attr_found = False
                for attr in self._atlas_template_attribs:
                    if node.get(attr):
                        template_attr_found = True
                        break
                if template_attr_found:
                    self.atlas_decls.append(node)
                else:
                    if atlas_id is None:
                        self.atlas_default.append(node)
            if atlas_id is not None:
                if atlas_id in self.atlas_default_by_id:
                    self.log_error(lxml_cur_pos(node) + " conflicts with previous declaration " +
                                   lxml_cur_pos(self.atlas_default_by_id[atlas_id]))
                self.atlas_default_by_id[atlas_id] = node
        elif node.tag == 'Compress':
            # настройки сжатия
            self.read_compress_settings_node(node)
        elif node.tag.lower() == 'include':
            inc_path = node.get("path")
            if inc_path:
                # Сначала смотрим относительно текущего файла, потом глобально
                filename = node.base  # текущий файл
                loc_path = normpath(os.path.join(os.path.dirname(filename), inc_path))
                if os.path.exists(os.path.join(self.repo_abs_path, loc_path)):
                    self.read_settings_xml(loc_path, "@ %s" % lxml_cur_pos(node))
                else:
                    inc_path = normpath(inc_path)
                    self.read_settings_xml(inc_path, "@ %s" % lxml_cur_pos(node))
            else:
                self.log_error("Missing 'path' attribute in <%s> node @ %s" % (node.tag, lxml_cur_pos(node)))
        else:
            self.log_error("Unexpected node: %r @ %s" % (node.tag, lxml_cur_pos(node)))

    # Применяем настройки из ноды <Settings> в атрибуты self
    def read_global_settings_xml_node(self, node):
        if not self.check_filter_attrs(node):
            return

        with self.log_section("read_global_settings_xml_node %s" % (lxml_cur_pos(node)), logging.DEBUG):
            for key, v in sorted(node.attrib.items()):
                if hasattr(self, key):
                    if type(getattr(self, key)) is str or getattr(self, key) is None:
                        self.log_debug("setattr %r %r" % (key, v))
                        setattr(self, key, v)
                    elif type(getattr(self, key)) is int:
                        self.log_debug("setattr %r %r" % (key, v))
                        setattr(self, key, int(v))
                    elif type(getattr(self, key)) is bool:
                        self.log_debug("setattr %r %r" % (key, v))
                        setattr(self, key, bool_attr(v))
                    elif type(getattr(self, key)) is list:
                        self.log_debug("append %r %r" % (key, v))
                        getattr(self, key).append(v)
                    else:
                        self.log_error("Can't apply setting %r @ %s" % (key, lxml_cur_pos(node)))
                else:
                    self.log_error("Unexpected setting %r @ %s" % (key, lxml_cur_pos(node)))

            # Доинициализируем логгер настройками из xml
            self.init_logger()

            for child in node:
                self.read_global_settings_xml_node(child)

    # Собирает настройки в одну кучу из нод AtlasDefault и текущей ноды
    def calc_atlas_settings(self, decl, package_id, group_id, pack_settings=None, preprocess_settings=None):
        if pack_settings is None:
            pack_settings = {}
        if preprocess_settings is None:
            preprocess_settings = []

        with self.log_section("calc_atlas_settings %s %r" % (lxml_cur_pos(decl), pack_settings), LOG_VERBOSE):
            if decl is not None:
                self._calc_atlas_settings_node(decl, package_id, group_id, pack_settings, preprocess_settings)
            self.log_verbose("initial %s" % tostr(pack_settings))

            # Применяем настройки из default_by_id. Они применяются после настроек из default.
            if decl is not None and decl.get('default'):
                def_node = self.atlas_default_by_id.get(decl.get('default'))
                if def_node is not None:
                    if self.check_filter_attrs(def_node, pack_settings, package_id):
                        self.log_verbose("add default %s" % lxml_cur_pos(def_node))
                        # Применяем настройки из default ноды
                        self.calc_atlas_settings(def_node, package_id, group_id, pack_settings, preprocess_settings)
                        self.log_verbose("updated %s" % tostr(pack_settings))
                    else:
                        self.log_verbose("skip default by filter %s" % lxml_cur_pos(def_node))
                else:
                    self.log_error("No AtlasDefault node with id: %r" % decl.get('default'))
            else:
                # Применяем все настройки по умолчанию
                for def_node in reversed(self.atlas_default):  # более поздние ноды имеют больший приоритет
                    if self.check_filter_attrs(def_node, pack_settings, package_id):
                        self.log_verbose("add default %s" % lxml_cur_pos(def_node))
                        # Применяем настройки из default ноды
                        self._calc_atlas_settings_node(def_node, package_id, group_id, pack_settings, preprocess_settings)
                        self.log_verbose("updated %s" % tostr(pack_settings))
                    else:
                        self.log_verbose("skip default by filter %s" % lxml_cur_pos(def_node))

        return pack_settings, preprocess_settings

    # Применяем настройки из ноды, не перезаписывая существующие в pack_settings
    def _calc_atlas_settings_node(self, decl, package_id, group_id, pack_settings, preprocess_settings=None, pack_settings_orig=None):
        with self.log_section("_calc_atlas_settings_node %s %r" % (lxml_cur_pos(decl), pack_settings), LOG_VERBOSE):
            if pack_settings_orig is None:
                pack_settings_orig = pack_settings.copy()  # shallow copy

            for key, v in sorted(decl.attrib.items()):
                if key in {'id', 'default'}:
                    pass
                elif key in self._filter_attribs:
                    pass
                elif key in self._atlas_template_attribs:
                    pack_settings['template'] = key
                elif key in self._all_pack_settings_attrs or re.match(r'^mask_', key):
                    if key not in pack_settings_orig:
                        pack_settings[key] = v
                        self.log_verbose("%s = %r" % (key, v))
                elif decl.tag == 'preprocess' and key in self._filter_attribs_ps:
                    # сохраняем атрибуты для check_filter_attrs_ps - они будут использоваться позже, при процессинге текстур
                    if key not in pack_settings_orig:
                        pack_settings[key] = v
                        self.log_verbose("%s = %r" % (key, v))
                elif re.match(r'^compress(_\w+)?$', key):
                    if 'compress' in pack_settings_orig:
                        self.log_verbose("compress is already defined, ignore @ %s" % lxml_cur_pos(decl))
                        continue
                    if v:  # ignore compress=""
                        if (key == 'compress_' + self.platform
                                or key == 'compress' and not (('compress_' + self.platform) in decl.attrib)):
                            compress = self.parse_compress_str(v, lxml_cur_pos(decl))
                            if compress:
                                if pack_settings.get('compress') and not compress.get('format'):
                                    pack_settings['compress'].update(compress)
                                    self.log_verbose("compress add %s" % tostr(compress))
                                else:
                                    pack_settings['compress'] = compress
                                self.log_verbose("compress = %s" % tostr(pack_settings['compress']))
                else:
                    self.log_error("Unexpected attribute: %r @ %s" % (key, lxml_cur_pos(decl)))

            for node in decl:
                if not self.check_filter_attrs(node, pack_settings, package_id):
                    self.log_verbose("skip by filter @ %s" % lxml_cur_pos(node))
                    continue
                elif node.tag == 'Content':
                    continue  # Обрабатывается в функции prepare_atlases
                elif node.tag == 'PackSettings' or node.tag == 'Result' or node.tag == 'MaskSettings':
                    self._calc_atlas_settings_node(node, package_id, group_id, pack_settings, preprocess_settings, pack_settings_orig)
                elif node.tag.lower() == 'preprocess':
                    if len(node):
                        self.log_error(lxml_cur_pos(node) + " unexpected children")
                    if preprocess_settings is not None:
                        settings = {}
                        settings['@loc'] = lxml_cur_pos(node)
                        preprocess = []
                        self._calc_atlas_settings_node(node, package_id, group_id, settings, preprocess, pack_settings_orig)
                        if settings:
                            preprocess_settings.append(settings)
                            self.log_verbose("preprocess_settings add %s" % tostr(settings))
                        if preprocess:
                            self.log_error("Unexpected recursive preprocess_settings @ %s" % lxml_cur_pos(node))
                            preprocess_settings.extend(preprocess)
                            self.log_verbose("preprocess_settings add %s" % tostr(preprocess))
                elif node.tag == 'Compress':
                    if 'compress' in pack_settings_orig:
                        self.log_verbose("compress is already defined, ignore @ %s" % lxml_cur_pos(node))
                        continue
                    compress = {}
                    for key, v in sorted(node.attrib.items()):
                        if key in self._filter_attribs:
                            continue
                        compress[key] = v
                    if compress:
                        if pack_settings.get('compress') and not compress.get('format'):
                            pack_settings['compress'].update(compress)
                            self.log_verbose("compress add %s" % tostr(compress))
                        else:
                            pack_settings['compress'] = compress
                        self.log_verbose("compress = %s" % tostr(pack_settings['compress']))

                    if len(node):
                        self.log_error(lxml_cur_pos(node) + " unexpected children")
                else:
                    self.log_error("Unexpected node: %r @ %s" % (node.tag, lxml_cur_pos(node)))

    # Собирает ресурсы по шаблону group=".*"
    def atlas_content_by_group(self, group_attr, package=None):
        result = {}  # result[package_id][group_id] = [content]
        if group_attr is None:
            return result
        with self.log_section("atlas_content_by_group %r %r" % (group_attr, package), logging.DEBUG):
            for package_id in sorted(self.resources_by_group):
                if package is not None and not self.wildcard_match(package, package_id):
                    continue
                for group_id, group_content in sorted(self.resources_by_group[package_id].items()):
                    if self.wildcard_match(group_attr, group_id):
                        if group_id == "" and group_attr != "":
                            continue  # это ресурсы без группы
                        if package_id not in result:
                            result[package_id] = {}
                        if group_id not in result[package_id]:
                            result[package_id][group_id] = []
                        for item in group_content:
                            self.log_debug("content %s" % tostr(item))
                            result[package_id][group_id].append(item.copy())
        return result

    # Собирает описания групп swl по шаблону swlgroup=".*"
    def atlas_content_by_swlgroup(self, group_attr, package=None):
        result = {}  # result[package_id][group_id] -> group_settings
        if group_attr is None:
            return result
        with self.log_section("atlas_content_by_swlgroup %r %r" % (group_attr, package), logging.DEBUG):
            for group_settings in self.swlgroups:
                package_id = group_settings.get('package', "")
                if package and not self.wildcard_match(package, package_id):
                    continue
                group_id = group_settings.get('group', "")
                if self.wildcard_match(group_attr, group_id):
                    self.log_debug("[%s] swlgroup %r %r @ %s", package_id, group_id, group_settings.get('atlasName', ""), group_settings.get('@loc'))
                    if package_id not in result:
                        result[package_id] = {}
                    if group_id in result[package_id]:
                        self.log_warning("Duplicate swl group %r @ %s vs %s", group_id, group_settings.get('@loc'), result[package_id][group_id][0].get('@loc'))
                    result[package_id][group_id] = group_settings
        return result

    # Собирает ресурсы по шаблону resource=".*"
    def atlas_content_resources(self, resource_v):
        result = {}  # result[res_id] = [content]
        if not resource_v:
            return result
        with self.log_section("atlas_content_resources %r" % resource_v, logging.DEBUG):
            for res_id, res in sorted(self.resources_by_id.items()):
                if self.wildcard_match(resource_v, res_id):
                    if res_id not in result:
                        result[res_id] = []
                    for item in res:
                        self.log_debug("content %r %s" % (res_id, tostr(item)))
                        result[res_id].append(item.copy())
        return result

    # Собирает ресурсы по шаблону effect=".*"
    def atlas_content_effects(self, effect_v):
        result = {}  # result[path] = [content]
        if not effect_v:
            return result
        with self.log_section("atlas_content_effects %r" % effect_v, logging.DEBUG):
            for package_id in sorted(self.effect_solutions):
                for s_id, node in sorted(self.effect_solutions[package_id].items()):
                    if not self.wildcard_match(effect_v, s_id):
                        continue

                    solutionPath = node.get('_path')
                    assert solutionPath

                    res = {}
                    res['@loc'] = lxml_cur_pos(node)
                    res['type'] = 'effect'
                    res['id'] = s_id
                    res['path'] = solutionPath
                    res['full_path'] = solutionPath  # (путь относительно repo_abs_path)

                    if package_id:
                        res['package'] = package_id

                    group = node.get('group')
                    if group:
                        res['group'] = group

                    # Собираем атрибуты касательно упаковки атласов - они должны начинаться с префикса 'atlas_'
                    for attr, v in sorted(node.attrib.items()):
                        if attr.startswith('atlas_'):
                            _, k = attr.split("_", 1)  # убираем префикс atlas_
                            if k in self._all_pack_settings_attrs or re.match(r'^mask_', k):
                                res[attr] = v
                            else:
                                self.log_warning("Unexpected attribute: %r @ %s" % (attr, lxml_cur_pos(node)))

                    self.log_debug("content %r %s" % (s_id, tostr(res)))

                    res['node'] = node

                    res_id = s_id
                    if res_id in result:
                        self.log_error("Duplicate solution id %r: %s vs %s",
                                       res_id, lxml_cur_pos(node), result[res_id][0].get('@loc'))
                    result[res_id] = [res]
        return result

    # Возвращает путь к swl без расширения
    def swl_full_path(self, item):
        base_path = item.get('base', self.base_path)
        package_id = item.get('package')
        if self.resources_rel_package and package_id and package_id in self.package_id_to_path:
            # Пути к ресурсам указываются относительно пакета (TS)
            base_path = self.package_id_to_path[package_id]
        return normpath(os.path.join(base_path, item.get('basePath', ""), FileNameWithoutExt(item.get('path', ""))))

    # Собирает ресурсы по шаблону swl=".*" (отдельные swl'ки)
    def atlas_content_swl(self, pat):
        result = {}  # result[path] = settings
        if not pat:
            return result
        with self.log_section("atlas_content_swl %r" % pat, logging.DEBUG):
            path_v = FileNameWithoutExt(pat)
            for swl_id, item in sorted(self.swl_by_id.items()):
                path = self.swl_full_path(item)
                if self.wildcard_match(path_v, path) or self.wildcard_match(pat, swl_id):
                    result[path] = item
            # Добавляем файлы, не описанные в ресурсных xml
            for f in self.glob(os.path.join(self.repo_abs_path, pat)):
                f = FileNameWithoutExt(normpath(os.path.relpath(f, self.repo_abs_path)))
                if f not in result:
                    result[f] = {}
        return result

    # Собирает текстуры для упаковки swl
    def atlas_content_swl_by_path(self, path_v, repack):
        result = []
        if not path_v:
            return result
        with self.log_section("atlas_content_swl_by_path %r" % path_v, logging.DEBUG):
            f = FileNameWithoutExt(path_v) + ".swl"
            if not os.path.exists(os.path.join(self.repo_abs_path, f)):
                self.log_warning("Missing file %r" % f)
                return result

            package_id = self.detect_package(f)
            base_path = self.base_path
            if self.resources_rel_package and package_id and package_id in self.package_id_to_path:
                # Пути к ресурсам указываются относительно пакета (TS)
                base_path = self.package_id_to_path[package_id]

            abspath = normpath(os.path.join(self.repo_abs_path, FileNameWithoutExt(f)))
            if os.path.exists(abspath + ".json"):
                self.swlGroupCounter += 1  # уникальный номер группы для каждого отдельного swl

                json_path = FileNameWithoutExt(f) + ".json"
                self.log_debug("read swl json: %r", json_path)
                mount_dir = os.path.join(self.repo_abs_path, base_path);
                pyscript.MountDirectory(mount_dir)
                pimages = Packer.PImage.CreateFromJsonList(os.path.join(self.repo_abs_path, json_path))
                pyscript.UnmountDirectory(mount_dir)
                textures = self.content_from_pimages(pimages, base_path, None, package_id, json_path)
                for res in textures:
                    res['groupId'] = self.swlGroupCounter  # номер группы для групповой упаковки атласов: все изображения из группы попадут на один лист
                    self.log_debug("  content %r %s" % (f, tostr(res)))
                result.extend(textures)
            elif os.path.exists(abspath + ".png") and os.path.exists(abspath + ".xml"):
                if not repack:
                    self.log_skip("Dont't repack swl atlas %r", FileNameWithoutExt(f) + ".png")
                    return result

                self.swlGroupCounter += 1  # уникальный номер группы для каждого отдельного swl

                # Распаковываем атлас
                self.log_debug("Unpack atlas %r", FileNameWithoutExt(f) + ".png")

                atlas_items = self.unpack_atlas(abspath + ".png")

                for item in atlas_items:
                    res = {}
                    res['@loc'] = FileNameWithoutExt(f) + ".png"
                    res['groupId'] = self.swlGroupCounter  # номер группы для групповой упаковки атласов: все изображения из группы попадут на один лист
                    res['type'] = 'texture'
                    res['id'] = item.get('id')
                    res['path'] = item.get('path')  # путь относительно base
                    res['full_path'] = normpath(os.path.join(base_path, item.get('path')))
                    # full_path не будет использоваться упаковщиком, так как есть image:
                    res['image'] = item.get('image')

                    if package_id:
                        res['package'] = package_id

                    result.append(res)
                    self.log_debug("  content %r %s" % (f, tostr(res)))
            else:
                self.log_skip("Missing textures for swl: %r" % f)
        return result

    # По шаблону с указанием пути
    def atlas_content_files(self, path_v, loc, type_v):
        result = {}
        if not path_v:
            return result
        with self.log_section("atlas_content_files %r" % path_v, logging.DEBUG):
            files = self.glob(os.path.join(self.repo_abs_path, path_v))
            for f in files:
                f = normpath(os.path.relpath(f, self.repo_abs_path))
                res = {}
                if loc:
                    res['@loc'] = loc
                if type_v:
                    res['type'] = type_v
                res['id'] = FileNameWithoutExt(normpath(os.path.relpath(f, self.base_path)))
                res['path'] = f
                res['full_path'] = f  # (путь относительно repo_abs_path)

                package_id = self.detect_package(f)
                if package_id:
                    res['package'] = package_id

                result[f] = res
                self.log_debug("content %s" % tostr(res))
        return result

    # По шаблону с указанием пути
    def atlas_content_texture(self, node):
        res = {}
        res['@loc'] = lxml_cur_pos(node)
        res['type'] = node.get('type', 'texture')
        tex_id = node.get('id')
        if not tex_id:
            tex_id = path_v
        res['id'] = tex_id

        self._copy_content_attrs([res], node.attrib)

        path = normpath(node.get('path'))
        res['path'] = path  # использовался раньше для поиска текстур
        res['full_path'] = normpath(node.get('full_path', path))  # full_path - путь относительно repo_abs_path

        alphaLimit = node.get('alphaLimit')
        if alphaLimit is not None:
            res['mask_limit'] = alphaLimit

        self.log_debug("content %s" % tostr(res))
        
        return res

    # Возвращает package_id, если у всех ресурсов одинаковый package_id.
    def package_id_from_resources(self, resources, atlas_info):
        package_id = None
        for item in resources:
            pkg = item.get('package')
            if pkg is None:
                pkg = ""
            if package_id is None:
                package_id = pkg
                continue
            if pkg != package_id:
                if self.atlas_output_dir_rel_package or self.atlas_output_subdir_package_id:
                    self.log_warning("Resources from different packages in one atlas (%r, %r): %r",
                                     pkg, package_id, atlas_info)
                return None
        if package_id:
            self.log_debug("package_id_from_resources: %r" % (pkg))
        return package_id

    # Подготавливает настройки для упаковки атласов
    def prepare_atlases(self):
        with self.log_section("prepare_atlases", LOG_PROGRESS):
            atlases = self.collect_atlases()  # по описаниям атласов делаем список атласов с нужными наборами ресурсов
            self.prepare_atlas_settings(atlases)  # вычисляем настройки, фильтруем контент
            return atlases

    # По описаниям атласов делает список атласов с нужными наборами ресурсов
    def collect_atlases(self):
        self.log_progress("collect_atlases")
        atlases = []

        # небольшая вспомогательная функция
        def add_atlas(atlas):
            atlases.append(atlas)
            # лог
            self.log_debug("Add atlas id=%r package_id=%r group_id=%r : %r items @ %s",
                           atlas.get('id'), atlas.get('package_id'), atlas.get('group_id'),
                           len(atlas.get('content', [])), lxml_cur_pos(atlas.get('decl')))

        # Запоминаем уже добавленные в атлас ресурсы, чтобы не паковать их дважды (для шаблонов)
        packed_groups = {}  # packed_groups["package_id|group_id"] = True
        packed_resources = {}  # packed_resources[res_id] = True

        # вспомогательная функция: проверяем, вдруг уже паковали эту группу или ресурс
        def check_already_packed(key, d, dbg_info=""):
            if key in d:
                self.log_debug("  already packed %r @ %s" % (key, dbg_info))
                return True
            d[key] = True  # отмечаем тоже обработанным
            return False

        # обрабатываем описания атласов в том порядке, как они записаны в xml
        for decl in self.atlas_decls:
            if decl.find('Content') is not None:  # атлас с тегом <Content>
                self.log_debug("Atlas %s" % lxml_cur_pos(decl))
                if not self.check_filter_attrs(decl):
                    self.log_debug("skip atlas by filter %s" % lxml_cur_pos(decl))
                    continue
                package_attr = decl.get('package')
                # здесь должно отличаться от 'group', т.к. group="..." - это шаблон (см. ниже)
                group_attr = decl.get('group_id')
                if bool_attr(decl.get('pack')) is False:
                    self.log_debug("skip atlas: pack = false @ %s" % lxml_cur_pos(decl))
                    continue
                content = []
                for node in decl.findall('Content'):
                    if not self.check_filter_attrs(node):
                        self.log_debug("skip content by filter @ %s" % lxml_cur_pos(node))
                        continue

                    # По шаблону path="base/.../file.png"
                    if node.get('path'):
                        res = self.atlas_content_texture(node)
                        packed_resources[res['id']] = True  # Запоминаем, что уже паковали этот ресурс
                        content.append(res)
                        continue

                    # По шаблону group="*"
                    if 'group' in node.attrib:
                        group = node.get('group')
                        package = node.get('package')
                        # Костыль для создания пакета через атрибут package в decl
                        if package is None and package_attr is not None and package_attr in self.resources_by_group:
                            package = package_attr
                        contents = self.atlas_content_by_group(group, package)  # собираем ресурсы
                        for package_id in contents:
                            for group_id, group_content in sorted(contents[package_id].items()):
                                self._copy_content_attrs(group_content, node.attrib, lxml_cur_pos(node))
                                # Запоминаем, что уже паковали эту группу
                                packed_groups[package_id + "|" + group_id] = True
                                content.extend(group_content)

                    # По шаблону swlgroup="*"
                    if 'swlgroup' in node.attrib:
                        group = node.get('swlgroup')
                        package = node.get('package')
                        # Костыль для создания пакета через атрибут package в decl
                        if package is None and package_attr is not None and package_attr in self.resources_by_group:
                            package = package_attr
                        swl_groups = self.atlas_content_by_swlgroup(group, package)  # собираем группы
                        for package_id in sorted(swl_groups):
                            for group_id, group_settings in sorted(swl_groups[package_id].items()):
                                # Запоминаем, что уже паковали эту группу
                                packed_groups[package_id + "|(swl)" + group_id] = True
                                for item in group_settings.get('children', []):
                                    swl_path = self.swl_full_path(item)
                                    packed_resources[swl_path] = True
                                    children_content = self.atlas_content_swl_by_path(swl_path, repack=True)
                                    self._copy_content_attrs(group_content, node.attrib, lxml_cur_pos(node))
                                    self.log_verbose("content %s" % tostr(children_content))
                                    content.extend(children_content)

                    # По шаблону resource="*"
                    for res_id, res_content in sorted(self.atlas_content_resources(node.get('resource')).items()):
                        self._copy_content_attrs(res_content, node.attrib, lxml_cur_pos(node))
                        packed_resources[res_id] = True  # Запоминаем, что уже паковали этот ресурс
                        content.extend(res_content)

                    # По шаблону effect="*"
                    for res_id, res_content in sorted(self.atlas_content_effects(node.get('effect')).items()):
                        self._copy_content_attrs(res_content, node.attrib, lxml_cur_pos(node))
                        packed_resources[res_id] = True  # Запоминаем, что уже паковали этот ресурс
                        content.extend(res_content)

                    # По шаблону swl="*"
                    for path, settings in sorted(self.atlas_content_swl(node.get('swl')).items()):
                        res_content = self.atlas_content_swl_by_path(path, repack=True)
                        self._copy_content_attrs(res_content, node.attrib, lxml_cur_pos(node))
                        packed_resources[path] = True  # Запоминаем, что уже паковали этот ресурс
                        content.extend(res_content)
                        # TODO: pack_settings['reg_swl_sheets'] = True

                    # По шаблону files="*"
                    for res_id, res in sorted(self.atlas_content_files(node.get('files'), lxml_cur_pos(node), node.get('type')).items()):
                        self._copy_content_attrs([res], node.attrib, lxml_cur_pos(node))
                        packed_resources[res_id] = True  # Запоминаем, что уже паковали этот ресурс
                        content.append(res)

                add_atlas({'decl': decl, 'id': decl.get('id'), 'package_id': package_attr,
                           'group_id': group_attr, 'content': content})
                continue

            # else:
            # Атласы по шаблонам
            self.log_debug("Atlas template %s" % lxml_cur_pos(decl))
            if not self.check_filter_attrs(decl):
                self.log_debug("Skip atlas by filter %s" % lxml_cur_pos(decl))
                continue

            package_attr = decl.get('package')

            # По шаблону group="*"
            if 'group' in decl.attrib:
                contents = self.atlas_content_by_group(decl.get('group'), package_attr)
                for package_id in sorted(contents):
                    for group_id, group_content in sorted(contents[package_id].items()):
                        if check_already_packed(package_id + '|' + group_id, packed_groups, lxml_cur_pos(decl)):
                            continue
                        packed_groups[package_id + "|" + group_id] = True
                        add_atlas({'decl': decl, 'id': decl.get('id', group_id), 'package_id': package_id,
                                   'group_id': group_id, 'content': group_content, 'template': 'group'})

            # По шаблону swlgroup="*"
            if 'swlgroup' in decl.attrib:
                swl_groups = self.atlas_content_by_swlgroup(decl.get('swlgroup'), package_attr)  # собираем группы
                for package_id in sorted(swl_groups):
                    for group_id, group_settings in sorted(swl_groups[package_id].items()):
                        self.log_debug("[%s] Atlas for swl group %r %r @ %s", package_id, group_id, group_settings.get('atlasName', ""), group_settings.get('@loc'))
                        if check_already_packed(package_id + '|(swl)' + group_id, packed_groups, lxml_cur_pos(decl)):
                            continue
                        packed_groups[package_id + "|(swl)" + group_id] = True

                        group_content = []
                        for item in group_settings.get('children', []):
                            swl_path = self.swl_full_path(item)
                            # не делаем check_already_packed, но в packed_resources записываем
                            packed_resources[swl_path] = True

                            children_content = self.atlas_content_swl_by_path(swl_path, repack=True)
                            self.log_verbose("content %s" % tostr(children_content))
                            group_content.extend(children_content)

                        # Дополняем настройки атласа атрибутами из SWLGroup
                        pack_settings = {'reg_swl_sheets': True}
                        for k, v in group_settings.items():
                            if k in self._all_pack_settings_attrs or k.startswith("compress"):
                                if k not in decl.attrib:  # не перезаписываем
                                    pack_settings[k] = v

                        atlas_id = decl.get('id') or group_settings.get('atlasName') or group_id
                        add_atlas({'decl': decl, 'id': atlas_id, 'package_id': package_id,
                                   'group_id': group_id, 'content': group_content, 'template': 'swlgroup', 'pack_settings': pack_settings})

            # По шаблону resource="*"
            for res_id, content in sorted(self.atlas_content_resources(decl.get('resource')).items()):
                if check_already_packed(res_id, packed_resources, lxml_cur_pos(decl)):
                    continue
                add_atlas({'decl': decl, 'id': decl.get('id', res_id), 'package_id': package_attr, 'content': content,
                           'template': 'resource'})

            # По шаблону effect="*"
            for res_id, content in sorted(self.atlas_content_effects(decl.get('effect')).items()):
                if check_already_packed(res_id, packed_resources, lxml_cur_pos(decl)):
                    continue
                # Определяем, под каким именем сохранять атлас
                atlas_id = decl.get('id')
                if atlas_id is None:
                    if 'rel' in decl.attrib:  # Имя атласа берётся как имя файла солюшена относительно каталога rel
                        atlas_id = FileNameWithoutExt(normpath(os.path.relpath(res_id, decl.get('rel'))))
                    else:
                        atlas_id = os.path.basename(res_id)  # берём имя файла солюшена
                        atlas_id = FileNameWithoutExt(atlas_id)  # без расширения
                add_atlas({'decl': decl, 'id': atlas_id, 'package_id': package_attr, 'content': content, 'template': 'effect'})

            # По шаблону swl="*"
            for path, settings in sorted(self.atlas_content_swl(decl.get('swl')).items()):
                if check_already_packed(path, packed_resources, lxml_cur_pos(decl)):
                    continue
                # Перепаковываем атлас только если есть какие-то дополнительные настройки атласа
                repack = len({k: v for k, v in decl.attrib.items() if k in self._pack_settings_attrs}) > 0
                content = self.atlas_content_swl_by_path(path, repack)
                if not content:
                    self.log_skip("  don't pack %r" % path)
                    continue
                # Дополняем настройки атласа атрибутами из SWLGroup
                pack_settings = {'reg_swl_sheets': True}
                for k, v in settings.items():
                    if k in self._all_pack_settings_attrs or k.startswith("compress"):
                        if k not in decl.attrib:  # не перезаписываем
                            pack_settings[k] = v
                atlas_id = decl.get('id')
                if atlas_id is None:
                    if 'rel' in decl.attrib:  # Имя атласа берётся как имя файла солюшена относительно каталога rel
                        atlas_id = FileNameWithoutExt(normpath(os.path.relpath(path, decl.get('rel'))))
                    else:
                        atlas_id = os.path.basename(path)  # берём имя файла солюшена
                        atlas_id = FileNameWithoutExt(atlas_id)  # без расширения
                add_atlas({'decl': decl, 'id': atlas_id, 'package_id': package_attr, 'content': content, 'template': 'swl', 'pack_settings': pack_settings})

            # По шаблону dir="*"
            dir_v = decl.get('dir')
            if dir_v:
                for path in self.glob(os.path.join(self.repo_abs_path, dir_v)):
                    if not os.path.isdir(path):
                        continue
                    path = normpath(os.path.relpath(path, self.repo_abs_path))
                    self.log_debug("atlas template dir: %r" % (path))
                    if check_already_packed(path, packed_resources, lxml_cur_pos(decl)):
                        continue
                    # ~ TODO: искать все изображения? (png, jpg)
                    content = self.atlas_content_files(normpath(os.path.join(
                        path, "*.png")), lxml_cur_pos(decl), decl.get('type')).values()
                    if content:
                        # Определяем, под каким именем сохранять атлас
                        atlas_id = decl.get('id')
                        if atlas_id is None:
                            if 'rel' in decl.attrib:  # Имя атласа берётся как имя каталога относительно rel
                                atlas_id = normpath(os.path.relpath(path, decl.get('rel')))
                            else:
                                atlas_id = os.path.basename(path)  # берём имя директории
                        add_atlas({'decl': decl, 'id': atlas_id, 'package_id': package_attr, 'content': content, 'template': 'dir'})

        return atlases

    # Пост-обработка атласов - вычисляем настройки, фильтруем контент
    def prepare_atlas_settings(self, atlases):
        self.log_progress("prepare_atlas_settings")

        used_names = {}  # Проверяем, чтобы атласы не перезаписывали друг друга

        # Подготавливаем настройки и фильтруем содержимое атласов
        for item in atlases[:]:
            self.log_debug("prepare_atlas_settings: %s @ %s" % (item.get('id', ""), lxml_cur_pos(item['decl'])))

            decl = item['decl']
            atlas_id = item.get('id')

            package_id = item.get('package_id')
            if package_id is None:  # Детектируем package_id
                package_id = decl.get('package')  # он и так отсюда берётся, но на всякий случай
                if package_id is None:
                    package_id = self.package_id_from_resources(item.get('content'), lxml_cur_pos(decl))
                    if package_id:
                        self.log_debug("  package_id from res %r" % package_id)
                if package_id is None:
                    package_id = ''
                if package_id is not None:
                    item['package_id'] = package_id

            group_id = item.get('group_id')
            if group_id is None:
                item['group_id'] = group_id = ''

            if not self.check_filter_attrs(decl):
                self.log_skip("Skip atlas %r @ %s" % (atlas_id, lxml_cur_pos(decl)))
                atlases.remove(item)
                continue

            if 'pack_settings' not in item:
                item['pack_settings'] = {}
            pack_settings = item['pack_settings']
            preprocess_settings = []
            self.log_verbose(" %s pack_settings %r" % (atlas_id, pack_settings))
            self.calc_atlas_settings(decl, package_id, group_id, pack_settings, preprocess_settings)
            self.log_verbose(" %s pack_settings %r" % (atlas_id, pack_settings))
            if bool_attr(pack_settings.get('pack')) is False:
                self.log_skip("Don't pack atlas (pack=\"false\") %r @ %s" % (atlas_id, lxml_cur_pos(decl)))
                atlases.remove(item)
                continue

            # Делаем копию content, чтобы иметь возможность модифицировать атрибуты ресурсов
            if 'content' not in item or not isinstance(item['content'], list):
                self.log_error("Wrong atlas 'content': %r" % item)
                continue
            content = item['content']

            if content and len(content) == 1 and content[0].get('type') == 'effect':
                # Переносим настройки атласа из солюшена эффектов ('atlas_*')
                node = content[0]
                for attr, v in sorted(node.items()):
                    if attr.startswith('atlas_'):
                        _, k = attr.split("_", 1)  # убираем префикс atlas_
                        if k in self._all_pack_settings_attrs or re.match(r'^mask_', k):
                            pack_settings[k] = v
                            self.log_debug("  apply solution settings: %s = %r" % (k, v))

            self.collect_effect_textures(content, pack_settings, item)
            self.collect_model_textures(content)

            self.filter_content(content, preprocess_settings)

            if not content:
                if item.get('template'):
                    self.log_debug("Skip empty atlas %r: %s" % (atlas_id, lxml_cur_pos(decl)))
                else:
                    self.log_skip("Skip empty atlas %r: %s" % (atlas_id, lxml_cur_pos(decl)))
                atlases.remove(item)
                continue

            # Определяем директорию и имя файла для атласа
            out_name = self.atlas_output_name(item, pack_settings)
            if not out_name:
                self.log_error("No out_name for atlas %r: %s" % (atlas_id, lxml_cur_pos(decl)))
                atlases.remove(item)  # ничего не поделаешь
                continue
            item['out_name'] = out_name

            self.log_debug("  Atlas decl=%r, id=%r, package_id=%r, group_id=%r, out_name=%r, %r items",
                           lxml_cur_pos(item.get('decl')), item.get('id'), item.get('package_id'),
                           item.get('group_id'), item.get('out_name'), len(item.get('content', [])))

            # Проверяем, чтобы атласы не перезаписывали друг друга
            if out_name in used_names:
                self.log_error("Atlas name conflict: %r: %r vs %r",
                               out_name, lxml_cur_pos(decl), used_names[out_name])
            used_names[out_name] = lxml_cur_pos(decl)

        return atlases

    # Определяем директорию и имя файла для атласа
    def atlas_output_name(self, atlas, pack_settings):
        # ~ TODO: use templates https://docs.python.org/2/library/stdtypes.html#string-formatting
        out_name = pack_settings.get('out_name')  # Если в описании атласа задан out_name, то этого достаточно
        if out_name:
            self.log_debug("  out_name from 'out_name' = %r" % out_name)
            return out_name

        output_dir = pack_settings.get('out_dir', self.atlas_output_dir or "atlases")

        # Если атласы записываются в директории пакетов...
        atlas_output_dir_rel_package = bool_attr(pack_settings.get('atlas_rel_pkg', self.atlas_output_dir_rel_package), strict=False)
        package_id = atlas.get('package_id')
        package_dir = None
        if atlas_output_dir_rel_package and package_id:
            if package_id in self.package_id_to_path:
                package_dir = self.package_id_to_path[package_id]
                self.log_debug("  package_dir = %r" % package_dir)

            if isinstance(self.atlas_output_dir_rel_package, str):  # E.g. atlas_output_dir_rel_package = "atlases"
                output_dir = atlas_output_dir_rel_package
                self.log_debug("  atlas_output_dir_rel_package = %r" % output_dir)
            # Для каждого пакета задаётся своя директория для атласов (относительно repo_abs_path!)
            elif isinstance(atlas_output_dir_rel_package, dict):
                output_dir = atlas_output_dir_rel_package.get(package_id)
                # package_dir не прибавляется в этом случае!
                package_dir = None
                self.log_debug("  atlas_output_dir_rel_package[%r] = %r" % (package_id, output_dir))

            if package_dir:
                output_dir = normpath(os.path.join(package_dir, output_dir))
            else:
                output_dir = normpath(os.path.join(self.base_path, output_dir))
            self.log_debug("  output_dir rel package = " + output_dir)
        else:
            output_dir = normpath(os.path.join(self.base_path, output_dir))

        # Поддиректория в директории атласов
        if 'subdir' in pack_settings:
            # поддиректория в директории атласов
            output_dir = normpath(os.path.join(output_dir, pack_settings['subdir']))
            self.log_debug("  output_dir from subdir = %r" % output_dir)
        elif (self.atlas_output_subdir_package_id or bool_attr(pack_settings.get('subdir_pkg'))) and package_id:
            # в output_dir создаётся поддиректория для каждого пакета (по его id)
            output_dir = normpath(os.path.join(output_dir, package_id))
            self.log_debug("  atlas_output_subdir_package_id: output_dir = %r" % output_dir)

        # Определяем имя файла для атласа
        atlas_id = atlas.get('id')
        if atlas_id is not None:
            prefix = pack_settings.get('prefix')
            if prefix:
                out_name = prefix + atlas_id
            else:
                out_name = atlas_id

        if 'atlasName' in pack_settings:  # имя файла для атласа задано явно
            out_name = pack_settings['atlasName']
            self.log_debug("  out_name from 'atlasName' = %r" % out_name)

        if out_name:
            out_name = normpath(os.path.join(output_dir, out_name))

        self.log_debug("  out_name = %r" % out_name)

        return out_name

    def _copy_content_attrs(self, res_content, attrs, dbg_info=""):
        for attr, v in sorted(attrs.items()):
            if attr.startswith(self.platform + "_"):  # для атрибутов типа android_pack="false"
                if not dbg_info:
                    dbg_info = "%r" % attr
                attr = attr[len(self.platform) + 1:]  # отрезаем префикс платформы
            if attr in self._content_pack_attrs or attr.startswith("compress"):
                for item in res_content:
                    item[attr] = v
                    if dbg_info:
                        self.log_debug("  update %r %r from %s: %s = %r", item.get('id'), item.get('full_path'), dbg_info, attr, v)

    # Пакуем все атласы
    def pack_all_atlases(self, atlases=None):
        with self.log_section("pack_all_atlases", LOG_PROGRESS):
            # Рассчитываем настройки атласов
            if atlases is None:
                atlases = self.prepare_atlases()

            for item in atlases[:]:  # ~ TODO: распараллелить?
                if self.only_package is not None and not self.check_group(item.get('package_id'), self.only_package):
                    continue
                if self.only_group is not None and not self.check_group(item.get('group_id'), self.only_group):
                    continue
                if self.only_atlas is not None and not self.check_group(item.get('id'), self.only_atlas):
                    continue

                self.pack_atlas(pack_settings=item['pack_settings'], content=item['content'],
                                atlas_id=item.get('id'), package_id=item.get('package_id'), group_id=item.get('group_id'),
                                out_name=item.get('out_name'), loc=lxml_cur_pos(item['decl']))

    # Проверяет выполнение условий-фильтров в xml ноде
    def check_filter_attrs(self, node, pack_settings=None, package_id=None):
        platform = node.get('platform')
        if platform is not None:
            if not self.wildcard_match(platform, self.platform):
                # ~ self.log_verbose("  check_filter_attrs platform %r != %r" % (platform, self.platform))
                return False

        if package_id is not None:
            package = node.get('package')
            if package is not None:
                if not self.wildcard_match(package, package_id):
                    # ~ self.log_verbose("  check_filter_attrs package %r != %r" % (package, package_id))
                    return False

        if pack_settings is not None:
            for key in ('poly', 'cube'):  # for_poly, for_cube
                expect = node.get('for_' + key)
                if expect is not None:
                    if bool_attr(expect) != bool_attr(pack_settings.get(key)):
                        # ~ self.log_verbose("  check_filter_attrs 'for_%s': %r != %r" % (key, expect, pack_settings.get(key)))
                        return False
            for key in ('swl', 'swlgroup'):  # for_swl, for_swlgroup
                expect = node.get('for_' + key)
                if expect is not None:
                    if pack_settings.get('template') != key:
                        # ~ self.log_verbose("  check_filter_attrs 'for_%s': %r != %r" % (key, expect, pack_settings.get(key)))
                        return False

            for_compress = node.get('for_compress')
            if for_compress is not None:
                compress = pack_settings.get('compress')
                if isinstance(compress, dict):
                    fmt = compress.get('format')
                    if (not self.wildcard_match(for_compress, fmt)
                            and not self.wildcard_match(for_compress, self.get_base_compress_format(fmt))):
                        # ~ self.log_verbose("  check_filter_attrs platform %r != %r (%r)",
                        # ~                  for_compress, fmt, self.get_base_compress_format(fmt))
                        return False
                else:
                    if compress:
                        self.log_error("Unexpected 'compress' value: %r" % compress)
        return True

    # Проверяет выполнение условий-фильтров в xml ноде для конкретного файла (image_path) или ресурса (res_id)
    def check_filter_attrs_ps(self, node, image_path, resource=None):
        file_v = node.get('file')
        folder = node.get('folder')
        if file_v is not None:
            if folder:
                file_v = normpath(os.path.join(folder, file_v))
            if not self.wildcard_match(file_v, image_path):
                # ~ self.log_verbose("  check_filter_attrs_ps file %r !~ %r" % (image_path, file_v))
                return False
        elif folder is not None:
            folder = normpath(folder)
            if not folder.endswith('/'):
                folder += '/'  # иначе проверка через commonprefix будет работать не так, как надо
            if os.path.commonprefix([image_path, folder]) != folder:
                # ~ self.log_verbose("  check_filter_attrs_ps folder %r !~ %r" % (image_path, folder))
                return False
        if resource:
            resource_id = node.get('resource_id')
            if resource_id is not None:
                if not self.wildcard_match(resource_id, resource.get('id', "")):
                    # ~ self.log_verbose("  check_filter_attrs_ps resource_id %r != %r" % (res_id, resource_id))
                    return False
            type_v = node.get('type')
            if type_v and type_v != resource.get('type'):
                return False
        return True

    # Получаем текстуры из эффектов в атласе
    def collect_effect_textures(self, content, pack_settings, atlas):
        package_id = atlas.get('package_id')
        pma = get_exact_setting(pack_settings)

        effect_params = pyscript.Effect.EffectConvertParams()

        filterHidden = pack_settings.get('effect_filter_hidden')
        if filterHidden:
            if filterHidden.lower() == 'nohidden' or bool_attr(filterHidden, strict=False) is True:
                effect_params.filterHidden = pyscript.Effect.FilterHidden.NoHidden
            elif filterHidden.lower().startswith('only'):
                effect_params.filterHidden = pyscript.Effect.FilterHidden.OnlyHiden
            elif filterHidden.lower() == 'nofilter':
                effect_params.filterHidden = pyscript.Effect.FilterHidden.NoFilter
            else:
                self.log_error('Unexpected value for "effect_filter_hidden" attribute: %r' % filterHidden)

        filterPMA = pack_settings.get('effect_filter_pma')
        if filterPMA:
            if filterPMA.lower() == 'nopma' or bool_attr(filterPMA, strict=False) is True:
                effect_params.filterPMA = pyscript.Effect.FilterPMA.NoPMA
            elif filterPMA.lower().startswith('only'):
                effect_params.filterPMA = pyscript.Effect.FilterPMA.OnlyPMA
            elif filterPMA.lower() == 'nofilter':
                effect_params.filterPMA = pyscript.Effect.FilterPMA.NoFilter
            else:
                self.log_error('Unexpected value for "effect_filter_pma" attribute: %r' % filterPMA)

        effect_params.imageDownscaleThreshold = int(pack_settings.get('effect_downscale_thr', effect_params.imageDownscaleThreshold))
        effect_params.trimImages = False;  # Не используем, т.к. trim мешает полигональным атласам.

        # Вспомогательные функции для монтирования
        self.mounted_dir = None  # в self, чтобы иметь общую переменную для вложенных функций ниже

        def unmount():
            if self.mounted_dir is not None:
                mount_base = os.path.abspath(os.path.join(self.repo_abs_path, self.mounted_dir))
                self.log_verbose("  unmount %r" % mount_base)
                pyscript.UnmountDirectory(mount_base)
                self.mounted_dir = None

        def mount(base_path):
            if self.mounted_dir == base_path:
                return

            unmount()

            mount_base = os.path.abspath(os.path.join(self.repo_abs_path, base_path))
            self.log_verbose("  mount %r" % mount_base)
            pyscript.MountDirectory(mount_base)

            self.mounted_dir = base_path

        if self.main_base:
            pyscript.MountDirectory(os.path.join(self.repo_abs_path, self.main_base))

        pyscript.MountDirectory(os.path.join(self.repo_abs_path, self.base_path))

        for item in content[:]:  # итерируемся по копии, чтобы делать remove
            if item.get('type') == 'effect':
                full_path = item.get('full_path')

                self.log_debug("collect_effect_textures %r: %r" % (item.get('id'), full_path))

                base_path = self.base_path
                node = item.get('node')
                if node is not None:
                    base_path = node.get('_base_path', base_path)

                if self.resources_rel_package and package_id and package_id in self.package_id_to_path:
                    # Пути к ресурсам указываются относительно пакета (TS)
                    base_path = self.package_id_to_path[package_id]

                #~ effects[base_path].append(item)

                content.remove(item)

                if base_path != self.base_path and base_path != self.main_base:
                    mount(base_path)

                textures = pyscript.Effect.EffectGetTextureInfoFromXml([normpath(os.path.join(self.repo_abs_path, full_path))], effect_params)
                
                # Используем EffectGetPImagesFromTextureInfo(), т.к. он умеет правильно масштабировать текстуры.
                # Иначе всю инфу можно было бы взять из EffectGetTextureInfoFromXml.
                effect_pimages = pyscript.Effect.EffectGetPImagesFromTextureInfo(textures, effect_params)
                effect_textures = self.content_from_pimages(effect_pimages, base_path, item.get('groupId'), item.get('package'), full_path)

                for i, info in enumerate(textures): # info is TextureInfo{...}
                    # Адский костыль:
                    # К сожалению, EffectGetPImagesFromTextureInfo возвращает хрень вместо path.
                    # Но зато правильный path есть в EffectGetTextureInfoFromXml, берём его оттуда.
                    assert effect_textures[i]['id'] == info.name, info.name  # на всякий случай
                    effect_textures[i]['full_path'] = normpath(os.path.relpath(info.path, self.repo_abs_path))

                    # ~ TODO: checks https://github.com/Playrix/mansion-makeover/blob/af8f625bdf2b3813192fa93b806650fa3bdccbd3/utils/resbuilder/hseffects.py#L107
                    # if (info.sizeFormat == pyscript.Effect.TextureSizeFormat.x2) and not setting.retina:
                    #    hsteamcity.error('Undeclared retina texture ' + info.name)
                    #    hseffects.debug_texture(solution, info)

                    if info.premultipliedAlpha and not pma:
                        self.log_error("'pma' specified for image %r in effect %r %r @ %s, but not for atlas %r @ %s",
                                       info.name, item.get('id'), full_path, item.get('@loc'), atlas.get('id'), lxml_cur_pos(atlas.get('decl')))

                    # if info.premultipliedAlpha != (os.path.basename(info.path).find('_blendadd') >= 0 or os.path.basename(info.path).find('_pma') >= 0):

                # Переносим настройки упаковки из описания эффекта
                self._copy_content_attrs(effect_textures, item)
                for res in effect_textures:
                    self.log_debug("  content %s" % tostr(res))
                content.extend(effect_textures)
                
        unmount()
        
        if self.main_base:
            pyscript.UnmountDirectory(os.path.join(self.repo_abs_path, self.main_base))

        pyscript.UnmountDirectory(os.path.join(self.repo_abs_path, self.base_path))
    #

    def content_from_pimages(self, pimages, base_path, group=None, package=None, loc=""):
        if base_path is None:
            base_path = self.base_path
        content = []
        for pimage in pimages:
            if pimage.ix != 0 or pimage.iy != 0 or pimage.iw != pimage.w or pimage.ih != pimage.h:
                # Не должно такого быть, мы специально делали trimImages = False выше
                self.log_error("should not be trimmed: %s %r %r,%r %r,%r,%r,%r", loc, pimage.path, pimage.w, pimage.h, pimage.ix, pimage.iy, pimage.iw, pimage.ih); 
            res = {}
            res['@loc'] = loc  # xml path
            res['type'] = 'texture'
            res['image'] = pimage.img  # Используем загруженную текстуру. Она ещё и правильно отмасштабирована, что важно.
            res['id'] = pimage.id
            res['path'] = pimage.path
            res['full_path'] = normpath(os.path.join(base_path, pimage.path))
            if pimage.prescale_x != 1.0:
                res['prescale_x'] = pimage.prescale_x
            if pimage.prescale_y != 1.0:
                res['prescale_y'] = pimage.prescale_y
            if pimage.joinLeft:
                res['joinLeft'] = pimage.joinLeft
            if pimage.joinRight:
                res['joinRight'] = pimage.joinRight
            if pimage.joinTop:
                res['joinTop'] = pimage.joinTop
            if pimage.joinBottom:
                res['joinBottom'] = pimage.joinBottom
            res['pma'] = pimage.premultipliedAlpha;
            if group is not None:
                res['groupId'] = group
            if package:
                res['package'] = package
            content.append(res)
        return content

    # Вычисляем настройки для отдельных ресурсов.
    # Заодно исключаем ресурсы, у которых pack="false".
    def filter_content(self, content, preprocess_settings):
        self.log_debug("filter_content")

        for item in content[:]:  # итерируемся по копии, чтобы делать remove
            assert isinstance(item, dict), item

            if item.get('type') == 'effect':
                # Эффекты должны быть распакованы в текстуры в функции collect_effect_textures()
                self.log_error("Unexpected effect in filter_content: %r %s", item.get('path'), item.get('@loc'));
                continue

            full_path = item['full_path']  # (путь относительно repo_abs_path)

            # Применяем настройки, указанные для отдельных файлов в теге <preprocess>
            if preprocess_settings:
                for node in preprocess_settings:
                    if self.check_filter_attrs_ps(node, full_path, item):
                        self._copy_content_attrs([item], node, node.get('@loc'))

            # Выкидываем текстуры с pack=false
            if bool_attr(item.get('pack')) is False:
                content.remove(item)
                self.log_debug("  skip: pack = false: %r %r" % (item.get('id'), item['full_path']))
                continue

            # Проверяем существование файла
            if not os.path.exists(os.path.join(self.repo_abs_path, full_path)) and not item.get('image'):
                self.log_error("File not found (%r): %r @ %s" % (item.get('id'), full_path, item.get('@loc')))
                continue

    # Упаковка атласа по описанию в xml (decl = <Atlas>)
    def pack_atlas(self, pack_settings, content, atlas_id=None, package_id=None, group_id=None, out_name=None, loc=""):
        with self.log_section("pack_atlas: %r" % (atlas_id), LOG_PROGRESS):
            assert pack_settings is not None, loc

            if out_name is None:
                out_name = pack_settings.get('out_name')  # Рассчитывается в prepare_atlas_settings
            if not out_name:
                self.log_error("No out_name @ %s" % loc)
                return

            if not content:
                self.log_skip("Empty atlas %r (%r) @ %s" % (atlas_id, package_id, loc))
                return

            # Предварительно вычисляем настройки сжатия
            compress_settings = self.calc_compress_settings(pack_settings.get('compress'), loc,
                    out_name, package_id, group_id, {'type': 'atlas'})  # noqa: E128 (indent)

            res = None
            out_sheets = None
            out_files = None
            from_cache = False

            # Check cache
            cache_id = "Atlas|" + out_name
            chash = None
            if self.cache is None and self.cache_path:
                self.init_cache()
            if self.cache and not self.dry_run:
                # Вычисляем хэш
                # Если self.compress_atlas_immediately = True, то добавляем в хэш настройки сжатия,
                # так как результат сжатия будет записан как результат упаковки атласа.
                chash = self.compute_pack_hash(pack_settings, content, compress_settings if self.compress_atlas_immediately else None)
                self.log_debug("cache hash: %r" % chash)
                # Проверяем кэш
                with self.cache_lock:
                    cache_checkout = self.cache.checkout(cache_id, chash)
                    if cache_checkout:
                        out_sheets = []
                        for f in cache_checkout:
                            self.log_debug("Cache checkout: %r" % f)
                            # Выделяем xml для регистрации в AtlasResources.xml
                            (f, ext) = os.path.splitext(f)
                            if ext == '.xml':
                                out_sheets.append(f)
                        if not out_sheets:
                            self.log_error("No sheets in cache checkout: %r" % out_name)
                        self.cache.save()
                        # Удаляем старые файлы (но не взятые из кэша)
                        for f in self.find_atlas_files(self.dst_abs_path, out_name):
                            if f not in cache_checkout:
                                self.log_write("Remove old file: %r" % f)
                                if not self.dry_run:
                                    os.remove(os.path.join(self.dst_abs_path, f))
                        out_files = cache_checkout[:]
                        res = (out_sheets, out_files)
                        from_cache = True
                    else:
                        # Если dst_abs_path совпадает с out_cache_path, то следующие действия испортят кэш, поэтому удаляем из кэша.
                        if self.cache.out_cache_path == self.dst_abs_path and not self.copy_only:
                            self.cache.delete(cache_id)
                            self.cache.save()

            if not res and self.copy_only:
                self.log_skip("(changed) Don't copy %r" % out_name)
                return

            if not res:
                if self.on_pack_atlas_start:  # callback
                    try:
                        self.on_pack_atlas_start(atlas_id, package_id, group_id, out_name, pack_settings, compress_settings, content, loc)
                    except Exception:
                        self.log_error("Error in callback 'on_pack_atlas_start': %r" % sys.exc_info())
                
                res = self.pack_atlas_impl(pack_settings, compress_settings, content, atlas_id, package_id, group_id, out_name, loc)
                if res:
                    (out_sheets, out_files) = res
                    # cache
                    if self.cache and not self.dry_run:
                        with self.cache_lock:
                            self.cache.delete(cache_id)
                            for f in out_files:
                                assert f.find('\\') == -1, f
                                self.cache.copy_file(os.path.join(self.dst_abs_path, f), self.cache.get_out_location(f))
                            self.cache.update(cache_id, chash, out_files)
                            self.cache.save()

            if res:
                # Записываем атлас в AtlasResources.xml
                self.register_sheets(out_sheets, out_name, atlas_id, package_id, group_id, pack_settings, loc)

                if bool_attr(pack_settings.get('reg_swl_sheets')):
                    # Записываем в SwlSheets.xml
                    self.register_swl_sheets(out_files, self.dst_abs_path, pack_settings, package_id)

            if self.on_pack_atlas_end:  # callback
                try:
                    self.on_pack_atlas_end(atlas_id, package_id, group_id, out_name, from_cache, out_sheets, out_files, loc)
                except Exception:
                    self.log_error("Error in callback 'on_pack_atlas_end': %r" % sys.exc_info())

    # Упаковка атласа - реализация
    def pack_atlas_impl(self, pack_settings, compress_settings, content, atlas_id, package_id, group_id, out_name, loc):
        self.log_progress("Pack atlas %r (%s) to %r @ %r" % (atlas_id, package_id, out_name, loc))

        self.log_debug("pack_settings = %s" % tostr(pack_settings))

        assert pack_settings is not None, loc

        if not content:
            self.log_skip("Empty atlas %r (%s) %r @ %s" % (atlas_id, package_id, out_name, loc))
            return

        if not out_name:
            self.log_error("No out_name @ %s" % loc)
            return

        # Настройки для упаковщика
        ps = GX.PackSettings()
        ps.max_width = int(next((pack_settings[key]
                                 for key in ('width', 'size') if key in pack_settings), ps.max_width))
        ps.max_height = int(next((pack_settings[key]
                                  for key in ('height', 'size') if key in pack_settings), ps.max_height))
        ps.advanced_atlas_alignment = int(pack_settings.get('round_size', ps.advanced_atlas_alignment))
        pot = bool_attr(pack_settings.get('pot', None))
        if bool_attr(pack_settings.get('cube')):
            if pot is None:
                pot = True
        if pot is None:  # Если явно не указан, то определяем автоматически по формату сжатия
            pot = self.detect_pot(compress_settings, ps.need_square_and_pot)
            if pot != ps.need_square_and_pot:
                self.log_debug("detect_pot %r" % (pot))
        ps.need_square_and_pot = pot
        ps.round = int(pack_settings.get('round', ps.round))
        detect_trim_pot = self.detect_trim_pot(compress_settings)
        if bool_attr(pack_settings.get('strict_size', ps.strict_size)):
            detect_trim_pot = False
        if detect_trim_pot is True:
            ps.trim_square_and_pot = True  # detected by compress_settings
        ps.trim_square_and_pot = bool_attr(pack_settings.get('trim', ps.trim_square_and_pot))
        processing = pack_settings.get('processing')
        if processing:
            ps.target_processing = ps.target_processing.names[processing]
        # на самом деле используется gap. padding_invisible - второстепенный параметр
        ps.padding_invisible = int(pack_settings.get('padding', ps.padding_invisible))
        ps.advanced_side_max_div = float(pack_settings.get('side_div', ps.advanced_side_max_div))
        ps.advanced_max_number_divisions = int(pack_settings.get('max_divisions', ps.advanced_max_number_divisions))
        # Вычисляем advanced_max_number_divisions через split_min_size
        split_min_size = pack_settings.get('split_min_size')
        if split_min_size is not None:
            split_min_size = int(split_min_size)
            size = min(ps.max_width, ps.max_height)
            ps.advanced_max_number_divisions = 0
            while (size // 2) >= split_min_size and size >= 0:
                ps.advanced_max_number_divisions += 1
                size //= 2
            self.log_debug("ps.advanced_max_number_divisions from split_min_size: %r", ps.advanced_max_number_divisions)

        # Добавляем остальные атрибуты, которые есть в PackSettings:
        for key in dir(ps):
            if key in pack_settings:
                attr_type = type(getattr(ps, key))  # Конвертируем в тот тип, который нужен PackSettings
                if attr_type == bool:
                    setattr(ps, key, bool_attr(pack_settings[key]))
                    self.log_verbose("ps.%s = %r = bool_attr(%r)", key, getattr(ps, key), pack_settings[key])
                else:
                    setattr(ps, key, attr_type(pack_settings[key]))
                    self.log_verbose("ps.%s = %r = %r(%r)", key, getattr(ps, key), attr_type, pack_settings[key])
        # Note: все проверки полей ps нужно делать после этого цикла

        if bool_attr(pack_settings.get('cube')):
            if not ps.strict_size:
                self.log_error("Strict size is required for cube atlas @ %s" % loc)
            ps.strict_size = True
            ps.max_sheets = int(pack_settings.get('max_sheets', 6))
            if ps.max_sheets > 6:
                self.log_warning("Max sheets for cube atlas is 6 @ %s" % loc)
                ps.max_sheets = 6
            if not ps.need_square_and_pot and self.require_cube_pot:
                self.log_error("Cube atlas is required to be power-of-two (old hardware limitation) @ %s" % loc)

        if ps.trim_square_and_pot and (detect_trim_pot is False):
            self.log_error("trim_square_and_pot (trim) is not good for POT compress format %r @ %s" % (compress_settings, loc))

        self.log_debug("ps: %s" % tostr(ps))

        # Создаём директорию при необходимости
        self.ensure_dir(os.path.dirname(out_name))

        base_dir = self.base_path
        if self.resources_rel_package and package_id and package_id in self.package_id_to_path:
            base_dir = self.package_id_to_path.get(package_id)  # rel package dir (TS)

        # Process images
        pimages = []
        pimage_by_path = {}  # pimage_by_path[path] = [pimage,..] - обрабатываем ситуацию, когда текстура попадает в атлас несколько раз
        for item in content:
            image_path = item['full_path']  # (путь относительно repo_abs_path)
            self.log_debug("process image: %r %r" % (item.get('id'), utf8_encode(image_path)))

            # Вспомогательная функция собирает настройки из pack_settings и атрибутов item
            # Дополнительно можно передать лямбды для преобразования атрибутов.
            def extract_settings(settings_name, default, *argv):
                # ~ self.log_debug("extract_settings %r" % (settings_name))
                # Приоритет имеют настроки в описании ресурса, затем pack_settings.
                v = extract_settings_impl(item, "item", settings_name, *argv)
                if v is not None:
                    return v
                v = extract_settings_impl(pack_settings, "pack_settings", settings_name, *argv)
                if v is not None:
                    return v
                return default

            def extract_settings_impl(d, d_name, settings_name, *argv):
                if not d:
                    return None
                v = d.get(settings_name)
                if v is not None:
                    # ~ self.log_debug("  %r from %s = %r" % (settings_name, d_name, v))
                    return v
                for item_f in argv:  # <texture ... noCut="true" />
                    if isinstance(item_f, str):  # attr_name
                        v = d.get(item_f)
                        if v is not None:
                            self.log_debug("  %r from %s %r = %r" % (settings_name, d_name, item_f, v))
                            return v
                    elif callable(item_f):  # lambda
                        v = item_f()
                        if v is not None:
                            self.log_debug("  %r from %s lambda = %r" % (settings_name, d_name, v))
                            return v
                    # if item_f is tuple(attr_name, lambda)
                    elif isinstance(item_f, tuple) and len(item_f) == 2 and isinstance(item_f[0], str) and callable(item_f[1]):
                        x = d.get(item_f[0])
                        if x is not None:
                            v = item_f[1](x)
                            if v is not None:
                                self.log_debug("  %r from %s lambda(%r) = %r", settings_name, d_name, x, v)
                                return v
                    else:
                        self.log_error('extract_settings %s %r: wrong argument: %r' % (d_name, settings_name, item_f))
                    if v is not None:
                        return v
                return None

            # Вычисляем некоторые настройки, нужные для PImage.CreateFrom
            needRectangle = bool_attr(extract_settings('needRectangle', False, 'needRect', 'need_rect'))
            noCut = bool_attr(extract_settings('noCut', False, ('cut', lambda v: not bool_attr(v))))
            alpha_threshold = int(extract_settings('alpha_threshold', ps.alpha_limit, 'thr'))
            if ps.poly:
                alpha_threshold = max(alpha_threshold, ps.alpha_limit)

            if item.get('image'):
                image = item['image']
            else:
                # Загружаем изображение
                if not os.path.exists(os.path.join(self.repo_abs_path, image_path)):
                    self.log_error("File not found (%r): %r @ %r" % (item.get('id'), image_path, item.get('@loc')))
                    continue
                image = Image.CreateFromFile(utf8_encode(os.path.join(self.repo_abs_path, image_path)))
            if image.w <= 0 or image.h <= 0:
                self.log_error("Failed to read image (%r): %r" % (item.get('id'), image_path))
                continue

            pimage = Packer.PImage()
            pimage.img = image;

            pimage.id = utf8_encode(item['id'])
            pimage.path = utf8_encode(normpath(os.path.relpath(image_path, base_dir)))
            pimage.idx = len(pimages)
            if 'groupId' in item:
                pimage.group_id = item['groupId']
            pimage.needRectangle = needRectangle
            pimage.noCut = noCut
            pimage.alpha_limit = alpha_threshold  # уровень обрезки для poly
            pimage.round = ps.round
            pimage.pack_separate = bool_attr(extract_settings('pack_separate', False))

            # add - расширение текстуры, например, для шейдера обводки  ##
            self.parse_direction(extract_settings('add', None), pimage.add)

            # join - определяем необходимость дублирования границы для стыковки текстур  ##
            # возвращает Direction с 1 или 0 вместо bool или None
            join = self.parse_direction(extract_settings('join', None))
            if ps.poly and needRectangle:
                join = self.parse_direction(extract_settings('join_rect', None), join)
            joinLeft = bool_attr(extract_settings('joinLeft', join and join.left != 0))
            joinRight = bool_attr(extract_settings('joinRight', join and join.right != 0))
            joinTop = bool_attr(extract_settings('joinTop', join and join.top != 0))
            joinBottom = bool_attr(extract_settings('joinBottom', join and join.bottom != 0))

            # автоматическое определение, будет ли текстура стыковаться, по примыканию изображения к границе
            rect = pyscript.GetTrimBox(image.SrcA(), pimage.alpha_limit)
            if joinLeft:
                joinLeft = (rect.x == 0) and (pimage.add.left == 0)
            if joinRight:
                joinRight = (rect.x + rect.w == image.w) and (pimage.add.right == 0)
            if joinTop:
                joinTop = (rect.y + rect.h == image.h) and (pimage.add.top == 0)
            if joinBottom:
                joinBottom = (rect.y == 0) and (pimage.add.bottom == 0)

            # border from prescale
            prescale = extract_settings('prescale', 1.0)
            prescale_x = float(extract_settings('prescale_x', prescale))
            prescale_y = float(extract_settings('prescale_y', prescale))
            pimage.prescale_x = prescale_x  # actually unused in GX.Pack
            pimage.prescale_y = prescale_y
            # Размер логического пикселя с учетом масштаба отрисовки (нужно для retina)
            unit_x = max(1, int(round(1.0 / prescale_x)))
            unit_y = max(1, int(round(1.0 / prescale_y)))

            # Для retina атласа возможен downscale
            # ~ TODO: check against compress settings
            downscaleRetina = bool_attr(extract_settings('downscaleRetina', False))
            pimage.downscaleRetina = downscaleRetina  # actually unused in GX.Pack
            if downscaleRetina:
                unit_x = max(unit_x, 2)
                unit_y = max(unit_y, 2)
            if ps.target_processing == GX.Preprocessing.Hardware:  # Разведение для блоков 4x4:
                unit_x = max(unit_x, 2)
                unit_y = max(unit_y, 2)

            #  dup - дублирующая рамка для стыковки текстур
            # Расчет повтора стыкующихся границ текстуры (CLAMP_TO_EDGE)
            if joinLeft:
                pimage.dup.left = unit_x
            if joinRight:
                pimage.dup.right = unit_x
            if joinTop:
                pimage.dup.top = unit_y
            if joinBottom:
                pimage.dup.bottom = unit_y
            if ps.target_processing == GX.Preprocessing.WebpLossy:  # Webp портит 1 пиксель
                if joinLeft:
                    pimage.dup.left += 1
                if joinRight:
                    pimage.dup.right += 1
                if joinTop:
                    pimage.dup.top += 1
                if joinBottom:
                    pimage.dup.bottom += 1
            # не перезаписывает предыдущие значения, если в настройках ничего не задано
            self.parse_direction(extract_settings('dup', None), pimage.dup)

            if joinLeft:
                pimage.joinLeft = (pimage.dup.left > 0)
            else:
                pimage.dup.left = 0
            if joinRight:
                pimage.joinRight = (pimage.dup.right > 0)
            else:
                pimage.dup.right = 0
            if joinTop:
                pimage.joinTop = (pimage.dup.top > 0)
            else:
                pimage.dup.top = 0
            if joinBottom:
                pimage.joinBottom = (pimage.dup.bottom > 0)
            else:
                pimage.dup.bottom = 0

            # gap - зазоры по бокам текстуры
            pimage.gap.left = unit_x
            pimage.gap.right = unit_x
            pimage.gap.top = unit_y
            pimage.gap.bottom = unit_y
            # не перезаписывает предыдущие значения, если в настройках ничего не задано
            self.parse_direction(extract_settings('gap', None, 'padding'), pimage.gap)
            # используем 'padding' как синоним 'gap', если 'gap' не задан.

            dup_in_gap = bool_attr(extract_settings('dup_in_gap', False))
            # Вычитаем обводку из gap (TS).
            # Это может привести к повржедению обводки при сжатии, зато даёт более компактную упаковку.
            # Обычно никаких проблем от этого не возникает.
            if dup_in_gap:
                pimage.gap.left = max(pimage.gap.left - pimage.dup.left, 0)
                pimage.gap.right = max(pimage.gap.right - pimage.dup.right, 0)
                pimage.gap.bottom = max(pimage.gap.bottom - pimage.dup.bottom, 0)
                pimage.gap.top = max(pimage.gap.top - pimage.dup.top, 0)

            if ps.poly:  # gap не должен быть меньше padding_invisible
                padding_invisible = ps.padding_invisible
                if padding_invisible == 0:
                    padding_invisible = 1
                    if pimage.downscaleRetina and not pimage.needRectangle:
                        padding_invisible = 2
                pimage.gap.left = max(pimage.gap.left, padding_invisible)
                pimage.gap.right = max(pimage.gap.right, padding_invisible)
                pimage.gap.top = max(pimage.gap.top, padding_invisible)
                pimage.gap.bottom = max(pimage.gap.bottom, padding_invisible)

            # transparencyFixRadius - прозрачная обводка
            pimage.transparencyFixRadius = max(2, max(unit_x, unit_y))
            if ps.target_processing == GX.Preprocessing.WebpLossy:  # Webp портит 1 пиксель
                pimage.transparencyFixRadius += 1

            pimage.transparencyFixRadius = int(extract_settings('fix', pimage.transparencyFixRadius))

            # premultipliedAlpha влияет на необходимость чистить альфу
            pimage.premultipliedAlpha = bool_attr(extract_settings('pma', False, 'blendAdd', 'exact'))
            # ~ TODO: check suffix for pma?
            if pimage.premultipliedAlpha and not get_exact_setting(pack_settings):
                self.log_warning("'pma' specified for image %r: %r @ %s  but not for atlas %r: %r @ %s" % (
                    item.get('id'), image_path, item.get('@loc'), atlas_id, out_name, loc))

            if extract_settings('addressMode', "").upper() == "REPEAT":
                self.log_error("Textures with addressMode=\"REPEAT\" %r: %r @ %s  should not be packed to atlas %r: %r @ %s" %(
                    item.get('id'), image_path, item.get('@loc'), atlas_id, out_name, loc))

            # Проверяем текстуры с одинаковым путём (но могут отличаться параметрами)
            if image_path in pimage_by_path:

                if not pimage.pack_separate:
                    # Мёржим настройки текстур с одинаковым путем, чтобы по возможности можно было обойтись одним изображением в атласе.
                    for pimg_prev in  pimage_by_path[image_path]:
                        if pimg_prev.pack_separate:
                            continue

                        pimage.prescale_x = pimg_prev.prescale_x = min(pimage.prescale_x, pimg_prev.prescale_x)
                        pimage.prescale_y = pimg_prev.prescale_y = min(pimage.prescale_y, pimg_prev.prescale_y)
                        
                        pimage.needRectangle = pimg_prev.needRectangle = (pimage.needRectangle or pimg_prev.needRectangle)
                        pimage.noCut = pimg_prev.noCut = (pimage.noCut or pimg_prev.noCut)
                        
                        pimage.add.left = pimg_prev.add.left = max(pimage.add.left, pimg_prev.add.left)
                        pimage.add.right = pimg_prev.add.right = max(pimage.add.right, pimg_prev.add.right)
                        pimage.add.top = pimg_prev.add.top = max(pimage.add.top, pimg_prev.add.top)
                        pimage.add.bottom = pimg_prev.add.bottom = max(pimage.add.bottom, pimg_prev.add.bottom)
                        
                        pimage.dup.left = pimg_prev.dup.left = max(pimage.dup.left, pimg_prev.dup.left)
                        pimage.dup.right = pimg_prev.dup.right = max(pimage.dup.right, pimg_prev.dup.right)
                        pimage.dup.top = pimg_prev.dup.top = max(pimage.dup.top, pimg_prev.dup.top)
                        pimage.dup.bottom = pimg_prev.dup.bottom = max(pimage.dup.bottom, pimg_prev.dup.bottom)
                        
                        pimage.gap.left = pimg_prev.gap.left = max(pimage.gap.left, pimg_prev.gap.left)
                        pimage.gap.right = pimg_prev.gap.right = max(pimage.gap.right, pimg_prev.gap.right)
                        pimage.gap.top = pimg_prev.gap.top = max(pimage.gap.top, pimg_prev.gap.top)
                        pimage.gap.bottom = pimg_prev.gap.bottom = max(pimage.gap.bottom, pimg_prev.gap.bottom)
                        
                        pimage.transparencyFixRadius = pimg_prev.transparencyFixRadius = max(pimage.transparencyFixRadius, pimg_prev.transparencyFixRadius)
                        pimage.round = pimg_prev.round = max(pimage.round, pimg_prev.round)
                
                pimage_by_path[image_path].append(pimage)
                
                if pimage.id == pimg_prev.id:
                    self.log_debug("  remove duplicate: %r %r" % (pimage.id, image_path))
                    continue
            else:
                pimage_by_path[image_path] = [ pimage ]

            pimages.append(pimage)

        if len(pimages) == 0:
            self.log_skip("No images to pack")
            return

        # do preprocessing
        for pimage in pimages:
            if pimage.iw == 0:
                # Пересчитываем rect, т.к. настройки needRectangle могли измениться при мёрже
                if (ps.poly and not pimage.needRectangle) or pimage.noCut:
                    rect = pimage.img.GetRect()
                else:
                    rect = pyscript.GetTrimBox(pimage.img.SrcA(), pimage.alpha_limit)
                pimage.iw = rect.w;
                pimage.ih = rect.h;
                pimage.ix = rect.x;
                pimage.iy = rect.y;
                pimage.w = pimage.img.w;
                pimage.h = pimage.img.h;
                assert pimage.h >= pimage.iy + pimage.ih;
                assert pimage.w >= pimage.ix + pimage.iw;
                
                pimage.img = pimage.img.CloneRect(rect);
            else:
                pass  # уже всё расчитано (например, для эффектов)

            GX.ExecutePreprocess(pimage)
            
            self.log_debug("  pimage: %s" % tostr(pimage))

        if self.dry_run_fast:
            return

        # Вызываем функцию упаковки
        self.log_progress("Atlas pack %d images" % (len(pimages)))
        self.log_debug("  ps: %s" % tostr(ps))
        result = False
        if pack_settings.get('pack_append') and ps.max_sheets != 1:
            (result, sheets) = self.pack_append(pimages, ps, out_name)
        if not result:
            (result, sheets) = GX.PackPrepared(pimages, ps)
        self.log_debug("Atlas pack result: %r; %s", result, [tostr(v) for v in sheets] if sheets else None)
        if not result:
            self.log_error("Atlas pack failed: %r (%r) @ %r" % (atlas_id, out_name, loc))
            return
        if not sheets:
            self.log_warning("No sheets packed for atlas: %r (%r) @ %r" % (atlas_id, out_name, loc))
            return

        # Удаляем старые файлы
        for f in self.find_atlas_files(self.dst_abs_path, out_name):
            self.log_write("Remove old file: %r" % f)
            if not self.dry_run:
                os.remove(os.path.join(self.dst_abs_path, f))

        # Сохраняем файлы
        out_sheets = []  # Сюда сохраняются имена отдельных атласов (без расширения)
        out_files = []  # Сюда сохраняются все файлы (xml, png)
        for i, sheet in enumerate(sheets):
            if not sheet:  # пропуск страницы
                continue
            sheet_files = []
            self.save_sheet(sheet, i, out_name, ps, pack_settings, out_sheets, sheet_files)
            out_files.extend(sheet_files)

            for f in sheet_files:
                # Дополнительная обработка - маска, сжатие
                if not os.path.exists(os.path.join(self.dst_abs_path, f)):
                    self.log_error("Missing result file: '%f'" % (f))

                if bool_attr(pack_settings.get('mask')):  # Делаем маску, если это явно указано
                    mask_files = self.make_mask(f, self.dst_abs_path, sheet, pack_settings, loc)
                    if mask_files:
                        out_files.extend(mask_files)

                if f.lower().endswith(".png"):
                    # Сжимаем текстуры атласа
                    if self.compress_atlas_immediately:
                        # (Не записываем результат в кэш, т.к. записываем в out_files, который пойдёт в кэш)
                        compress_files = self.compress_file(f, self.dst_abs_path, compress_settings, pack_settings,
                                                            package_id, group_id, {'type': 'atlas'}, loc, no_cache=True)
                        if compress_files:  # если успешно сжали
                            for ff in compress_files:
                                if ff not in out_files:
                                    out_files.append(ff)
                            # удаляем png файл после сжатия
                            if self.compress_remove_dst_png or self.compress_remove_atlas_png:
                                out_files.remove(f)
                                if os.path.exists(os.path.join(self.dst_abs_path, f)):
                                    self.log_write("Remove compressed file: %r" % f)
                                    if not self.dry_run:
                                        os.remove(os.path.join(self.dst_abs_path, f))

        return out_sheets, out_files

    # Сохраняем файлы готового атласа на диск
    def save_sheet(self, sheet, i, out_name, ps, pack_settings, out_sheets, out_files):
        self.log_debug("save_sheet %s, i=%r, out_name=%r" % (tostr(sheet), i, out_name))
        file_name = out_name
        if ps.max_sheets != 1:
            file_no = str(i)
            if i < 10:
                file_no = '0' + file_no
            file_name = file_name + '_' + file_no
        out_sheets.append(file_name)  # сохраняем имена отдельных атласов (без расширения)

        # Save atlas png
        self.log_write("Write " + file_name + '.png')
        if not self.dry_run:
            sheet.image.WritePng(utf8_encode(os.path.join(self.dst_abs_path, file_name + '.png')))
        out_files.append(file_name + '.png')

        # Save atlas xml
        output_settings = GX.OutputSettings()
        if bool_attr(pack_settings.get('xml_add_path', True)):
            output_settings.add_path = True
        if bool_attr(pack_settings.get('xml_add_id', True)):
            output_settings.add_id = True
        if bool_attr(pack_settings.get('rawGeometry')):
            output_settings.rawGeometry = True
        if 'rootPath' in pack_settings:
            output_settings.rootPath = pack_settings['rootPath']  # ~ TODO: нет такого поля в OutputSettings

        self.log_debug("output_settings: %s" % tostr(output_settings))

        doc = xml.xml_document()
        frames_node = doc.append_child('Frames')
        sheet.WriteDescription(frames_node, output_settings)
        self.log_write("Write " + file_name + '.xml')
        if not self.dry_run:
            doc.save_file(utf8_encode(os.path.join(self.dst_abs_path, file_name + '.xml')))
        out_files.append(file_name + '.xml')

    # Инкрементальная упаковка многостраничных атласов (например, кубов).
    # Стараемся упаковать все новые файлы в конец атласа, чтобы не менять уже имеющиеся страницы.
    # Это используется для минимизации изменений в дозагрузке, а также для ускорения сжатия.
    def pack_append(self, pimages, ps, out_name):
        self.log_debug("pack_append %d images" % (len(pimages)))

        result = True
        sheets = []  # результат

        # Загружаем имеющиеся атласы (если есть) и пакуем страницы по тем же спискам.
        prev_dir = self.cache_path
        prev_files = self.find_atlas_files(prev_dir, out_name)
        if not prev_files:
            # Если не нашли в кеше, то проверяем dst_abs_path
            prev_dir = self.dst_abs_path
            prev_files = self.find_atlas_files(prev_dir, out_name)
        # нам нужны .xml файлы атласов
        prev_xml_files = []
        for f in prev_files:
            if f.endswith(".xml"):
                prev_xml_files.append(f)
        if not prev_xml_files:
            # ничего не нашли, выходим
            result = False
            self.log_debug("pack_append: no prev sheets: %r" % out_name)
            return (result, sheets)
        # Пакуем страницы
        prev_sheets_num = len(prev_xml_files)
        for i in range(prev_sheets_num):
            xml_abs_path = normpath(os.path.join(prev_dir, prev_xml_files[i]))
            if not os.path.exists(xml_abs_path):
                self.log_error("pack_append: missing file %r" % (xml_abs_path))
            self.log_verbose("pack_append %d read %r" % (i, xml_abs_path))
            doc = xml_read(xml_abs_path)
            sheet_files = set()
            frames_path = doc.getroot().get('path', "")
            for frame in doc.getroot().findall('frame'):
                self.log_verbose("pack_append frame %s" % (lxml_cur_pos(frame)))
                tex_path = frame.get('path')
                if not tex_path:
                    self.log_error(lxml_cur_pos(frame) + ": no 'path' attribute")
                    continue
                tex_path = normpath(os.path.join(frames_path, tex_path))
                sheet_files.add(tex_path)
            self.log_verbose("pack_append prev: %r" % (sheet_files))
            self.log_verbose("pack_append check: %r" % [x.path for x in pimages])
            # Выбираем из pimages те же файлы, что были в этом атласе
            if i + 1 < prev_sheets_num:
                sheet_pimages = []
                pimages = [x for x in pimages if x.path not in sheet_files or sheet_pimages.append(x)]
                # в pimages остались неподошедшие файлы
            else:
                # Для последней страницы упаковываем все оставшиеся pimages
                sheet_pimages = pimages
                pimages = []
            if not sheet_pimages:
                sheets.append(None)  # пропускаем страницу
                continue
            self.log_verbose("pack_append pack: %r" % [x.path for x in sheet_pimages])
            # пакуем страницу
            (result, new_sheets) = GX.PackPrepared(sheet_pimages, ps)
            if not result:
                self.log_warning("pack_append %r %d/%d failed" % (out_name, i + 1, prev_sheets_num))
                break
            if i + 1 < prev_sheets_num and len(new_sheets) != 1:
                # В new_sheets должна быть ровно 1 страница, если упаковывается не последняя страница
                self.log_warning("pack_append %r %d/%d failed: %d sheets" % (out_name, i + 1, prev_sheets_num, len(new_sheets)))
                result = False
                break
            sheets.extend(new_sheets)

        if result and pimages:
            # Что-то пошло не так: в pimages не должно ничего остаться!
            self.log_error("pack_append failed: %r" % out_name)
            result = False

        return (result, sheets)

    # Определяем, должен ли размер атласа быть степенью двойки (в зависимости от формата сжатия)
    def detect_pot(self, compress_settings, default):
        if compress_settings.get('format') in {'pvrtc', '2xpvrtc', 'etc2_pvrtc'}:
            return True
        # else:
        return default

    # Определяем можно ли и нужно ли обрезать POT атласы
    # Возвращает True, если нужно делать trim по умолчанию (для etc2_pvrtc).
    # Возвращает False, если trim нельзя делать ни в коем случае.
    # Возвращает None, если trim не нужно делать по умолчанию.
    def detect_trim_pot(self, compress_settings):
        res = self.detect_pot(compress_settings, None)  # Эта функция возвращает True для etc2_pvrtc, т.к. ему полезно сделать trim.
        if res and compress_settings.get('format') in {'pvrtc', '2xpvrtc'}:
            return False  # Запрещаем обрезать pvrtc атласы, т.к. это приведёт лишь к лишнему TranslateUV, и больше ни к чему
        return res

    # Вспомогательная функция для проверки условия only_group.
    # only_group может быть None, "group" или ["group1","group2",...]
    def check_group(self, group, only_group):
        if only_group is None:
            return True
        if group is None:
            group = ""
        if isinstance(only_group, str):
            return group == only_group
        if isinstance(only_group, list) or isinstance(only_group, tuple):
            return group in only_group
        self.log_error("Wrong only_group value: %r" % (only_group))
        return True

    # Находим файлы атласов по имени файла. Используется для удаления старых файлов.
    def find_atlas_files(self, root_path, out_name):
        result = []
        for ext in ("xml", "png", "webp", "dds"):
            if os.path.exists(os.path.join(root_path, out_name + "." + ext)):
                result.append(out_name + "." + ext)
            for f in self.glob(os.path.join(root_path, out_name + "_??." + ext)):
                if re.match(r'.*_\d\d\.[^\.]+$', f):
                    result.append(normpath(os.path.relpath(f, root_path)))
                else:
                    self.log_warning("Suspicious file: " + f)
        result.sort()
        return result

    # Регистрируем атлас в AtlasResources.xml. (В атласе может быть несколько страниц.)
    def register_sheets(self, out_sheets, out_name, atlas_id, package_id, group_id, pack_settings, loc):
        atlas_resources_xml = pack_settings.get('reg_xml', self.atlas_resources_xml or 'AtlasResources.xml')
        # atlas_resources_xml = None обозначает base/AtlasResources.xml по умолчанию
        # atlas_resources_xml = False обозначает, что не надо регистрировать атлас
        if bool_attr(atlas_resources_xml, strict=False) is False:
            self.log_debug("Don't register sheets (reg_xml = false): %r" % out_name)
            return  # Не регистрировать атласы вообще

        with self.log_section("register_sheets %r" % out_name, logging.DEBUG):
            if group_id is None:
                group_id = pack_settings.get('group_id', "")

            xml_rel_package = bool_attr(pack_settings.get('reg_rel_pkg', self.atlas_resources_xml_rel_package))

            # base_dir - директория, относительно которой записываются пути к файлам атласа
            base_dir = self.base_path  # Обычно это base
            if self.resources_rel_package and xml_rel_package and package_id and package_id in self.package_id_to_path:
                base_dir = self.package_id_to_path[package_id]  # Относительно пакета (TS)

            # Приводим пути атласов к base_dir
            rel_sheets = []
            for f in out_sheets:
                assert os.path.commonprefix([f, base_dir]) == base_dir, f + " not in " + base_dir
                rel_filename = normpath(os.path.relpath(f, base_dir).replace('\\', '/'))
                rel_sheets.append(rel_filename)
                self.log_debug("sheet file: %r" % rel_filename)

            # Загружаем AtlasResources.xml
            if xml_rel_package and package_id and package_id in self.package_id_to_path:
                # AtlasResources.xml лежит в пакете
                package_dir = self.package_id_to_path[package_id]
                atlas_resources_xml = normpath(os.path.join(package_dir, atlas_resources_xml))  # package/AtlasResources.xml
            else:
                atlas_resources_xml = normpath(os.path.join(self.base_path, atlas_resources_xml))  # base/AtlasResources.xml
            self.log_debug("atlas_resources_xml = %r" % atlas_resources_xml)

            self.generated_atlas_resources_xml.add(atlas_resources_xml)

            if os.path.exists(os.path.join(self.dst_abs_path, atlas_resources_xml)):
                doc = xml_read(atlas_resources_xml, self.dst_abs_path)
                root = doc.getroot()
            else:
                root = etree.Element('Resources')

            # Удаляем регистрацию старых атласов из AtlasResources.xml
            for base_node in root.findall('Sheets'):
                found = []
                for node in base_node.findall('sheet'):
                    if (atlas_id and node.get('id') == atlas_id
                            or fnmatch.fnmatch(node.get('path'), out_name + "_??.*")
                            or fnmatch.fnmatch(node.get('path'), out_name + ".*")):  # На случай max_sheets=1
                        found.append(node)
                        continue
                    for sheet in rel_sheets:  # По идее проверок выше достаточно, но на всякий случай...
                        if node.get('path') == sheet:
                            found.append(node)
                            break
                for node in found:
                    self.log_debug("remove old sheet node %r %r" % (node.get('id'), node.get('path')))
                    base_node.remove(node)
                if len(base_node) == 0:
                    root.remove(base_node)  # удаляем пустой блок <Sheets>

            cube = bool_attr(pack_settings.get('cube'))

            sheets_node = None
            if not cube:  # Для кубического атласа всегда создаём отдельный блок <Sheets assemble="cube">
                # Ищем первую попавшуюся ноду Sheets без assemble="cube"
                for node in root.findall('Sheets'):
                    if node.get('assemble'):
                        continue
                    if node.get('group', "") != group_id:
                        continue
                    sheets_node = node
                    break
            if sheets_node is None:
                sheets_node = etree.SubElement(root, 'Sheets', OrderedDict())
                if cube:
                    sheets_node.attrib['assemble'] = 'cube'
                if group_id and self.atlas_register_group:
                    sheets_node.attrib['group'] = group_id

            for sheet in rel_sheets:
                sheet_xml = etree.SubElement(sheets_node, 'sheet', OrderedDict())
                if self.atlas_register_id and atlas_id:
                    sheet_xml.attrib['id'] = atlas_id
                sheet_xml.attrib['path'] = sheet + '.png'
                sheet_xml.attrib['xml'] = sheet + '.xml'
                if 'mask' in pack_settings:
                    sheet_xml.attrib['mask'] = pack_settings['mask']  # например, для mask="false"
                if 'mask_limit' in pack_settings:
                    sheet_xml.attrib['alphaLimit'] = pack_settings['mask_limit']
                if 'pixelType' in pack_settings:
                    sheet_xml.attrib['pixelType'] = pack_settings['pixelType']

                if self.atlas_register_compress and 'compress' in pack_settings:  # по умолчанию False, т.к. на деле не используется
                    compress = pack_settings['compress']
                    if isinstance(compress, dict):
                        compress = self.compress_to_str(compress)
                    assert isinstance(compress, str), str(compress)
                    sheet_xml.attrib['compress'] = compress

                self.log_debug("sheet_xml %s" % tostr(dict(sheet_xml.attrib)))

            if not self.dry_run:
                self.ensure_dir(os.path.dirname(atlas_resources_xml))
                etree.ElementTree(root).write(os.path.join(self.dst_abs_path, atlas_resources_xml),
                                              xml_declaration=True, encoding='utf-8', pretty_print=True)

    # Вытаскиваем из атласов информацию по swl анимациям и регистрируем её в отдельном файле (SwlSheets.xml)
    def register_swl_sheets(self, out_files, root_path, settings, package_id):
        self.log_progress("register_swl_sheets %r [%r]" % (out_files, package_id))
        # Читаем атласы
        swl_to_sheets = {}
        for f in out_files:
            if f.endswith(".xml"):
                doc = xml_read(os.path.join(root_path, f))
                for frame in doc.getroot():
                    frame_id = frame.get('id')
                    if settings.get('register_swl_by_path'):  # Опция для Тауншипа
                        frame_id = frame.get('path')
                    anim = os.path.dirname(frame_id)
                    swl_to_sheets[anim] = FileNameWithoutExt(f) + ".png"  # менеджер ресурсов учитывает атласы по имени png

        xml_rel_package = bool_attr(settings.get('reg_rel_pkg', self.swl_sheets_xml_rel_package))

        # base_dir - директория, относительно которой записываются пути к файлам атласа
        base_dir = self.base_path  # Обычно это base
        if self.resources_rel_package and xml_rel_package and package_id and package_id in self.package_id_to_path:
            base_dir = self.package_id_to_path[package_id]  # Относительно пакета (TS)

        # Сохраняем инфу
        swl_sheets_xml = settings.get('swl_sheets_xml', self.swl_sheets_xml or 'SwlSheets.xml')
        if xml_rel_package and package_id and package_id in self.package_id_to_path:
            # SwlSheets.xml лежит в пакете
            package_dir = self.package_id_to_path[package_id]
            swl_sheets_xml = normpath(os.path.join(package_dir, swl_sheets_xml))  # package/SwlSheets.xml
        else:
            swl_sheets_xml = normpath(os.path.join(base_dir, swl_sheets_xml))  # base/SwlSheets.xml

        self.log_debug("register_swl_sheets to %r" % swl_sheets_xml)
        if os.path.exists(os.path.join(self.dst_abs_path, swl_sheets_xml)):
            doc = xml_read(swl_sheets_xml, self.dst_abs_path)
            root = doc.getroot()
        else:
            root = etree.Element('Resources')

        # Удаляем старую регистрацию
        to_delete = []
        for elem in root.findall('SwlSheet'):
            if elem.get('swl') in swl_to_sheets:
                to_delete.append(elem)
        for node in to_delete:
            self.log_debug("  remove old swl-to-sheet record %r %r" % (node.get('swl'), node.get('sheet')))
            root.remove(node)

        # Добавляем новые записи
        for swl, sheet in sorted(swl_to_sheets.items()):
            elem = etree.SubElement(root, 'SwlSheet', OrderedDict())
            elem.attrib['swl'] = swl
            # Убираем base (первый компонент пути)
            path = normpath(os.path.relpath(sheet, self.base_path))
            elem.attrib['sheet'] = path
            self.log_debug("  add swl-to-sheet record %r %r" % (swl, path))

        # Создаём директорию при необходимости
        self.ensure_dir(os.path.dirname(swl_sheets_xml))

        # Сохраняем в файл
        etree.ElementTree(root).write(os.path.join(self.dst_abs_path, swl_sheets_xml),
                                      xml_declaration=True, encoding='utf-8', pretty_print=True)

    # Вычисляет хэш для кэша атласов
    def compute_pack_hash(self, pack_settings, content, compress_settings):
        s = '[Atlas]'
        if self.global_hash_salt:
            s += '|' + self.global_hash_salt
        if self.atlas_hash_salt:
            s += '|' + self.atlas_hash_salt
        settings = {k: v for k, v in pack_settings.items(
        ) if k in self._pack_settings_attrs or k in self._content_pack_attrs or k in self._pack_result_attrs}
        s += '|ps=' + tostr(settings)

        files = []
        file_ids = []
        img_hashes = []
        for item in content:
            if item.get('type') == 'effect':  # Particle Effect Solution
                # Не должны сюда попадать!
                # Эффекты должны быть распакованы в текстуры в функции collect_effect_textures()
                self.log_error("Unexpected effect in filter_content: %r %s", item.get('path'), item.get('@loc'));

                # используем встроенную функцию для хэша
                s += '|eff=' + str.join(',', ["%s:%s" % (f, pyscript.Effect.EffectHash(normpath(os.path.join(self.repo_abs_path, f)))) for f in item['effects']])
                if item.get('textures'):
                    # note: abs path in 'textures'
                    hashes = pyscript.fs.hash_files([utf8_encode(v.path) for v in item['textures']])
                    for i, v in enumerate(item['textures']):
                        hashes[i] = "%s:%s" % (normpath(os.path.relpath(self.repo_abs_path, v.path)), hashes[i])
                    s += '|files=' + str.join(',', hashes)
                else:
                    self.log_warning("No textures in effect")
                continue
            if item.get('type') == 'model':  # Animation model
                # Не должны сюда попадать!
                # Модели должны быть распакованы в текстуры в функции collect_model_textures()
                self.log_error("Unexpected model in filter_content: %r %s", item.get('path'), item.get('@loc'));
                continue
            if item.get('image'):
                img_hashes.append("%s:%s" % (item['id'], item['image'].hash()))
            else:
                files.append(item['full_path'])
                file_ids.append(item['id'])
            attrs = {k: v for k, v in item.items() if k in self._content_pack_attrs}
            if attrs:
                s += '|' + item['full_path'] + "=" + tostr(attrs)

        if files:
            hashes = pyscript.fs.hash_files([utf8_encode(os.path.join(self.repo_abs_path, f)) for f in files])
            for i, h in enumerate(hashes):
                hashes[i] = "%s:%s" % (file_ids[i], h)
            s += '|files=' + str.join(',', hashes)
        if img_hashes:
            s += '|imgs=' + str.join(',', img_hashes)

        if compress_settings:
            s += '|compress=' + self.compute_compress_hash(None, compress_settings)

        self.log_debug('compute_pack_hash %r' % utf8_encode(s))

        return pyscript.string.hash(utf8_encode(s))

    # Парсим параметры вида "fmt:a=1;b=2;..."
    def parse_compress_str(self, s, dbg_info=None):
        p = re.split(r'(?<!\\)[:@;,]', s)  # not prefixed with '\' (?<! - 'lookbehind' condition) ('@' used by FD)
        fmt = p[0].lower()
        res = {}
        res['format'] = fmt
        for v in p[1:]:
            sp = v.split('=', 1)  # maxsplit = 1
            k = sp[0]
            v = sp[1] if len(sp) > 1 else True
            if k in {'format', 'id'}:
                self.log_error("Unallowed compress option " + k + " in " + s + ": " + str(dbg_info))
                continue
            if k in res:
                self.log_warning("Duplicate compress option " + k + " in " + s + ": " + str(dbg_info))
            res[k] = v
        return res

    # Форматируем настройки сжатия в строку (используется для записи атрибута compress в описание атласа)
    def compress_to_str(self, d):
        res = d['format']
        d = d.copy()
        del d['format']
        if d:
            res += ":" + str.join(";", ['%s=%s' % (key, str(value)) for (key, value) in sorted(d.items())])
        return res

    # Сохраняем настройки сжатия из AtlasSettings.xml.
    # На самом деле просто сохраняем ноды по id, а реальная обработка делается в позже в calc_compress_settings.
    def read_compress_settings_node(self, node):
        if not self.check_filter_attrs(node):
            return

        # Проверка
        if (node.get('id') is None and node.get('format') is None and node.get('file') is None and node.get('folder') is None
                and len(node) == 0):
            # Параметры сжатия привязываются к id формата, поэтому в ноде обязательно должен быть id или format,
            # иначе непонятно, к чему эти настройки.
            self.log_warning("Incorrect <Compress> node: " + lxml_cur_pos(node))

        id = node.get('id')
        if id is None and node.getparent() == node.getroottree().getroot():
            id = ""  # Корневые ноды Compress задают сжатие по умолчанию
        if id is not None:
            id = id.lower()
            if id not in self.compress_settings:
                self.compress_settings[id] = []
            self.compress_settings[id].append(node)

        if node.get('id') is None:
            for child in node:
                self.read_compress_settings_node(child)

    # Это костыльная функция, которая пытается вычислить базовый формат из объявленного пользователем.
    # При этом не учитываются фильтры, так что не стоит ими злоупотреблять.
    def get_base_compress_format(self, fmt):
        if fmt in self.compress_settings:
            for node in self.compress_settings[fmt]:
                # тут могут быть фильтры, но сюда слишком сложно прокидывать контекст, поэтому надеемся, что они не понадобятся
                v = node.get('format')
                if v:
                    v = self.parse_compress_str(v, dbg_info=lxml_cur_pos(node))
                    v = v.get('format')
                    if v:
                        self.log_verbose("get_base_compress_format %r" % fmt)
                        return self.get_base_compress_format(v)  # tail recursion
        return fmt

    # Рассчитываем настройки упаковки для конкретного файла
    def calc_compress_settings(self, fmt="", loc=None, filename=None, package=None, group=None, resource=None, result=None):
        if result is None:
            result = {}
        if resource is None:
            resource = {}
        with self.log_section("calc_compress_settings fmt=%r loc=%r filename=%r resource=%r package=%r group=%r result=%r"
                              % (fmt, loc, filename, resource, package, group, result), LOG_VERBOSE):
            if fmt is None:
                fmt = ""
            if isinstance(fmt, str):
                fmt = self.parse_compress_str(fmt, loc)
                self.log_verbose("fmt: %r" % (fmt))
            fmt_name = fmt['format']

            # Запоминаем все форматы, чтобы избежать рекурсии
            if '__stack' not in result:
                result['__stack'] = OrderedDict()
            if fmt_name in result['__stack']:
                self.log_error("Recursive format declaration: " + str(result['__stack']) + " @ " + str(loc))
                return result
            result['__stack'][fmt_name] = loc

            result['format'] = fmt_name

            # Собираем все настройки
            if fmt_name in self.compress_settings:
                for node in self.compress_settings[fmt_name]:
                    self._calc_compress_settings_node(node, filename, package, group, resource, result)

            # Применяем настройки из fmt
            for attr, v in sorted(fmt.items()):
                if attr == 'format':
                    continue
                result[attr] = v

            result['__stack'].popitem()  # против рекурсии
            if len(result['__stack']) == 0:
                del result['__stack']

            self.log_verbose("result: %r" % (result))
            return result

    # Вспомогательная функция для расчёта настроек упаковки (собирает атрибуты из описания xml)
    def _calc_compress_settings_node(self, node, filename, package_id, group_id, resource, result):
        with self.log_section("_calc_compress_settings_node: %r file=%r" % (lxml_cur_pos(node), filename), LOG_VERBOSE):
            if not self.check_filter_attrs(node, None, package_id):
                self.log_verbose("skip by filter")
                return
            if not self.check_filter_attrs_ps(node, filename, resource):
                self.log_verbose("skip by filter ps")
                return
            # other filters
            package_attr = node.get('package')
            if package_attr is not None and package_id != package_attr:
                self.log_verbose("skip by filter pkg %r != %r" % (package_id, package_attr))
                return
            group_attr = node.get('group')
            if group_attr is not None and group_id != group_attr:
                self.log_verbose("skip by filter group %r != %r" % (group_id, group_attr))
                return
            atlas_attr = node.get('atlas')
            if atlas_attr is not None and bool_attr(atlas_attr) != (resource.get('type') == 'atlas'):
                self.log_verbose("skip by filter atlas %s" % (bool_attr(atlas_attr)))
                return

            if node.get('format'):  # Ссылка на другой формат!
                v = node.get('format')
                self.calc_compress_settings(v, lxml_cur_pos(node), filename, package_id, group_id, resource, result)

            for attr, v in sorted(node.attrib.items()):
                if attr in {'id', 'format', 'package', 'group', 'atlas'}:
                    pass  # эти атрибуты только что обработали выше
                elif attr in self._filter_attribs or attr in self._filter_attribs_ps:
                    pass
                else:
                    # атрибуты сжатия могут быть любыми (для пользовательских форматов), так что сохраняем все, какие есть
                    result[attr] = v
                    self.log_verbose("%s = %r" % (attr, v))

            self.log_verbose("result %r" % (result))

            if len(node):
                for child in node:
                    if child.get('id'):
                        continue  # Такие ноды были собраны отдельно в read_compress_settings
                    self._calc_compress_settings_node(child, filename, package_id, group_id, resource, result)
                self.log_verbose("result %r" % (result))

    # Берём настройки из настроек атласа по умолчанию.
    def calc_default_settings(self, settings=None, package_id=None, group_id=None):
        with self.log_section("calc_default_settings", LOG_VERBOSE):
            result = {}
            for def_node in reversed(self.atlas_default):  # более поздние ноды имеют больший приоритет
                if self.check_filter_attrs(def_node, result, package_id):
                    self.log_verbose("add default %s" % lxml_cur_pos(def_node))
                    # Применяем настройки из default ноды
                    self._calc_atlas_settings_node(def_node, package_id, group_id, result)
                    self.log_verbose("updated %s" % tostr(result))
                else:
                    self.log_verbose("skip default by filter %s" % lxml_cur_pos(def_node))
            if settings:
                self.log_verbose("apply initial settings %s" % (settings))
                result.update(settings)
            self.log_verbose("result: %s" % tostr(result))
            return result

    # Возвращает set из файлов, которые попадают в атласы (пути относительно repo_abs_path).
    def get_packed_textures(self, atlases=None):
        result = self.resources_in_atlases.copy()
        # Добавляем файлы, которые будут запакованы в атласы:
        if atlases is None:
            atlases = self.prepare_atlases()
        for atlas in atlases:
            repacked_atlases = set()
            for item in atlas['content']:
                if item.get('type') == 'effect':  # Particle Effect
                    for info in item.get('textures'):  # note: abs path in 'textures'
                        result.add(normpath(os.path.relpath(self.repo_abs_path, info.path)))
                    continue
                result.add(item['full_path'])
                # Проверяем переупакованные атласы
                if 'image' in item:
                    f = item.get('@loc')
                    if f and f.endswith(".png"):
                        if f in repacked_atlases:
                            continue
                        self.log_debug("packed_atlas: %r" % f)
                        repacked_atlases.add(f)
                        result.add(f)
        return result

    # Сжимаем все текстуры в сжатый формат
    def compress_all(self, atlases=None):
        with self.log_section("compress_all", LOG_PROGRESS):
            compressed = {}  # Запоминаем уже сжатые файлы, чтобы не сжимать повторно

            if atlases is None:
                atlases = self.prepare_atlases()  # Описания атласов со списком текстур

            # Сжимаем текстуры сгенерированных атласов
            self.compress_gen_atlases(atlases, compressed)

            # Файлы, которые не надо сжимать, т.к. они упакованы в атласы
            exclude = self.get_packed_textures(atlases)

            # Сжимаем атласы, которые не генерируются автоматически (из Resources.xml, если такие вообще бывают)
            self.compress_res_atlases(exclude, compressed)

            # Сжимаем текстуры, которые не упакованы в атласы
            self.compress_res_textures(exclude, compressed)

            # Сжимаем файлы, объявленные по пути (<Compress file="*"/>)
            self.compress_listed_files(exclude, compressed)

            if self.threading_enabled:
                self._wait_pool_completion()

    # Сжимаем текстуры сгенерированных атласов
    def compress_gen_atlases(self, atlases, compressed=None):
        if not compressed:
            compressed = {}
        with self.log_section("compress_gen_atlases", LOG_PROGRESS):
            for atlas in atlases:
                decl = atlas.get('decl')
                if decl is None:
                    self.log_error("No 'decl' @ " + str(atlas))
                    continue
                loc = lxml_cur_pos(decl)
                out_name = atlas.get('out_name')
                if not out_name:
                    self.log_error("No 'out_name' @ " + loc)
                    continue
                self.log_debug("Compress atlas %r" % out_name)
                package_id = atlas.get('package_id', '')
                group_id = atlas.get('group_id', '')
                if not self.check_group(package_id, self.only_package):
                    continue
                if not self.check_group(group_id, self.only_group):
                    continue
                if not self.check_group(atlas.get('id'), self.only_atlas):
                    continue

                pack_settings = atlas.get('pack_settings')
                compress = pack_settings.get('compress')

                # ~ TODO: запоминать out_sheets, чтобы хотя бы при полном запуске иметь эту инфу?
                files = self.find_atlas_files(self.dst_abs_path, out_name)
                if not files:
                    if not self.dry_run:
                        self.log_warning("No files for atlas %r: %r @ %r" % (atlas.get('id'), out_name, loc))
                    continue
                for f in files:  # все файлы атласа: xml, png, mask, ...
                    if f.lower().endswith('.png'):
                        if f in compressed:
                            self.log_warning("Already compressed: " + f)  # не должно происходить
                            continue
                        compressed[f] = True

                        self._job_wrapper(self.compress_file, (f, self.dst_abs_path, compress, pack_settings,
                                                               package_id, group_id, {'type': 'atlas'}, loc))

    # Сжимаем атласы, которые не генерируются автоматически (из Resources.xml, если такие вообще бывают)
    def compress_res_atlases(self, exclude, compressed=None):
        if not compressed:
            compressed = {}
        with self.log_section("compress_res_atlases", LOG_PROGRESS):
            for item in self.resources_atlases:
                path = item.get('full_path')  # (путь относительно repo_abs_path)
                if not path:
                    self.log_warning("No path in atlas description @ %s" % item.get('@loc'))
                    continue
                # проверяем, что это .png
                if not path.lower().endswith('.png'):
                    self.log_warning("Wrong resource image: %r @ %s" % (path, item.get('@loc')))
                    continue
                # проверяем, упакован ли ресурс в атлас
                if path in exclude:
                    continue

                package_id = item.get('package_id') or self.detect_package(path)
                group_id = item.get('group_id', '')
                if not self.check_group(package_id, self.only_package):
                    continue
                if not self.check_group(group_id, self.only_group):
                    continue
                if not self.check_group(item.get('id'), self.only_atlas):
                    continue

                self.log_debug("Compress atlas texture: %r" % path)

                # берём настройки по умолчанию
                pack_settings = self.calc_default_settings(item, package_id, group_id)

                # берём настройки сжатия
                compress = pack_settings.get('compress_' + self.platform)  # e.g. "compress_android"
                if compress is None:
                    compress = pack_settings.get('compress')

                if path in compressed:
                    self.log_debug("Skip already compressed file: %r" % path)
                    continue
                compressed[path] = True

                self._job_wrapper(self.compress_file, (path, self.repo_abs_path, compress, pack_settings,
                                  package_id, group_id, {'type': 'atlas'}, item.get('@loc')))

    # Сжимаем текстуры, которые не упакованы в атласы
    def compress_res_textures(self, exclude, compressed=None):
        if not compressed:
            compressed = {}
        with self.log_section("compress_res_textures", LOG_PROGRESS):
            for package_id in self.resources_by_group:
                if self.only_atlas:
                    continue
                if not self.check_group(package_id, self.only_package):
                    continue
                for group_id, resources in sorted(self.resources_by_group[package_id].items()):
                    if not self.check_group(group_id, self.only_group):
                        continue
                    resources = resources[:]  # make a copy
                    self.collect_model_textures(resources)
                    for item in resources:
                        loc = item.get('@loc')
                        path = item.get('full_path')  # (путь относительно repo_abs_path)
                        if not path:
                            self.log_warning("No full_path in resource (%r): %r" % (item.get('id'), loc))  # internal error
                            continue

                        # проверяем, что это .png
                        if not path.lower().endswith('.png'):
                            self.log_warning("Wrong resource image (%r): %r @ %s" % (item.get('id'), path, loc))
                            continue

                        # проверяем, упакован ли ресурс в атлас
                        if path in exclude:
                            continue

                        if path in compressed:
                            self.log_debug("Skip already compressed file (%r): %r" % (item.get('id'), path))
                            continue

                        self.log_debug("Compress texture %r: %r" % (item.get('id'), path))

                        # берём настройки сжатия
                        compress = item.get('compress_' + self.platform)  # e.g. "compress_android"
                        if compress is None:
                            compress = item.get('compress')
                        compressed[path] = True

                        # берём настройки по умолчанию
                        pack_settings = self.calc_default_settings(item, package_id, group_id)
                        pack_settings['mask'] = item.get('mask')  # calc_default_settings возвращает настройку mask для атласов

                        self._job_wrapper(self.compress_file, (path, self.repo_abs_path, compress, pack_settings,
                                          package_id, group_id, item, loc))

    # Сжимаем файлы, объявленные по пути (<Compress file="*"/>)
    def compress_listed_files(self, exclude, compressed=None):
        if not compressed:
            compressed = {}
        with self.log_section("compress_listed_files", LOG_PROGRESS):
            pack_settings = None
            for id in self.compress_settings:
                if self.only_atlas:
                    continue
                if self.only_group:
                    continue
                for node in self.compress_settings[id]:
                    file_v = node.get('file')
                    folder_v = node.get('folder')
                    if not file_v and not folder_v:
                        continue
                    self.log_debug("Compress files: %r %r" % (folder_v or "", file_v or ""))
                    if folder_v:
                        if not file_v:
                            file_v = "*.png"
                        file_v = normpath(os.path.join(folder_v, file_v))
                    for f in self.glob(os.path.join(self.repo_abs_path, file_v)):
                        f = normpath(os.path.relpath(f, self.repo_abs_path))
                        # проверяем, упакован ли ресурс в атлас
                        if f in exclude and f != file_v:
                            self.log_debug("Skip already packed file: %r" % f)
                            continue
                        if self.only_package is not None and not self.check_group(self.detect_package(f), self.only_package):
                            continue
                        if f in compressed and f != file_v:
                            self.log_debug("Skip already compressed file: %r" % f)
                            continue
                        compressed[f] = True

                        if not pack_settings:
                            pack_settings = self.calc_default_settings()
                            pack_settings['mask'] = None  # calc_default_settings возвращает настройку mask для атласов

                        compress_settings = {}
                        if not node.get('format'):
                            compress_settings = self.parse_compress_str("")
                        self._calc_compress_settings_node(node, f, None, None, {}, compress_settings)

                        self._job_wrapper(self.compress_file, (f, self.repo_abs_path, compress_settings, pack_settings,
                                          None, None, None, lxml_cur_pos(node)))

    # Сжимает изображение в соответствии с настройками.
    def compress_file(self, file, src_path, settings, pack_settings, package_id=None, group_id=None, resource=None, dbg_info=None, no_cache=False):
        with self.log_section("compress_file %r: %s @ %s" % (file, tostr(settings), dbg_info), LOG_PROGRESS):
            self.log_verbose("in %r; resource=%r, package_id=%r, group_id=%r", src_path, resource, package_id, group_id)

            settings = self.calc_compress_settings(settings, dbg_info, file, package_id, group_id, resource)

            self.log_debug("compress settings: %s" % tostr(settings))

            fmt = settings.get('format')
            if fmt is None:
                self.log_error("No 'format' in compress settings for %r (%r)" % (file, dbg_info))
                return

            if fmt == '' or fmt == 'png':
                self.log_skip("Don't compress %r (%r) @ %s" % (file, fmt, dbg_info))
                return  # похоже, не надо сжимать

            # Костыль для pma
            if get_exact_setting(pack_settings):
                settings['pma'] = True

            # Сжимаем
            result = self.compress_file_impl(file, src_path, fmt, settings, no_cache, dbg_info)
            if not result:
                # не делаем здесь log_error, т.к. это нормальная ситуация при dry_run или copy_only
                self.log_debug("No result from compress: %r %r [%r]: %r" % (src_path, file, fmt, settings))
                return

            # mask
            mask = bool_attr(settings.get('mask'))
            if mask is None:
                mask = bool_attr(pack_settings.get('mask'))
            if mask is None:
                if str(pack_settings.get('mask_limit', self.default_mask_limit)) == "0":
                    self.log_debug("mask_limit = 0, don't make mask")
                    mask = False
            if mask is None:
                if fmt != 'webp' and fmt != 'jpeg':
                    mask = True  # По умолчанию для сжатых форматов
                    self.log_debug("Mask by default for %r" % fmt)
            if mask:
                mask_files = self.make_mask(file, src_path, None, pack_settings, dbg_info)
                if mask_files:
                    result.extend(mask_files)

            # удаляем png файл после сжатия, если сжимаем в dst_abs_path
            if self.compress_remove_dst_png and src_path == self.dst_abs_path and not self.dry_run:
                self.log_write("Remove compressed file: %r" % file)
                os.remove(os.path.join(self.dst_abs_path, file))

            return result

    # Сжимает изображение в соответствии с настройками (реализация)
    def compress_file_impl(self, file, src_path, fmt, settings, no_cache=False, dbg_info=None):
        self.log_progress("Compress %r: %r %s @ %s" % (fmt, file, tostr(settings), dbg_info))
        self.log_verbose("  in %r", src_path)

        # check cache
        cache_id = fmt + "|" + file
        chash = None
        if self.cache is None and self.cache_path:
            self.init_cache()
        if self.cache and not self.dry_run:
            # Вычисляем хэш
            chash = self.compute_compress_hash(os.path.join(src_path, file), settings)
            self.log_debug("cache hash: %r" % chash)
            # Проверяем кэш
            with self.cache_lock:
                cache_checkout = self.cache.checkout(cache_id, chash)
                if cache_checkout:
                    for f in cache_checkout:
                        self.log_debug("Cache checkout: %r" % f)
                    out_files = cache_checkout
                    self.cache.save()
                    if self.on_compress_end:  # callback
                        try:
                            from_cache = True
                            self.on_compress_end(file, src_path, fmt, settings, out_files, from_cache, dbg_info)
                        except Exception:
                            self.log_error("Error in callback 'on_compress_end': %r" % sys.exc_info())
                    return out_files
                # else:
                # Если dst_abs_path совпадает с out_cache_path, то следующие действия испортят кэш, поэтому удаляем из кэша.
                if not self.copy_only and self.cache.out_cache_path == self.dst_abs_path:
                    self.cache.delete(cache_id)
                    self.cache.save()

        if self.copy_only:
            self.log_skip("(copy_only) Don't compress %r" % file)
            return

        out_name = FileNameWithoutExt(file)
        # Создаём директорию при необходимости
        self.ensure_dir(os.path.dirname(out_name))

        # Вызываем функцию сжатия
        compress_func = AtlasPacker.compress_image
        if fmt in self.compress_functions:
            compress_func = self.compress_functions[fmt]

        if self.dry_run:
            return

        out_files = []

        if self.on_compress_start:  # callback
            try:
                self.on_compress_start(file, src_path, fmt, settings, out_name, dbg_info)
            except Exception:
                self.log_error("Error in callback 'on_compress_start': %r" % sys.exc_info())

        try:
            result = compress_func(self, normpath(os.path.join(src_path, file)), fmt, settings,
                                   normpath(os.path.join(self.dst_abs_path, out_name)))
            # Проверяем результат
            if not result:
                raise Exception("%r %r (%r): no result (%r)" % (src_path, file, fmt, dbg_info))
            self.log_verbose("result: %r" % (result))
            if not (isinstance(result, list) or isinstance(result, tuple)):
                raise Exception("%r (%r): wrong result type %r: %r (%r)",
                               file, fmt, type(result).__name__, result, dbg_info)
            for res in result:
                # проверяем наличие файла
                if not os.path.exists(res):
                    raise Exception("%r %r (%r): Missing output file: %r (%r)" % (src_path, file, fmt, res, dbg_info))
                if normpath(os.path.commonprefix([res, self.dst_abs_path])) != self.dst_abs_path:
                    raise Exception("%r %r (%r): Wrong output file: %r (%r)" % (src_path, file, fmt, res, dbg_info))
                res = normpath(os.path.relpath(res, self.dst_abs_path))  # переводим обратно в относительный путь
                self.log_debug("  out_file: %r" % res)
                out_files.append(res)
        except Exception:
            exc_type, exc_val, trace = sys.exc_info()
            self.log_error("Error in compress function %r (%r): %r: %r" % (fmt, dbg_info, exc_type.__name__, exc_val),
                           trace=trace)
            out_files = []  # No result

        if file in out_files:  # Исходный file не должен попадать в результаты
            self.log_error("Wrong compress result: %r" % file)
            out_files.remove(file)

        if self.on_compress_end:  # callback
            try:
                from_cache = False
                self.on_compress_end(file, src_path, fmt, settings, out_files, from_cache, dbg_info)
            except Exception:
                self.log_error("Error in callback 'on_compress_end': %r" % sys.exc_info())

        if not out_files:
            self.log_error("No result of compressing %r: %r" % (fmt, file))
            return

        # cache
        if self.cache and not no_cache and not self.dry_run:
            with self.cache_lock:
                self.cache.delete(cache_id)
                for res in out_files:
                    assert res.find('\\') == -1, res
                    self.cache.copy_file(os.path.join(self.dst_abs_path, res), self.cache.get_out_location(res))
                self.cache.update(cache_id, chash, out_files)
                self.cache.save()

        return out_files

    # Вычисляет хэш для кэша сжатых файлов
    def compute_compress_hash(self, path, settings):
        s = '[Compress]'
        if self.global_hash_salt:
            s += '|' + self.global_hash_salt
        if self.compress_hash_salt:
            s += '|' + self.compress_hash_salt
        if path:
            s += '|file=' + pyscript.fs.hash(utf8_encode(path))

        if settings:
            s += '|settings=' + tostr(settings)

        self.log_debug('compute_compress_hash %r' % s)

        return pyscript.string.hash(utf8_encode(s))

    # Создаёт маску для изображения
    def make_mask(self, file, src_path, img=None, settings=None, dbg_info=None):
        if settings and str(settings.get('mask_limit', self.default_mask_limit)) == "0":
            self.log_debug("mask_limit = 0, don't make mask for %r" % (file))
            return None

        with self.log_section("Make mask %r @ %s" % (file, dbg_info), LOG_PROGRESS):
            self.log_verbose("in %r" % (src_path))
            if settings:
                settings = {k: v for k, v in settings.items() if re.match(r'^mask_', k)}
            else:
                settings = {}
            mask_format = settings.get('mask_format', self.default_mask_format)
            self.log_debug("mask_format: %r; settings: %s" % (mask_format, tostr(settings)))

            # check cache
            cache_id = mask_format + "|" + file
            chash = None
            if self.cache is None and self.cache_path:
                self.init_cache()
            if self.cache and not self.dry_run:
                # Вычисляем хэш
                chash = self.compute_mask_hash(os.path.join(src_path, file), mask_format, settings)
                self.log_debug("cache hash: %r" % chash)
                # Проверяем кэш
                with self.cache_lock:
                    cache_checkout = self.cache.checkout(cache_id, chash)
                    if cache_checkout:
                        for f in cache_checkout:
                            self.log_debug("Cache checkout: %r" % f)
                        self.cache.save()
                        return cache_checkout
                    else:
                        if not self.copy_only and self.cache.out_cache_path == self.dst_abs_path:
                            self.cache.delete(cache_id)
                            self.cache.save()

            if self.copy_only:
                self.log_info("(changed) Don't copy %r" % (file))
                return None

            # Make mask
            out_file = self.make_mask_impl(mask_format, file, src_path, img, settings, dbg_info)
            if not out_file:
                self.log_error("Can't make mask '%r': %r %r @ %r" % (mask_format, src_path, file, dbg_info))
                return False

            # cache
            if self.cache and not self.dry_run:
                with self.cache_lock:
                    self.cache.delete(cache_id)
                    assert out_file.find('\\') == -1, out_file
                    self.cache.copy_file(os.path.join(self.dst_abs_path, out_file), self.cache.get_out_location(out_file))
                    self.cache.update(cache_id, chash, [out_file])
                    self.cache.save()

            return [out_file]

    # Генерируем маску изображения (реализация).
    def make_mask_impl(self, mask_format, file, src_path, img=None, settings=None, dbg_info=None):
        if settings is None:
            settings = {}
        if mask_format == 'msk2':
            params = pyscript.OpacityMask.MaskSettings()
            params.mask_type = pyscript.OpacityMask.MaskType.Polygonal
            mask_scale = int(settings.get('mask_scale', 1))
            params.scale_x = int(settings.get('mask_scale_x', mask_scale))
            params.scale_y = int(settings.get('mask_scale_y', mask_scale))
            params.alpha_limit = int(settings.get('mask_limit', self.default_mask_limit))

            out_file = FileNameWithoutExt(file) + ".msk2"

            if not img:
                img = Image.CreateFromFile(utf8_encode(os.path.join(src_path, file)))

            self.log_debug("CreateOpacityMask %r %s" % (out_file, tostr(params)))
            if not self.dry_run:
                pyscript.OpacityMask.CreateOpacityMask(img, params, utf8_encode(os.path.join(self.dst_abs_path, out_file)))
            return out_file

        # else:
        self.log_error("Unknown mask format '%r': %r %r @ %r" % (mask_format, src_path, file, dbg_info))
        return False  # Unsupported format

    # Вычисляем хэш для кэша масок
    def compute_mask_hash(self, path, mask_format, settings):
        s = '[Mask]'
        if self.global_hash_salt:
            s += '|' + self.global_hash_salt
        if self.mask_hash_salt:
            s += '|' + self.mask_hash_salt
        if path:
            s += '|file=' + pyscript.fs.hash(utf8_encode(path))
        s += '|format=' + mask_format
        if settings:
            s += '|settings=' + tostr(settings)

        self.log_debug('compute_mask_hash ' + s)

        return pyscript.string.hash(utf8_encode(s))

    # Сжимаем указанный файл, используя те настройки, какие сможем найти.
    def compress_resource_file(self, path, compress_settings=None):
        with self.log_section("compress_resource_file %r %s" % (path, tostr(compress_settings)), LOG_PROGRESS):
            resource = None
            if path in self.resources_by_id:  # Если вместо path передали resource_id
                resource = self.resources_by_id[path]
                path = resource['full_path']  # (путь относительно repo_abs_path)
                self.log_debug("Resource found: %s" % tostr(resource))
            else:
                # Приводим путь относительно repo_abs_path
                if os.path.exists(os.path.join(self.repo_abs_path, path)):
                    pass  # ok
                elif os.path.exists(path):
                    path = normpath(os.path.relpath(path, self.repo_abs_path))
                    self.log_debug("rel path %r" % path)

                if not compress_settings:
                    # Пробуем найти файл в ресурсах, чтобы получить его настройки сжатия
                    for _, resources in sorted(self.resources_by_id.items()):
                        for res in resources:
                            if res['full_path'] == path:
                                resource = res  # найден
                                self.log_debug("Resource found: %s" % tostr(resource))
                                break
                        if resource:
                            break
                    if not resource:
                        for res in self.resources_atlases:
                            if res['full_path'] == path or res['id'] == path:
                                resource = res  # найден
                                self.log_debug("Resource found: %s" % tostr(resource))
                                break
            if not os.path.exists(os.path.join(self.repo_abs_path, path)):
                self.log_error("No such file: " + path)
                return
            if not compress_settings and resource:
                compress_settings = resource.get('compress')
            if not compress_settings:
                self.log_error("Can't find compress settings for: " + path + ". (Use -f,--format?)")
                return
            package_id = None
            group_id = None
            if resource:
                package_id = resource.get('package_id')
                group_id = resource.get('group_id')
                pack_settings = self.calc_default_settings(resource, package_id, group_id)
            else:
                pack_settings = self.calc_default_settings()
            pack_settings['mask'] = None  # None - по умолчанию (calc_default_settings возвращает настройку mask для атласов)
            self.compress_file(path, self.repo_abs_path, compress_settings, pack_settings, package_id, group_id, resource)

    # Функция сжатия для формата fmt_name (например, "webp")
    def compress_image(self, filename, fmt_name, settings=None, out_name=None):
        self.log_verbose("compress_image %r %r %r %r" % (fmt_name, filename, settings, out_name))

        if settings is None:
            settings = {}

        # Определяем настройки сжатия
        ext = '.dds'  # почти для всех форматов такое расширение
        fmt = None
        params = Compress.Params()
        if fmt_name == 'webp':
            fmt = Compress.Format.WebP
            ext = '.webp'
            params.webpQuality = int(settings.get('q', 100))
            params.webpAlphaQuality = int(settings.get('alpha_q', 100))
        elif fmt_name == 'pvrtc':
            fmt = Compress.Format.PVRTC4
        elif fmt_name == '2xpvrtc':
            fmt = Compress.Format.PVRTC4PVRTC4
        elif fmt_name == 'etc1':
            fmt = Compress.Format.ETC1
        elif fmt_name == 'etc2':
            fmt = Compress.Format.ETC2
        elif fmt_name == 'etc2_pvrtc':
            fmt = Compress.Format.ETC2_PVRTC4
        elif fmt_name == 'etc2etc2':
            fmt = Compress.Format.ETC2ETC2
        elif fmt_name == 'bc7':
            fmt = Compress.Format.BC7
        elif fmt_name == 'dxt5':
            fmt = Compress.Format.DXT5

        if fmt is None:
            self.log_error("Unknown compress format %r for %r" % (fmt_name, filename))
            return None

        params.etcQuality = int(settings.get('q', 100))  # для ETC
        params.pma = get_exact_setting(settings)  # не портить цвета прозрачных пикселей
        params.retina = bool_attr(settings.get('retina', True))  # обводка в 2 пикселя вместо одного
        params.toEtc1 = bool_attr(settings.get('toetc1', False))  # разрешить транскодирование в etc1 (иначе в rgba)
        params.halfPvrtc = bool_attr(settings.get('halfpvrtc', False))  # использовать уменьшенный pvrtc в etc2_pvrtc
        if 'opaque' in settings:
            params.etcOpaque = int(settings.get('opaque'))  # без альфа-канала

        # Добавляем остальные атрибуты, которые есть в CompressParams:
        for key in dir(params):
            if key in settings:
                attr_type = type(getattr(params, key))  # Конвертируем в тот тип, который нужен CompressParams
                if attr_type == bool:
                    setattr(params, key, bool_attr(settings[key]))
                    self.log_verbose("compress params.%s = %r = bool_attr(%r)", key, getattr(params, key), settings[key])
                else:
                    setattr(params, key, attr_type(settings[key]))
                    self.log_verbose("compress params.%s = %r = %r(%r)", key, getattr(params, key), attr_type, settings[key])

        if not out_name:
            out_name = FileNameWithoutExt(filename)
        if not out_name.endswith(ext):
            out_name = out_name + ext

        # Сжатие
        self._process_wrapper(lambda:
                              Compress.CompressPng(filename, fmt, params, out_name))

        return [out_name]

    # Вытаскиваем содержимое из атласа
    def unpack_atlas(self, img_abs_path, xml_path=None):
        if not xml_path:
            xml_path = FileNameWithoutExt(img_abs_path) + ".xml"

        result = []

        image = Image.CreateFromFile(utf8_encode(img_abs_path))
        doc = xml_read(xml_path)
        frames_path = doc.getroot().get('path', "")
        for frame in doc.getroot():
            tex_path = frame.get('path')
            if not tex_path:
                self.log_error("No 'path' attribute @ %s" % lxml_cur_pos(frame))
                continue
            tex_path = normpath(os.path.join(frames_path, tex_path))
            fw = int(frame.get('frameWidth', 0))
            fh = int(frame.get('frameHeight', 0))
            if fw <= 0 or fh <= 0:
                self.log_error("Wrong frameWidth=%r frameHeight=%r @ %s" % (fw, fh, lxml_cur_pos(frame)))
                continue
            x = int(frame.get('x', 0))
            y = int(frame.get('y', 0))
            w = int(frame.get('width', 0))
            h = int(frame.get('height', 0))
            ix = int(frame.get('innerX', 0))
            iy = int(frame.get('innerY', 0))
            if ix < 0:
                self.log_warning("Wrong innerX=%r @ %s" % (ix, lxml_cur_pos(frame)))
                x -= ix
                w += ix
            if iy < 0:
                self.log_warning("Wrong innerY=%r @ %s" % (iy, lxml_cur_pos(frame)))
                y -= iy
                h += iy
            if x < 0 or y < 0:
                self.log_error("Wrong frame x=%r y=%r @ %s" % (x, y, lxml_cur_pos(frame)))
                continue
            if w <= 0 or h <= 0:
                self.log_error("Wrong w=%r h=%r @ %s" % (w, h, lxml_cur_pos(frame)))
                continue
            tex_img = Image(fw, fh)
            image.CopyFromTo(x, y, w, h, tex_img, ix, iy)
            item = dict(frame.attrib)
            item['full_path'] = tex_path  # не совсем правильно, но всё равно неиспользуется
            item['image'] = tex_img
            result.append(item)
            # self.log_debug("resources_in_atlases add %r @ %r" % (tex_path, lxml_cur_pos(frame)))
        return result

# ----------------------------------------------------------------------


# Интерфейс командной строки
def main():
    parser = argparse.ArgumentParser()
    # ~ parser.add_argument('filename', help='...')
    parser.add_argument('-a', '--atlases', action='store_true', default=None, help="Pack atlases")
    parser.add_argument('-c', '--compress', action='store_true', default=None, help="Compress textures")
    parser.add_argument('-nc', '--no-compress', action='store_false',
                        dest='compress', default=None, help="Don't compress textures")
    parser.add_argument('-cf', '--compress-file', help="Compress specified file with --format")
    parser.add_argument('-f', '--format', help="Compress specified file (used with -cf,--compress-file)")
    parser.add_argument('-d', '--dst', help="Destination path (default: repo path)")
    parser.add_argument('-o', '--out', help="Output directory for atlases (relative to dst_abs_path)")
    parser.add_argument('-P', '--platform', help="Target platform ('ios', 'android', 'mac', ...)")
    parser.add_argument('-r', '--repo', default=".", help="Path to the source repository")
    parser.add_argument('-b', '--base', default="base", help="Path to 'base' directory")
    parser.add_argument('-B', '--main-base', help="Another 'base' directory")
    parser.add_argument('-s', '--settings', action='append', help="Path to AtlasSettings.xml file")
    parser.add_argument('-p', '--package', help="Pack only specified package")
    parser.add_argument('-g', '--group', help="Pack only specified group")
    parser.add_argument('-A', '--atlas', help="Pack only specified atlas")
    parser.add_argument('--log', help="Log file")
    parser.add_argument('--errors-log', help="Log file for errors")
    parser.add_argument('--warnings-log', help="Log file for warnings")
    parser.add_argument('--capture-to-log', action='store_true', help="Capture stdout and stderr to log")
    parser.add_argument('--debug', action='store_true', help="Debug logging")
    parser.add_argument('--cache', help="Cache directory")
    parser.add_argument('--cache-out', help="Cache output directory (default is cache directory)")
    # (TS):
    parser.add_argument('--rel-pkg', action='store_true', help="Resources relative to package (TS)")
    parser.add_argument('--res-xml-rel-pkg', help="AtlasResources.xml name relative to package (TS)")
    parser.add_argument('--out-rel-pkg', help="Atlas output directory relative to package (TS)")
    args = parser.parse_args()

    packer = AtlasPacker(args.repo, args.platform)
    packer.log_abs_path = args.log
    packer.log_errors_abs_path = args.errors_log
    packer.log_warnings_abs_path = args.warnings_log
    if args.debug:
        packer.log_level_stdout = logging.DEBUG
    if args.settings:
        for filename in args.settings:
            if not os.path.exists(filename) and os.path.exists(os.path.join(args.repo, filename)):
                filename = normpath(os.path.join(args.repo, filename))
            if os.path.exists(filename):
                filename = normpath(os.path.relpath(filename, args.repo))
            else:
                print("Missing settings file %r" % filename)
                continue
            packer.read_settings_xml(filename)

    if args.base is not None:
        packer.base_path = args.base
    if args.main_base is not None:
        packer.main_base = args.main_base
    if args.dst is not None:
        packer.dst_abs_path = args.dst
    if args.out is not None:
        packer.atlas_output_dir = args.out

    if args.rel_pkg:  # (TS)
        packer.resources_rel_package = True

    packer.cache_path = args.cache
    packer.cache_out_path = args.cache_out

    if args.capture_to_log:
        packer.capture_to_log = True

    if args.package is not None:
        packer.only_package = args.package.split(',')
    if args.group is not None:
        packer.only_group = args.group.split(',')
    if args.atlas is not None:
        packer.only_atlas = args.atlas.split(',')

    if args.compress_file:  # Сжимаем указанный файл
        if os.path.exists(args.compress_file):  # Приводим путь относительно repo_abs_path
            args.compress_file = normpath(os.path.relpath(args.compress_file, packer.repo_abs_path))
        packer.compress_resource_file(args.compress_file, args.format)
        return

    if args.atlases is None and args.compress is None:
        args.atlases = args.compress = True  # по умолчанию, если не задан один из параметров

    # Делаем всю работу
    packer.run(pack_atlases=args.atlases, compress=args.compress)


if __name__ == '__main__':
    main()
