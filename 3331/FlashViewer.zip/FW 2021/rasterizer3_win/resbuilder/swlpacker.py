#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
sys.dont_write_bytecode = True  # noqa: E402

import os
import shutil
import re
import argparse
import subprocess
import json
from lxml import etree
from collections import OrderedDict

import pyscript

from rescache import ResourceCache

import logging

import atlaspacker
from atlaspacker import bool_attr, xml_read, lxml_cur_pos, FileNameWithoutExt, normpath, tostr, wildcard_match, utf8_encode

# Данный скрипт обрабатывает flash-анимации по описанию в xml-файле.
# Вызывает растеризатор для преобразования swf(,fla,psd) -> swl.
# Вызывает atlaspacker для упаковки атласов.

# ----------------------------------------------------------------------


# Удаляем файл или каталог
def rm_all(path):
    if os.path.isdir(path):
        shutil.rmtree(path)
    elif os.path.exists(path):
        os.remove(path)


# Возвращает первый компонент пути (пример: path="a/b/c" -> "a")
def path_first_dir(path):
    # Используем очень тупой способ получить первый компонент пути (TODO: в python3 можно будет сделать по-нормальному)
    assert not os.path.isabs(path)
    (path, filename) = os.path.split(path)
    if path == "":  # в случае path_first_dir("filename.ext") возвращаем ""
        return path
    else:
        while path:
            (path, base_path) = os.path.split(path)
    assert base_path
    assert os.path.basename(base_path) == base_path
    return base_path

# ----------------------------------------------------------------------


class SwlPacker:
    def __init__(self, repo_abs_path, rasterizer_abs_path, platform=None):
        self.repo_abs_path = os.path.abspath(repo_abs_path)  # Путь к корневой директории игры
        self.dst_abs_path = self.repo_abs_path  # куда записывать генерируемые файлы (по умолчанию прямо в репозиторий)
        self.rasterizer_abs_path = rasterizer_abs_path  # Путь до rasterizer (ставится из пакета)
        self.platform = (platform or "")  # ios, android, win, mac, ...
        # (Параметр platform по умолчанию =None для того, чтобы удобно было передавать в него args.platform как есть.)

        # Исходные настройки по умолчанию для xml с настройками
        self.default = {
            # Настройки упаковки отдельных (одиночных) swl
            'atlas': True,  # делать атлас для одиночного swl
            # Можно установить atlas="false" в xml, если атлас для swl не нужен.
            #  Например, если атлас делается не через этот скрипт.

            # Сюда можно добавлять другие настройки по умолчанию, а лучше прописывать их в xml.
        }

        self.default_atlas = {}  # Настройки simple атласов (всё по умолчанию)

        # Логгирование и ошибки
        # Очень рекомендуется всегда писать в лог файл!
        # (Эти настройки используются в функции atlaspacker.setupLogger)
        self.log_abs_path = None  # Имя файла логов
        self.log_backup = True  # переименовывать старый лог в .bak
        # Дополнительный отдельный лог для ошибок (может быть полезно на teamcity)
        self.log_errors_abs_path = None
        # Дополнительный отдельный лог для предупреждений (может быть полезно на teamcity)
        self.log_warnings_abs_path = None

        self.log_level_stdout = logging.INFO
        self.log_level_log = logging.DEBUG
        self.log_verbose_enabled = True  # выводить подробную отладочную информацию (с полными путями)
        self.log_error_stack = True  # Добавлять стек к сообщениям об ошибке
        # Форматирование логов в стиле teamcity
        self.is_teamcity = (os.getenv('TEAMCITY', 'false') == 'true')

        self.logger = None  # инициируется при использовании

        # Кэш (см. rescache.py)
        self.cache = None  # rescache.ResourceCache
        self.cache_path = None  # (абсолютный путь)
        self.cache_out_path = None  # (абсолютный путь)
        self.cache_hashes_file = 'swlhashes.xml'  # (относительно cache_path и cache_out_path)
        self.cache_deps_file = None  # (абсолютный путь)
        self.cache_thumb = None  # костыль для замены cache.thumb (используется при тестировании)

        self.global_hash_salt = None  # Можно задать, чтобы изменить хэш и вызвать пересборку (trigger)

        # Какие шаги кэшировать
        self.cached_swf_to_swl = False
        self.cached_swf_to_atlas = False
        self.cached_swl_to_atlas = False

        self.warnings = []  # Сюда добавляются все предупреждения, возникшие в ходе работы.
        self.errors = []  # Сюда добавляются все ошибки, возникшие в ходе работы.

        self.settings_xml_loaded = []  # прочитанные файлы настроек (чтобы не было рекурсивного инклуда)
        self.swl_settings = []  # Настройки растеризации для каждого swl
        self.swl_groups = []  # Настройки групп swl для упаковки атласов: [tuple(settings, swl_settings_list)]

        self.atlas_default = []  # Общие настройки атласов
        self.compress_settings = {}  # Настройки сжатия для atlaspacker

        self.swl_sheets_xml = "SwlSheets.xml"

        # Отображение коротких синонимов параметров (как в параметрах командной строки растеризатора)
        self.abbreviated_params = {
            'aas': 'atlasautoscale',
            'aus': 'atlasupscale',
            'vso': 'vectorscaleonly',
            'as': 'atlasscale',
            'ppm': 'preprocessmode',
            'b': 'border',
            'ads': 'atlasdebugsimplepacking',
            'cs': 'codecscheme',
            'c': 'codec',
            'cp': 'codecparam',
            'cpd': 'codecparamdefault',
            'ac': 'atlascompare',
            'acp': 'atlascompareparams',
            'rc': 'roundcoords',
            'a': 'allowedcharacters',
        }

        self._own_options = {'@loc', 'atlas', 'single_pack', 'platform', 'package', 'id', 'atlasName', 'src', 'path', 'base',
                             'srcBasePath', 'basePath', 'atlasBasePath', 'swl_sheets_xml'}
        self._raster_options = {'atlasautoscale', 'atlasupscale', 'vectorscaleonly', 'atlasdebugsimplepacking',
                                'old2pixeloffset', 'placeholder', 'codecscheme', 'codec', 'atlascompare', 'swlversion',
                                'hittest', 'roundcoords', 'allowedcharacters', 'exportprefix', 'atlasscale', 'border',
                                'shadow', 'preprocessmode', 'codecparam', 'codecparamdefault', 'atlascompareparams', 'export',
                                'retina', 'fonts_path', 'postscriptfont', 'compress_paged'}
        self._atlas_options = atlaspacker.AtlasPacker()._all_pack_settings_attrs
        self._atlas_options.update(('compress', 'id', 'package', 'group'))

    def init_logger(self):
        if not self.logger:
            self.logger = logging.Logger("swlpacker")

        atlaspacker.setupLogger(self.logger, self.__dict__)

    # Логгирование
    def log(self, log_level, msg, *args, **kws):
        if not self.logger:
            self.init_logger()  # инициализируем при первом обращении
        self.logger.log(log_level, msg, *args, **kws)

    def log_info(self, msg, *args):
        self.log(logging.INFO, msg, *args)

    def log_debug(self, msg, *args):
        self.log(logging.DEBUG, msg, *args)

    def log_verbose(self, msg, *args):
        if self.log_verbose_enabled:
            self.log(logging.DEBUG, msg, *args)

    def log_warning(self, msg, *args):
        self.log(logging.WARNING, msg, *args)
        if args:
            msg = msg % args
        self.warnings.append(msg)

    def log_error(self, msg, *args):
        self.log(logging.ERROR, msg, *args)
        if args:
            msg = msg % args
        self.errors.append(msg)

    def log_progress(self, msg, *args):
        self.log(logging.INFO, msg, *args)

    def log_write(self, msg, *args):
        self.log(logging.DEBUG, msg, *args)

    def log_skip(self, msg, *args):
        self.log(logging.DEBUG, msg, *args)

    # Инициализация кэша (rescache.py)
    def init_cache(self):
        self.log_debug("Init cache: %r %r %r" % (self.cache_path, self.cache_hashes_file, self.cache_out_path))
        self.cache = ResourceCache(os.path.abspath(self.dst_abs_path), self.cache_path,
                                   self.cache_hashes_file, self.cache_out_path, copy_to_repo=True)
        if self.cache_thumb is not None:
            self.cache.thumb = self.cache_thumb
        else:
            self.cache.thumb = self._init_cache_hash()
        self.cache.init(self.cache_deps_file)

        self.cache.on_error = lambda text: self.log_warning("[cache error] " + str(text))
        self.cache.on_print = lambda text: self.log_debug(text)

    # Собираем хэш для кэша (cache.thumb)
    def _init_cache_hash(self):
        result = ""
        result += self.platform
        # resbuilder version:
        result += "|" + pyscript.string.hash(pyscript.Version)
        cur_dir = os.path.dirname(os.path.realpath(__file__))
        # rescache.py text:
        result += "|" + pyscript.fs.hash_text(utf8_encode(os.path.join(cur_dir, "rescache.py")))
        # this file text:
        result += "|" + pyscript.fs.hash_text(utf8_encode(re.sub(r"\.py\w+$", ".py", os.path.realpath(__file__))))
        self.log_debug("cache thumb %r" % result)
        return result

    # Загружаем настройки из xml файла
    def read_resources_xml(self, filename, dbg_info="", settings=None):
        # with self.log_section("read_resources_xml: %r" % filename, LOG_LOG):
        if os.path.exists(os.path.join(self.repo_abs_path, filename)):
            pass
        elif os.path.exists(filename):  # На случай, если попадётся абсолютный путь
            filename = normpath(os.path.relpath(filename, self.repo_abs_path))
        else:
            self.log_error("Can't find file: %r @ %s" % (filename, dbg_info))
            return
        if os.path.isabs(filename):
            self.log_error("File %r not in repo %r" % (filename, self.repo_abs_path))
            return

        # Проверяем, чтобы файл не загружался дважды. (Спасает от рекурсивного инклуда.)
        if filename in self.settings_xml_loaded:
            self.log_warning("Don't include %r again, skip. @ %s" % (filename, dbg_info))
            return
        self.settings_xml_loaded.append(filename)

        if settings is None:
            settings = self.default.copy()

        settings['base'] = path_first_dir(filename)

        doc = xml_read(filename, self.repo_abs_path)
        self.read_resources_xml_node(doc.getroot(), settings)

    # Читаем настройки из xml
    def read_resources_xml_node(self, node, settings):
        if node.tag.lower() == 'include':
            if node.getparent() != node.getroottree().getroot():
                self.log_error("<include> is allowed only in the root node @ %s" % lxml_cur_pos(node))
                return
            inc_path = node.get("path")
            if not inc_path:
                self.log_error("Missing 'path' attribute in <%s> node @ %s" % (node.tag, lxml_cur_pos(node)))
                return
            # Сначала смотрим относительно текущего файла, потом глобально
            loc_path = normpath(os.path.join(os.path.dirname(node.base), inc_path))
            if os.path.exists(os.path.join(self.repo_abs_path, loc_path)):
                return self.read_resources_xml(loc_path, lxml_cur_pos(node), settings)
            else:
                inc_path = normpath(inc_path)
                return self.read_resources_xml(inc_path, lxml_cur_pos(node), settings)

        # Не делаем здесь фильтр по platform, т.к. растеризуем всё подряд. Разница есть только для атласов.

        # TODO: фильтр for psd/fla/swf, for group, path, ...?

        parent_settings = settings

        settings = settings.copy()  # т.к. будем модифицировать
        settings['@loc'] = lxml_cur_pos(node)

        for key in ('id', 'atlasName', 'src', 'path'):  # не распространяется на вложенные ноды
            if key in settings:
                del settings[key]  # удаляем из только что созданной копии

        node_settings = dict(node.attrib)  # забираем все атрибуты из xml

        if node == node.getroottree().getroot():
            # Используем root attrib для настроек SwlPacker
            self.read_global_settings_xml_node(node)

        # преобразуем сокращённые атрибуты в полные
        for short, full in sorted(self.abbreviated_params.items()):
            if short in node_settings:
                if full in node_settings:
                    self.log_error("Conflicting attributes: %r and %r @ %s", short, full, lxml_cur_pos(node))
                else:
                    node_settings[full] = node_settings[short]
                    del node_settings[short]

        # Костыль для имени атласа
        # atlas="true" обозначает, что нужно делать атласы swl+png вместо "нарезки".
        # Но также можно указать atlas="atlasname", это будет работать как синоним атрибута atlasName.
        if 'atlas' in node_settings and node_settings['atlas'].lower() not in ('true', 'false'):
            if 'atlasName' not in node_settings:
                node_settings['atlasName'] = node_settings['atlas']
            else:
                self.log_error("Conflicting attributes 'atlas' and 'atlasName' @ %s" % lxml_cur_pos(node))
            node_settings['atlas'] = True

        settings.update(node_settings)

        if node.tag == 'SWL' or node.tag.lower() == 'swlgroup' or node == node.getroottree().getroot():  # рутовая нода может называться как угодно
            # Запрещаем атрибуты 'src' в групповой ноде
            for attr in ('src'):
                if node.get(attr):
                    self.log_error("Unexpected attribute %r in group node %r @ %s" % (attr, node.tag, lxml_cur_pos(node)))

            # Сначала обрабатываем вложенные ноды <default>
            default_allowed = True
            for child in node:
                if child.tag.lower() == 'default':
                    if not default_allowed:
                        self.log_error("<%s> node should go before other child nodes @ %s" % (child.tag, lxml_cur_pos(child)))
                    if not self.platform_filter(child.get('platform')):
                        self.log_skip("Skip by platform filter %r != %r @ %s", child.get('platform'), self.platform, lxml_cur_pos(child))
                        continue
                    settings.update(child.attrib)
                else:
                    if child.tag.lower() == 'swl' or child.tag.lower() == 'swlib' or child.tag.lower() == 'swlgroup':
                        default_allowed = False  # запрещаем указывать <default> ниже <swl>

            # Проверяем, нужно ли делать атлас для этой группы
            atlas_for_group = False
            if settings.get('atlasName'):
                if node == node.getroottree().getroot():
                    self.log_error("Atlas for root node is not allowed @ %s" % lxml_cur_pos(node))
                else:
                    atlas_for_group = True
                    settings['atlas'] = False  # Не делаем атласы для swl внутри группы с общим атласом
            else:
                # Костыль для групп вложенных в группу атласа
                settings['atlasName'] = parent_settings.get('atlasName')

            # Собираем swl в группе
            swl_children = []
            for child in node:
                if child.tag.lower() == 'default':
                    continue
                res = self.read_resources_xml_node(child, settings)
                if res:
                    swl_children.extend(res)

            if atlas_for_group:
                if swl_children:
                    self.swl_groups.append((settings, swl_children))
            else:
                return swl_children  # поддержка вложенных нод <swlgroup>
        elif node.tag == 'swl' or node.tag.lower() == 'swlib':
            if len(node):
                self.log_error("Unexpected children @ %s" % lxml_cur_pos(node))

            if settings.get('src'):
                self.swl_settings.append(settings)
                # TODO: проверить на уникальность имени swl, иначе перезапишет.

                if not parent_settings.get('atlasName'):
                    # Если swl не пакуется в групповой атлас, то записываем её как группу из одного swl (так удобнее)
                    self.swl_groups.append((settings, [settings]))

                if settings.get('atlas'):  # пакуется в отдельный атлас
                    if parent_settings.get('atlasName'):
                        # Это значит, что внутри группы с атласом попался элемент, у которого atlas=True,
                        # что означает, что он пакуется в отдельный атлас. Выдаём предупреждение.
                        self.log_skip("Pack %r individually, not to %r @ %s" %
                            (self.get_swl_path(settings), parent_settings.get('atlasName'), lxml_cur_pos(node)))  # noqa: E128 (indent)
                else:
                    return [settings]  # add to parent group
            else:
                self.log_error("No src path attribute @ %s" % lxml_cur_pos(node))
        elif node.tag == 'AtlasDefault':
            if node.get('id'):
                self.log_warning("Skip %r node because of 'id' @ %s" % (node.tag, lxml_cur_pos(node)))
            else:
                self.atlas_default.append(node)
        elif node.tag == 'Compress':
            # TODO: здесь копипаста с atlaspacker.read_compress_settings_node, это надо переделать
            if not self.platform_filter(node.get('platform')):
                return
            id = node.get('id')
            if id is None and node.getparent() == node.getroottree().getroot():
                id = ""  # Корневые ноды Compress задают сжатие по умолчанию
            if id is not None:
                id = id.lower()
                if id not in self.compress_settings:
                    self.compress_settings[id] = []
                self.compress_settings[id].append(node)
            if node.get('id') is None:
                for child in node:
                    self.read_resources_xml_node(child, {})
        else:
            # self.log_error("Unexpected node: <%s> @ %s" % (node.tag, lxml_cur_pos(node)))
            pass

    # platform_filter следует применять только при упаковке атласов. Растеризуем для всех платформ одинаково.
    def platform_filter(self, platform):
        if platform and self.platform and not wildcard_match(self.platform, platform):
            return False
        return True

    # Применяем настройки из рутовой ноды в атрибуты self
    def read_global_settings_xml_node(self, node):
        for key, v in sorted(node.attrib.items()):
            if hasattr(self, key):
                if type(getattr(self, key)) is str or getattr(self, key) is None:
                    self.log_debug("setattr %r %r" % (key, v))
                    setattr(self, key, v)
                elif type(getattr(self, key)) is int:
                    self.log_debug("setattr %r %r" % (key, int(v)))
                    setattr(self, key, int(v))
                elif type(getattr(self, key)) is bool:
                    self.log_debug("setattr %r %r" % (key, bool_attr(v)))
                    setattr(self, key, bool_attr(v))
                elif type(getattr(self, key)) is list:
                    self.log_debug("append %r %r" % (key, v))
                    getattr(self, key).append(v)
                else:
                    self.log_error("Can't apply setting %r @ %s" % (key, lxml_cur_pos(node)))

        # Доинициализируем логгер настройками из xml
        self.init_logger()

    # Определяет положение swl по настройкам в xml
    def get_swl_path(self, settings):
        path = settings.get('path')
        if path:
            if not path.endswith(".swl"):
                path = FileNameWithoutExt(path) + ".swl"
        elif settings.get('id'):  # from id
            path = settings.get('id') + ".swl"
        elif settings.get('src'):  # only filename
            path = FileNameWithoutExt(os.path.basename(settings.get('src'))) + ".swl"
        else:
            return None
        return normpath(os.path.join(settings.get('base', ""), settings.get('basePath', ""), path))

    # Находит исходный swf по настройкам в xml
    def get_swf_abs_path(self, settings):
        src_path = settings.get('src')
        if not src_path:
            return None
        src_path = normpath(os.path.join(settings.get('base', ""), settings.get('srcBasePath', ""), src_path))
        if not os.path.isabs(src_path):
            src_path = normpath(os.path.join(self.repo_abs_path, src_path))
        return src_path

    # Для правильного кэширования нужно
    # разделить настройки растеризации и атласов от прочих настроек
    def split_settings(self, settings):
        raster_settings = {}
        atlas_settings = {}

        for k, v in sorted(settings.items()):
            k_orig = k
            if k in self.abbreviated_params:
                k = self.abbreviated_params[k]
            found = False
            if k in self._atlas_options:
                atlas_settings[k] = v  # переносим в atlas_settings
                found = True
            if k in self._raster_options:
                raster_settings[k] = v  # переносим в raster_settings
                found = True
            if k not in self._own_options:
                if found:
                    del settings[k_orig]
                else:
                    # Либо опечатка, либо забыли прописать опцию в _own_options или _atlas_options или _raster_options.
                    self.log_error("Unknow option %r: %r = %r @ %s" % (k, k_orig, v, settings.get('@loc')))

        # для сообщений:
        raster_settings['@loc'] = settings.get('@loc')
        atlas_settings['@loc'] = settings.get('@loc')

        return (raster_settings, atlas_settings)

    # Растеризует swl из swf и, если задано в настройках, сразу пакует атлас.
    def make_swl(self, settings):
        # Определяем, какой атлас нам нужен
        need_atlas_type = None
        if bool_attr(settings.get('atlas')):
            # для одиночного swl
            need_atlas_type = settings.get('single_pack', 'simple')
        else:
            # для swl из группы
            need_atlas_type = settings.get('group_pack', 'simple')
            if need_atlas_type and need_atlas_type != 'simple':  # None or 'simple' expected
                self.log_error("Can't pack %r for swl in group! %r" % (need_atlas_type, settings.get('@loc')))
                return

        # путь к исходному swf
        src_abs_path = self.get_swf_abs_path(settings)
        if not src_abs_path:
            self.log_error("No src path @ %s" % settings.get('@loc'))
            return

        # путь к итоговому swl
        swl_path = self.get_swl_path(settings)
        if not swl_path:
            self.log_error("No out path @ %s" % settings.get('@loc'))
            return

        # разделяем настройки (настройки растеризации и атласа удаляются из settings)
        (raster_settings, atlas_settings) = self.split_settings(settings)
        # возвращаем настройки растеризации, т.к. будем делать её полюбому
        settings.update(raster_settings)
        # определяемся с настройками атласа
        if not need_atlas_type:
            # не делаем атлас
            atlas_settings = None
        elif need_atlas_type == 'simple':
            # простой прямоугольный атлас
            atlas_settings = self.default_atlas.copy()
        elif need_atlas_type == 'final':
            pass  # используем имеющиеся atlas_settings
        else:
            self.log_error("Unknown need_atlas_type: %r @ %s" % (need_atlas_type, settings.get('@loc')))
            return
        if atlas_settings:
            settings.update(atlas_settings)  # возвращаем в settings для вычисления хэша
        atlas_path = FileNameWithoutExt(swl_path)

        # Все настройки должны быть уже определены до вычисления хэша!
        cache_id = "Swl|" + swl_path
        chash = None  # cache hash
        if self.cache is None and self.cache_path:
            self.init_cache()
        if self.cache:
            # Вычисляем хэш
            chash = self.compute_swl_hash(settings, src_abs_path)
            self.log_debug("cache hash: %r" % chash)
            # Проверяем кэш
            cache_checkout = self.cache.checkout(cache_id, chash)
            if cache_checkout:
                for f in cache_checkout:
                    self.log_debug("Cache checkout: %r" % f)
                out_files = cache_checkout
                self.cache.save()
                # Удаляем старые файлы, которых нет в cache_checkout
                for f in self.find_swl_files(self.dst_abs_path, swl_path):
                    if f not in out_files:
                        self.log_write("Remove old files: %r" % f)
                        os.remove(os.path.join(self.dst_abs_path, f))
                if need_atlas_type:
                    self.register_sheets(out_files, atlas_settings, self.dst_abs_path, atlas_path)
                return out_files
            else:
                # Если dst_abs_path совпадает с out_cache_path, то следующие действия испортят кэш, поэтому удаляем из кэша.
                if self.cache.out_cache_path == self.dst_abs_path:  # not self.copy_only
                    self.cache.delete(cache_id)
                    self.cache.save()

        # TODO: if self.copy_only:

        # Растеризуем swf -> swl
        out_files = self.make_swl_impl(settings)
        if not out_files:
            self.log_error("Failed to make swl %r @ %s" % (swl_path, settings.get('@loc')))
            return

        # Делаем атлас, если требуется
        if need_atlas_type:
            swl_images = self.find_swl_images([swl_path], self.dst_abs_path)
            atlas_settings['reg_xml'] = False  # Не регистрируем в AtlasResources.xml
            atlas_settings['max_sheets'] = 1  # Пакуем на один лист
            atlas_files = self.make_atlas_impl(swl_images, atlas_settings, self.dst_abs_path, atlas_path)
            if not atlas_files:
                self.log_error("Failed to make atlas for swl %r @ %s" % (swl_path, settings.get('@loc')))
                return
            # если текстуры были сжаты в атлас, то в out_files идёт только swl и атлас
            swl_files = out_files
            out_files = atlas_files[:]  # copy
            for f in swl_files:
                if f.endswith(".swl"):
                    out_files.append(f)
                    # удаляем директорию с нарезкой
                    dir_abs_path = os.path.join(self.dst_abs_path, FileNameWithoutExt(f))
                    if os.path.isdir(dir_abs_path):
                        self.log_write("Remove packed files: %r", FileNameWithoutExt(f))
                        rm_all(dir_abs_path)
                else:
                    # удаляем остальные файлы, т.к. они были сжаты в атлас
                    if os.path.exists(os.path.join(self.dst_abs_path, f)):
                        self.log_write("Remove packed files: %r", f)
                        os.remove(os.path.join(self.dst_abs_path, f))

        self.log_debug("make_swl out files: %r", out_files)

        # cache
        if self.cache:
            self.cache.delete(cache_id)
            for res in out_files:
                assert res.find('\\') == -1, res
                self.cache.copy_file(os.path.join(self.dst_abs_path, res), self.cache.get_out_location(res))
            self.cache.update(cache_id, chash, out_files)
            self.cache.save()

        return out_files

    # Вызываем растеризатор, чтобы сделать SWL из SWF
    def make_swl_impl(self, settings):
        self.log_progress("make_swl_impl %r" % settings)

        # путь к исходному swf
        src_abs_path = self.get_swf_abs_path(settings)
        if not src_abs_path:
            self.log_error("No src path @ %s" % settings.get('@loc'))
            return

        # путь к итоговому swl
        swl_path = self.get_swl_path(settings)
        if not swl_path:
            self.log_error("No out path @ %s" % settings.get('@loc'))
            return

        swl_abs_path = normpath(os.path.join(self.dst_abs_path, swl_path))

        params = []

        # dirbase нужен для записи атласов (пути относительно этой директории)
        base_abs_path = normpath(os.path.join(self.dst_abs_path, settings.get('base')))
        params += ['--dirbase', base_abs_path]

        # dirout starts with dirbase
        (dirout_abs_path, out_name) = os.path.split(swl_abs_path)
        if not os.path.exists(dirout_abs_path):
            self.log_write("Make dir %r", normpath(os.path.relpath(dirout_abs_path, self.dst_abs_path)))
            os.makedirs(dirout_abs_path)
        params += ['--dirout', dirout_abs_path]

        params.append('-i')
        params.append(src_abs_path)

        params.append('/outname')
        params.append(FileNameWithoutExt(out_name))

        # params.append('-d')  # -d, -dd - INFO/DEBUG
        # -t, --switchtemp  - использовать curdir/tmp вместо /tmp, не удалять
        # -U, --utilitesdir - путь от растеризатора до swf-extractor'а

        # bool attributes
        for key in ('atlasautoscale', 'atlasupscale', 'vectorscaleonly', 'atlasdebugsimplepacking',
                    'old2pixeloffset', 'placeholder'):
            if bool_attr(settings.get(key)):
                params.append(("--" if len(key) > 3 else "-") + key)

        # string attributes
        for key in ('codecscheme', 'codec', 'atlascompare', 'swlversion',
                    'hittest', 'roundcoords', 'allowedcharacters', 'exportprefix',
                    'atlasscale', 'border', 'shadow', 'preprocessmode'):
            if settings.get(key):
                params.append(("--" if len(key) > 3 else "-") + key)
                params.append(settings[key])

        # append attributes
        for key in ('codecparam', 'codecparamdefault', 'atlascompareparams', 'export'):
            if settings.get(key):
                params.append(("--" if len(key) > 3 else "-") + key)
                params.extend(settings[key].split(' '))

        if bool_attr(settings.get('retina')):
            params.append('--retina')

        if settings.get('fonts_path'):  # Путь до папки с игровыми шрифтами.
            params += ['-f', normpath(os.path.join(self.repo_abs_path, settings.get('base'), settings.get('fonts_path')))]
        if settings.get('postscriptfont'):
            # Путь до JSON'а с отображением названий шрифтов в имена файлов (из папки -f).
            params += ['-pf', normpath(os.path.join(self.repo_abs_path, settings.get('base'), settings.get('postscriptfont')))]

        params.append('--errorcode')

        # Удаляем старые файлы
        imgs_dir = os.path.join(self.dst_abs_path, FileNameWithoutExt(swl_path))
        if os.path.isdir(imgs_dir):
            self.log_write("Remove old files: %r" % FileNameWithoutExt(swl_path))
            rm_all(imgs_dir)
        for f in self.find_swl_files(self.dst_abs_path, swl_path):
            self.log_write("Remove old files: %r" % f)
            rm_all(os.path.join(self.dst_abs_path, f))

        # запускаем растеризатор
        command = [self.rasterizer_abs_path] + params
        if self.rasterizer_abs_path.endswith(".py"):
            command = ["python"] + command
        self.log_verbose(str.join(" ", command))
        retcode = subprocess.call(command)
        if retcode != 0:
            self.log_error("rasterizer failed to make %r (ret code %r)" % (swl_path, retcode))
            # cleanup
            for f in self.find_swl_files(self.dst_abs_path, swl_path):
                self.log_write("Cleanup: %r" % f)
                rm_all(os.path.join(self.dst_abs_path, f))
            return
        # Проверяем получившийся swl
        if not os.path.exists(swl_abs_path):
            self.log_error("rasterizer failed to make %r" % swl_path)
            # cleanup
            for f in self.find_swl_files(self.dst_abs_path, swl_path):
                self.log_write("Cleanup: %r" % f)
                rm_all(os.path.join(self.dst_abs_path, f))
            return

        # Сжатие swl
        if bool_attr(settings.get('compress_paged')):
            size_bits = settings.get('compress_paged_size_bits', 16)
            self.log_debug("Compress paged %r %r", swl_path, size_bits)
            pyscript.Storage.PagedStream.CompressFile(swl_abs_path, size_bits)

        out_files = self.find_swl_files(self.dst_abs_path, swl_path)
        return out_files

    def compute_swl_hash(self, settings, src_abs_path):
        s = '[Swl]'
        if self.global_hash_salt:
            s += '|' + self.global_hash_salt
        s += '|ps='
        for k, v in sorted(settings.items()):
            if k.startswith('@'):  # e.g. '@loc'
                continue
            s += ("%s:%r," % (k, v))
        hashes = pyscript.fs.hash_files([utf8_encode(src_abs_path)])
        s += '|src=' + str.join(',', hashes)

        self.log_debug('compute_swl_hash %r' % s)

        return pyscript.string.hash(utf8_encode(s))

    # Находим swl и сопутствующие ему файлы
    def find_swl_files(self, root_path, out_name):
        out_name = FileNameWithoutExt(out_name)
        result = []
        # Проверяем все файлы, которые могут относиться к swl (текстуры, атласы)
        for ext in ("swl", "xml", "json", "png", "webp", "dds"):
            if os.path.exists(os.path.join(root_path, out_name + "." + ext)):
                result.append(normpath(out_name + "." + ext))
        # Проверяем каталог с текстурами для json
        if os.path.isdir(os.path.join(root_path, out_name)) \
                and os.path.exists(os.path.join(root_path, out_name + ".json")):
            for root, dirs, items in os.walk(os.path.join(root_path, out_name)):
                for filename in items:
                    f = normpath(os.path.relpath(os.path.join(root, filename), root_path))
                    result.append(f)
        result.sort()  # для стабильности
        return result

    # Используется в случае, если группы сразу пакуются в финальный атлас.
    def make_swl_group_final(self, group_settings, children):
        # Подготавливаем вспомогательные структуры
        swf_settings = {}  # swf_abs_path -> settings
        swl_settings = {}  # swl_path -> settings
        for settings in children:
            # Для swl можно указать фильтр platform="..."
            if not self.platform_filter(settings.get('platform')):
                self.log_skip("Skip by platform filter %r != %r @ %s", settings.get('platform'),
                               self.platform, settings.get('@loc'))  # noqa: E128 (indent)
                continue
            # путь к исходному swf
            src_abs_path = self.get_swf_abs_path(settings)
            if not src_abs_path:
                self.log_error("No src path @ %s" % settings.get('@loc'))
                return
            if src_abs_path in swf_settings:  # проверяем дубли
                self.log_error("Don't pack %r twice @ %s" % (src_abs_path, settings.get('@loc')))
                return
            swf_settings[src_abs_path] = settings

            # путь к итоговому swl
            swl_path = self.get_swl_path(settings)
            if not swl_path:
                self.log_error("No out path @ %s" % settings.get('@loc'))
                return
            if swl_path in swl_settings:  # проверяем дубли
                self.log_error("Don't pack to %r twice @ %s" % (swl_path, settings.get('@loc')))
                return
            swl_settings[swl_path] = settings

        atlas_name = group_settings.get('atlasName')
        if atlas_name:
            atlas_name = os.path.join(group_settings.get('base'), group_settings.get('atlasBasePath', ""), atlas_name)
        elif len(children) == 1:
            # атлас для одного swl (а не для группы) кладётся рядом с swl и называется так же
            atlas_name = FileNameWithoutExt(self.get_swl_path(children[0]))
            group_settings['reg_xml'] = False  # Не регистрируем в AtlasResources.xml
        else:
            # для swlgroup надо указывать имя атласа (иначе непонятно, какое оно)
            self.log_error("No atlasName @ %s" % (group_settings.get('@loc')))
            return

        # Все настройки должны быть уже определены до вычисления хэша!
        cache_id = "SwlAtlas|" + atlas_name
        chash = None  # cache hash
        if self.cache is None and self.cache_path:
            self.init_cache()
        if self.cache:
            # Вычисляем хэш
            hashes = []
            for src_abs_path, settings in sorted(swf_settings.items()):
                hashes.append(self.compute_swl_hash(settings, src_abs_path))
            chash = pyscript.string.hash(str.join(",", hashes))
            self.log_debug("cache hash: %r" % chash)
            # Проверяем кэш
            cache_checkout = self.cache.checkout(cache_id, chash)
            if cache_checkout:
                for f in cache_checkout:
                    self.log_debug("Cache checkout: %r" % f)
                out_files = cache_checkout
                self.cache.save()
                # Удаляем старые файлы, которых нет в cache_checkout
                for swl_path, settings in sorted(swl_settings.items()):
                    for f in self.find_swl_files(self.dst_abs_path, swl_path):
                        if f not in out_files:
                            self.log_write("Remove old files: %r" % f)
                            os.remove(os.path.join(self.dst_abs_path, f))
                self.register_sheets(out_files, group_settings, self.dst_abs_path, atlas_name)
                self.register_swl_sheets(out_files, group_settings, self.dst_abs_path)
                return out_files
            else:
                # Если dst_abs_path совпадает с out_cache_path, то следующие действия испортят кэш, поэтому удаляем из кэша.
                if self.cache.out_cache_path == self.dst_abs_path:  # not self.copy_only
                    self.cache.delete(cache_id)
                    self.cache.save()

        out_files = []

        # Растеризуем swf -> swl
        swl_images = []
        for swl_path, settings in sorted(swl_settings.items()):
            swl_out_files = self.make_swl_impl(settings)
            if not swl_out_files:
                self.log_error("Failed to make swl %r @ %s" % (swl_path, settings.get('@loc')))
                return
            out_files.extend(swl_out_files)

        swl_images = self.find_swl_images(sorted(list(swl_settings.keys())), self.dst_abs_path, True)
        if not swl_images:
            self.log_error("Missing swl images: %r @ %s" % (atlas_name, settings.get('@loc')))
            return

        # Делаем атлас
        (raster_settings, atlas_settings) = self.split_settings(group_settings.copy())
        atlas_files = self.make_atlas_impl(swl_images, atlas_settings, self.dst_abs_path, atlas_name)
        if not atlas_files:
            self.log_error("Failed to make atlas %r @ %s" % (atlas_name, settings.get('@loc')))
            return
        self.register_swl_sheets(atlas_files, group_settings, self.dst_abs_path)
        # если текстуры были сжаты в атлас, то в out_files идёт только swl и атлас
        swl_files = out_files
        out_files = atlas_files[:]  # copy
        for f in swl_files:
            if f.endswith(".swl"):
                out_files.append(f)
                # удаляем директорию с нарезкой
                dir_abs_path = os.path.join(self.dst_abs_path, FileNameWithoutExt(f))
                if os.path.isdir(dir_abs_path):
                    self.log_write("Remove packed files: %r", FileNameWithoutExt(f))
                    rm_all(dir_abs_path)
            else:
                # удаляем остальные файлы, т.к. они были сжаты в атлас
                if os.path.exists(os.path.join(self.dst_abs_path, f)):
                    self.log_write("Remove packed files: %r", f)
                    os.remove(os.path.join(self.dst_abs_path, f))

        self.log_debug("make_swl_group_final out files: %r", out_files)

        # cache
        if self.cache:
            self.cache.delete(cache_id)
            for res in out_files:
                assert res.find('\\') == -1, res
                self.cache.copy_file(os.path.join(self.dst_abs_path, res), self.cache.get_out_location(res))
            self.cache.update(cache_id, chash, out_files)
            self.cache.save()

        return out_files

    def find_swl_images(self, swls, root_path, strict=False):
        files = []  # files = [ {id: tex_id, path: filename, n: 0), (id: atlas.xml, path: atlas.png, n: 0) ]
        for n, swl_path in enumerate(swls):
            swl_abs_path = normpath(os.path.join(root_path, swl_path))
            if os.path.isdir(FileNameWithoutExt(swl_abs_path)) and os.path.exists(FileNameWithoutExt(swl_abs_path) + ".json"):
                # "нарезка" - загружаем json файл и берём список текстур из него
                json_file = FileNameWithoutExt(swl_abs_path) + ".json"
                with open(json_file) as json_fh:
                    textures = json.load(json_fh)
                    if not textures:
                        self.log_skip("  No textures in %r", json_file)
                        continue
                    # вычисляем base_path как первый компонент пути swl_path
                    base_path = path_first_dir(swl_path)

                    for t in textures:
                        path = t.get('path')
                        if not path:
                            continue
                        tex_id = t.get('id')
                        if not tex_id:
                            tex_id = path

                        path = normpath(os.path.join(base_path, path))

                        if not os.path.exists(os.path.join(root_path, path)):
                            self.log_skip("  No texture %r @ %r", os.path.join(root_path, path), json_file)
                            continue
                        files.append({'id': tex_id, 'path': path, 'n': n})
            elif os.path.exists(FileNameWithoutExt(swl_abs_path) + ".xml") and os.path.exists(FileNameWithoutExt(swl_abs_path) + ".png"):
                # готовый атлас
                files.append({'id': FileNameWithoutExt(swl_path) + ".xml", 'path': FileNameWithoutExt(swl_path) + ".png", 'n': n})
            else:
                self.log_skip("  No textures: %r", swl_abs_path)
                if strict:
                    return None
                continue

        return files

    def compute_atlas_hash(self, atlas_settings, files, root_path):
        s = '[SwlAtlas]'
        if self.global_hash_salt:
            s += '|' + self.global_hash_salt
        s += '|ps='
        for k, v in sorted(atlas_settings.items()):
            if k.startswith('@'):  # e.g. '@loc'
                continue
            s += tostr(v) + ","

        s += '|src=' + str.join(',', pyscript.fs.hash_files([utf8_encode(os.path.join(root_path, f)) for f in files]))

        self.log_debug('compute_atlas_hash %r' % s)

        return pyscript.string.hash(utf8_encode(s))

    def get_packer(self, root_path, base_path):
        packer = atlaspacker.AtlasPacker(repo_abs_path=root_path, platform=self.platform)
        packer.dst_abs_path = self.dst_abs_path
        packer.base_path = base_path
        packer.cache = self.cache
        packer.cache_path = self.cache_path
        packer.cache_out_path = self.cache_out_path
        packer.logger = self.logger
        packer.atlas_default = self.atlas_default
        packer.compress_settings = self.compress_settings
        packer.atlas_register_id = False
        return packer

    def detect_base_path(self, files, dbg_info=""):
        # Определяем base_path на основе путей в списке files.
        # Все файлы должны лежать в одинаковом base!
        base_path = None
        for f in files:
            base = path_first_dir(f)
            if base_path is None:
                base_path = base
            elif base_path == base:
                pass  # ok
            else:
                self.log_error("Base dir mismatch (%r != %r) @ %s" % (base, base_path, dbg_info))
        return base_path

    # Делаем атласы для swl
    def make_atlas_impl(self, swl_images, settings, root_path, out_name):
        self.log_progress("make_atlas_impl %r %r %r %r" % (out_name, root_path, len(swl_images), settings))
        self.log_debug(swl_images)

        if not swl_images:
            return

        base_path = self.detect_base_path([elem.get('path') for elem in swl_images], settings.get('@loc'))
        packer = self.get_packer(root_path, base_path)

        atlas_content = []  # содержимое атласа

        for elem in swl_images:
            if elem['id'].endswith(".xml"):  # atlas
                # Распаковываем атлас
                self.log_debug("Unpack atlas %r", elem['path'])
                atlas_items = packer.unpack_atlas(os.path.join(root_path, elem['path']))
                for item in atlas_items:
                    res = {}
                    res['@loc'] = elem['id']
                    res['groupId'] = elem['n']  # номер группы для групповой упаковки атласов: все изображения из группы попадут на один лист
                    res['type'] = 'texture'
                    res['id'] = item.get('id')
                    res['path'] = item.get('path')  # путь относительно base
                    res['full_path'] = normpath(os.path.join(base_path, item.get('path')))
                    # full_path не будет использоваться упаковщиком, так как есть image:
                    res['image'] = item.get('image')

                    if 'package' in settings:
                        res['package'] = settings['package']

                    atlas_content.append(res)
            else:
                res = {}
                res['@loc'] = elem['path']
                res['groupId'] = elem['n']  # номер группы для групповой упаковки атласов: все изображения из группы попадут на один лист
                res['type'] = 'texture'
                res['id'] = elem['id']
                res['path'] = os.path.relpath(elem['path'], base_path)
                if not os.path.exists(os.path.join(root_path, elem['path'])):
                    self.log_error("Missing file %r @ %s", os.path.join(root_path, elem['path']))
                res['full_path'] = elem['path']

                if 'package' in settings:
                    res['package'] = settings['package']

                atlas_content.append(res)

        atlas_id = settings.get('id')  # обычно None
        package_id = settings.get('package')  # обычно None
        group_id = settings.get('group')  # обычно None
        pack_settings = settings.copy()
        packer.calc_atlas_settings(None, package_id, group_id, pack_settings)

        loc = settings.get('@loc')
        if settings.get('single_pack') == 'final':
            compress_settings = packer.calc_compress_settings(settings.get('compress'), loc,
                    out_name, package_id, group_id, {'type': 'atlas'})  # noqa: E128 (indent)
        else:
            compress_settings = packer.parse_compress_str("", loc)

        res = packer.pack_atlas_impl(pack_settings, compress_settings, atlas_content,
                atlas_id or settings.get('atlasName'), package_id, group_id, out_name, loc)  # noqa: E128 (indent)
        if not res:
            self.log_error("Failed to pack atlas %r @ %s" % (out_name, loc))
            return
        (out_sheets, out_files) = res

        packer.register_sheets(out_sheets, out_name, atlas_id, package_id, group_id, pack_settings, loc)

        return out_files

    # Эта функция используется для регистрации атласов при восстановлении из кэша
    def register_sheets(self, out_files, settings, root_path, atlas_path, packer=None):
        out_sheets = []
        swl_name = ""
        for f in out_files:
            if f.endswith(".xml"):
                out_sheets.append(FileNameWithoutExt(f))
            if f.endswith(".swl"):
                swl_name = f

        if len(out_sheets) == 1 and out_sheets[0] == FileNameWithoutExt(swl_name):
            # Не регистрируем в AtlasResources.xml, если имя атласа совпадает с swl
            return

        atlas_id = settings.get('id')  # обычно None
        package_id = settings.get('package')  # обычно None
        group_id = settings.get('group')  # обычно None
        loc = settings.get('@loc')

        if not packer:
            base_path = self.detect_base_path(out_sheets)
            packer = self.get_packer(root_path, base_path)

        packer.register_sheets(out_sheets, atlas_path, atlas_id, package_id, group_id, settings, loc)

    # Вытаскиваем из атласов информацию по анимациям и регистрируем её в отдельном файле (SwlSheets.xml)
    def register_swl_sheets(self, out_files, settings, root_path):
        self.log_progress("register_swl_sheets %r %r %r" % (out_files, settings, root_path))
        # Читаем атласы
        swl_to_sheets = {}
        for f in out_files:
            if f.endswith(".xml"):
                doc = xml_read(os.path.join(root_path, f))
                for frame in doc.getroot():
                    frame_id = frame.get('id')
                    anim = os.path.dirname(frame_id)
                    swl_to_sheets[anim] = f

        # Сохраняем инфу
        swl_sheets_xml = os.path.join(settings.get('base'), settings.get('swl_sheets_xml', self.swl_sheets_xml))
        if os.path.exists(os.path.join(root_path, swl_sheets_xml)):
            doc = xml_read(swl_sheets_xml, root_path)
            root = doc.getroot()
        else:
            root = etree.Element('Resources')

        # Удаляем старую регистрацию
        to_delete = []
        for elem in root.findall('SwlSheet'):
            if elem.get('swl') in swl_to_sheets:
                to_delete.append(elem)
        for node in to_delete:
            self.log_debug("  remove old swl-to-sheet record %r %r" % (node.get('swl'), node.get('sheet')))
            root.remove(node)

        # Добавляем новые записи
        for swl, sheet in swl_to_sheets.items():
            elem = etree.SubElement(root, 'SwlSheet', OrderedDict())
            elem.attrib['swl'] = swl
            # Убираем base (первый компонент пути)
            path = normpath(os.path.relpath(sheet, path_first_dir(sheet)))
            elem.attrib['sheet'] = path
            self.log_debug("  add swl-to-sheet record %r %r" % (swl, path))

        # Сохраняем в файл
        etree.ElementTree(root).write(os.path.join(root_path, swl_sheets_xml),
                                      xml_declaration=True, encoding='utf-8', pretty_print=True)

    def make_final_atlas(self, group_settings, children, root_path):
        self.log_debug("make_final_atlas %r @ %s" % (group_settings, group_settings.get('@loc')))

        # root_path - где лежат swl и их текстуры (обычно это repo_abs_path)
        if not root_path:
            root_path = self.repo_abs_path

        # собираем swl'ки для упаковки их текстур в атлас
        swls = []
        for settings in children:
            # Для swl можно указать фильтр platform="..."
            if not self.platform_filter(settings.get('platform')):
                self.log_skip("Skip by platform filter %r != %r @ %s", settings.get('platform'),
                              self.platform, settings.get('@loc'))
                continue
            swls.append(self.get_swl_path(settings))

        settings = group_settings.copy()
        (raster_settings, atlas_settings) = self.split_settings(settings)  # удаляет из settings то, что возвращает
        # atlas_settings возвращаем, а raster_settings выкидываем, чтобы не мешался в хэше для кэша
        settings.update(atlas_settings)

        atlas_name = group_settings.get('atlasName')
        if atlas_name:
            atlas_name = os.path.join(group_settings.get('base'), group_settings.get('atlasBasePath', ""), atlas_name)
        elif len(children) == 1:
            # атлас для одного swl (а не для группы) кладётся рядом с swl и называется так же
            atlas_name = FileNameWithoutExt(self.get_swl_path(children[0]))
            settings['reg_xml'] = False  # Не регистрируем в AtlasResources.xml
        else:
            # для swlgroup надо указывать имя атласа (иначе непонятно, какое оно)
            self.log_error("No atlasName @ %s" % (group_settings.get('@loc')))
            return

        # Собираем изображения для упаковки в атлас (обязательно одним вызовом)
        swl_images = self.find_swl_images(swls, root_path)
        if not swl_images:
            self.log_error("Missing swl images: %r @ %s" % (atlas_name, group_settings.get('@loc')))
            return

        # Если всего одна swl с атласом - здесь уже не нужно ничего упаковывать, оставим так
        if len(swls) == 1 and len(swl_images) == 1 and swl_images[0].get('id').endswith(".xml"):
            if FileNameWithoutExt(swl_images[0].get('id')) == atlas_name:
                self.log_debug("Swl already has a single atlas: %r @ %s" % (atlas_name, settings.get('@loc')))
                return
            else:
                self.log_error("Atlas name mismatch: %r != %r" % (swl_images[0].get('id'), atlas_name))

        self.log_debug("make atlas %r %r @ %s" % (atlas_name, settings, settings.get('@loc')))

        # Check cache
        cache_id = "SwlAtlas|" + atlas_name
        chash = None
        out_files = None
        if self.cache is None and self.cache_path:
            self.init_cache()
        if self.cache:
            chash = self.compute_atlas_hash(settings, [elem.get('path') for elem in swl_images], root_path)
            self.log_debug("check cache: %r %r", cache_id, chash)
            # Проверяем кэш
            cache_checkout = self.cache.checkout(cache_id, chash)
            if cache_checkout:
                for f in cache_checkout:
                    self.log_debug("Cache checkout: %r" % f)
                out_files = cache_checkout
                self.cache.save()
                # Удаляем старые файлы, которых нет в cache_checkout
                base_path = self.detect_base_path([elem.get('path') for elem in swl_images], settings.get('@loc'))
                packer = self.get_packer(root_path, base_path)
                for swl_path in swls:
                    for f in packer.find_atlas_files(self.dst_abs_path, atlas_name):
                        if f not in out_files:
                            self.log_write("Remove old atlas files: %r" % f)
                            os.remove(os.path.join(self.dst_abs_path, f))
                self.register_sheets(out_files, settings, root_path, atlas_name)
                self.register_swl_sheets(out_files, settings, root_path)
                return out_files
            else:
                # Если dst_abs_path совпадает с out_cache_path, то следующие действия испортят кэш, поэтому удаляем из кэша.
                if self.cache.out_cache_path == self.dst_abs_path:  # not self.copy_only
                    self.cache.delete(cache_id)
                    self.cache.save()

        out_files = self.make_atlas_impl(swl_images, atlas_settings, root_path, atlas_name)
        if not out_files:
            self.log_error("Failed to make atlas %r" % atlas_name)
            return

        self.register_swl_sheets(out_files, group_settings, root_path)

        # cache
        if self.cache:
            self.cache.delete(cache_id)
            for f in out_files:
                assert f.find('\\') == -1, f
                self.cache.copy_file(os.path.join(self.dst_abs_path, f), self.cache.get_out_location(f))
            self.cache.update(cache_id, chash, out_files)
            self.cache.save()

        return out_files

    # Растеризуем все swl файлы (Step 1)
    # (но не делаем финальные атласы, если это не указано явно)
    def make_swl_all(self):
        self.log_debug("make_swl_all")
        for settings in self.swl_settings:
            self.make_swl(settings)

    # Делаем финальные атласы (Step 2)
    # Предполагается, что swl уже сделаны и лежат в root_path.
    def make_final_atlases(self):
        self.log_debug("make_final_atlases")

        # root_path - где лежат swl и их текстуры (обычно это repo_abs_path)
        root_path = self.repo_abs_path

        for item in self.swl_groups:
            (group_settings, children) = item

            if not group_settings.get('atlasName'):
                continue

            # Для группы можно указать фильтр platform="..."
            if not self.platform_filter(group_settings.get('platform')):
                self.log_skip("Skip by platform filter %r != %r @ %s" %
                        (group_settings.get('platform'), self.platform, group_settings.get('@loc')))  # noqa: E128 (indent)
                continue

            self.make_final_atlas(group_settings, children, root_path)

    # Растеризуем все swl и сразу делаем финальные атласы, в том числе для групп. (Step 1 + 2)
    def make_swl_all_final(self):
        self.log_debug("make_swl_all_final")

        for item in self.swl_groups:
            (group_settings, children) = item
            print(group_settings)
            self.make_swl_group_final(group_settings, children)

    # Вспомогательная функция для CLI
    def make_by_name(self, name, final=False):
        # Пытаемся найти swl или группу по указанному имени и собрать.
        # Если также указано final, то собираем сразу с финальным атласом.

        for item in self.swl_groups:
            (group_settings, children) = item

            if group_settings.get('atlasName') == name:
                # Если группа указана по имени атласа, то собираем сразу с атласом
                return self.make_swl_group_final(group_settings, children)

            if group_settings.get('id') == name:
                if final:
                    self.make_swl_group_final(group_settings, children)
                else:
                    for settings in children:
                        self.make_swl(settings)
                return True

        for settings in self.swl_settings:
            if settings.get('id') == name:
                if final:
                    settings['atlas'] = True
                    settings['single_pack'] = 'simple'
                return self.make_swl(settings)
            if FileNameWithoutExt(settings.get('path')) == FileNameWithoutExt(name):
                if final:
                    settings['atlas'] = True
                    settings['single_pack'] = 'simple'
                return self.make_swl(settings)
        # ничего не нашли
        return False


# Конвертирует ResourcesFlash.xml в новый формат
def convert_xml(filename, root_path, out_file=None):
    if os.path.exists(filename):
        filename = os.path.relpath(filename, root_path)
        if out_file:
            out_file = os.path.relpath(out_file, root_path)

    items_by_group = {}  # group -> []

    doc = xml_read(filename, root_path)
    root = doc.getroot()
    to_delete = []
    for base_node in root.findall('SWL') + root.findall('SWLGroup'):
        to_delete.append(base_node)
        for node in base_node.findall('SWLib'):
            swl_item = {}
            group = ""
            for attr, v in sorted(node.attrib.items()):
                if attr == 'id':
                    swl_item['id'] = v
                elif attr == 'format':
                    if v == "png":
                        continue
                    swl_item['compress'] = v
                elif attr == 'group':
                    group = v
                elif attr == 'path':
                    swl_item['path'] = v
                elif attr == 'scheme':
                    swl_item['codecscheme'] = v
                elif attr == 'sourcePath':
                    swl_item['src'] = os.path.join("..", v)
                elif attr == 'autoscale':
                    swl_item['atlasautoscale'] = v
                elif attr == 'prefix':
                    swl_item['exportprefix'] = v
                elif attr == 'vector_scale_only':
                    swl_item['vectorscaleonly'] = v
                elif attr == 'width':
                    swl_item['width'] = v
                else:
                    raise Exception("Unknown attribute: %r @ %s" % (attr, lxml_cur_pos(node)))

            if group not in items_by_group:
                items_by_group[group] = []
            items_by_group[group].append(swl_item)

    for node in to_delete:
        root.remove(node)

    to_move = []
    for group, items in items_by_group.items():
        if len(items) == 1:
            to_move.append(group)
    if to_move:
        if "" not in items_by_group:
            items_by_group[""] = []
        for group in to_move:
            items_by_group[""].extend(items_by_group[group])
            del items_by_group[group]

    for group, items in sorted(items_by_group.items()):
        swlgroup = etree.SubElement(root, 'SWLGroup', OrderedDict())
        if group:
            swlgroup.attrib['group'] = group
            swlgroup.attrib['atlasName'] = "flash_" + group

        srcBasePath = None
        basePath = None
        if len(items) > 1:
            for swl_item in items:
                if swl_item.get('src'):
                    if srcBasePath is None:
                        srcBasePath = swl_item.get('src')
                    else:
                        srcBasePath = os.path.commonprefix([srcBasePath, swl_item.get('src')])
                if swl_item.get('path'):
                    if basePath is None:
                        basePath = swl_item.get('path')
                    else:
                        basePath = os.path.commonprefix([basePath, swl_item.get('path')])
            if srcBasePath:
                srcBasePath = os.path.dirname(srcBasePath)
                for swl_item in items:
                    if swl_item.get('src'):
                        swl_item['src'] = os.path.relpath(swl_item['src'], srcBasePath)
                swlgroup.attrib['srcBasePath'] = srcBasePath
            if basePath:
                basePath = os.path.dirname(basePath)
                for swl_item in items:
                    if swl_item.get('path'):
                        swl_item['path'] = os.path.relpath(swl_item['path'], basePath)
                swlgroup.attrib['basePath'] = basePath

            # Выносим часто повторяющиеся атрибуты в групповую ноду
            attr_count = {}  # attr -> value -> count
            for swl_item in items:
                for attr, v in swl_item.items():
                    if attr not in attr_count:
                        attr_count[attr] = {}
                    attr_count[attr][v] = attr_count[attr].get(v, 0) + 1
                    attr_count[attr]['_total'] = attr_count[attr].get('_total', 0) + 1
            for attr in attr_count:
                if attr_count[attr]['_total'] < len(items):
                    continue  # Не можем вынести атрибут, если он есть не во всех нодах (потому что его будет никак не отменить)
                total_half = attr_count[attr]['_total'] / 2 + 1
                for v, count in attr_count[attr].items():
                    if v == '_total':
                        continue
                    if count >= total_half:
                        if attr in {'id', 'atlasName', 'src', 'path'}:  # на всякий случай
                            continue
                        swlgroup.attrib[attr] = v  # записываем в групповую ноду
                        for swl_item in items:
                            if swl_item.get(attr) == v:
                                del swl_item[attr]

        for swl_item in items:
            item_xml = etree.SubElement(swlgroup, 'SWLib', OrderedDict())
            for attr, v in sorted(swl_item.items()):
                item_xml.attrib[attr] = v

    if not out_file:
        out_file = filename  # overwrite

    etree.ElementTree(root).write(out_file, xml_declaration=True, encoding='utf-8', pretty_print=True)


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument('-R', '--rasterizer', help=".../rasterizer3.py")
    parser.add_argument('-r', '--repo', default=".", help="Path to the source repository")
    parser.add_argument('-P', '--platform', help="Target platform ('ios', 'android', 'mac', ...)")
    parser.add_argument('-a', '--all-swl', action='store_true', help="Make all swl files")
    parser.add_argument('-f', '--final', action='store_true', help="Make final swl files and atlases")
    parser.add_argument('-nc', '--no-compress', action='store_false',
                        dest='compress', default=None, help="Don't compress textures (for debug)")
    parser.add_argument('--log', help="Log file")
    parser.add_argument('--errors-log', help="Log file for errors")
    parser.add_argument('--warnings-log', help="Log file for warnings")
    parser.add_argument('--cache', help="Cache directory")
    parser.add_argument('--cache-out', help="Cache output directory (default is cache directory)")
    parser.add_argument('--convert', nargs="+", help="Convert FlashResources.xml to new format. Please specify repo path with -r.")
    parser.add_argument('-b', '--base', help="Scan base directory")
    parser.add_argument('names', nargs="*", help='some files')

    args = parser.parse_args()

    if args.convert:
        if not args.repo:
            raise Exception("Please specify --repo")
        if len(args.convert) == 1:
            convert_xml(args.convert[0], args.repo)
        else:
            convert_xml(args.convert[0], args.repo, args.convert[1])
        return

    swl_packer = SwlPacker(args.repo, args.rasterizer, args.platform)

    swl_packer.log_abs_path = args.log
    swl_packer.log_errors_abs_path = args.errors_log
    swl_packer.log_warnings_abs_path = args.warnings_log

    swl_packer.cache_path = args.cache
    swl_packer.cache_out_path = args.cache_out

    for filename in args.names:
        if filename.endswith(".xml"):
            swl_packer.read_resources_xml(filename)
        else:
            ok = swl_packer.make_by_name(filename, args.final)
            if not ok:
                print("Can't make %r" % args.name)

    if args.all_swl or args.final:
        if args.base:  # scan base dir
            for root, dirs, items in os.walk(args.base):
                for name in items:
                    if name.endswith('.xml'):
                        file = os.path.join(root, name)

                        with open(file, 'rb') as f:
                            head = f.read(4096)
                            f.close()

                        if head.find(b'<Resources>') >= 0:
                            swl_packer.read_resources_xml(file)
        if not args.rasterizer:
            raise Exception("Please specify --rasterizer")

    if not args.names and not args.base:
        raise Exception("Please specify -base <path/to/base> to scan for resources.")

    if args.all_swl and args.final:
        swl_packer.make_swl_all_final()
        return

    if args.all_swl:
        swl_packer.make_swl_all()

    if args.final:
        swl_packer.make_final_atlases()

    if swl_packer.warnings:
        print("Finished with %d warnings:" % len(swl_packer.warnings))
        for msg in swl_packer.warnings:
            print(msg)

    if swl_packer.errors:
        print("Finished with %d errors:" % len(swl_packer.errors))
        for msg in swl_packer.errors:
            print(msg)


if __name__ == '__main__':
    main()
