#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
sys.dont_write_bytecode = True  # noqa: E402

import os
import shutil
import json
from lxml import etree
from collections import OrderedDict

import pyscript

global_utils_binary_hashes = {}
global_utils_text_hashes = {}


# ====================================================
# Если нужно создает папки, только однопоточная работа
def ensure_path(path):
    if not os.path.exists(path):
        os.makedirs(path)


# singular or plural
def plural(amount, word_singular, word_plural):
    return str(amount) + ' ' + (word_singular if amount == 1 or amount == -1 else word_plural)


# хеш объекта
def hash_of_object(object, skip_fields=[]):
    d = pyscript.ObjectToDict(object)
    if skip_fields:
        d = {k: v for k, v in d.items() if k not in skip_fields}
    s = '[' + str(object.__class__) + ']'
    s = s + json.dumps(d, sort_keys=True)
    # print(s)

    return pyscript.string.hash(s)


# ======================================
# Проект общего кэша
class ResourceCache:
    # Инициализирует пустой неактивный кэш
    def __init__(self, repo_path, in_cache_path, rel_hashes_file, out_cache_path, copy_to_repo):
        self.repo_path = repo_path

        self.in_cache_path = in_cache_path
        self.out_cache_path = out_cache_path if out_cache_path else in_cache_path

        self.in_hashes_file = os.path.join(self.in_cache_path, rel_hashes_file)
        self.out_hashes_file = os.path.join(self.out_cache_path, rel_hashes_file)

        self.active = False
        self.thumb = ''
        self.resources = {}
        self.dirty = False
        self.bucket = ''
        self.copy_to_repo = copy_to_repo
        self.inplace_cache = (self.in_cache_path == self.out_cache_path)

    class Resource:
        def __init__(self, id):
            self.id = id
            self.buckets = {}

    class Bucket:
        def __init__(self):
            self.source_hash = None
            self.files = []
            self.useful = False

    def on_error(self, text):
        raise Exception(text)

    def on_print(self, text):
        print(text)

    # Копирует файл по абсолютным путям
    def copy_file(self, in_file, out_file):
        if os.path.exists(in_file):
            if os.path.abspath(in_file) != os.path.abspath(out_file):
                try:
                    ensure_path(os.path.dirname(out_file))
                    shutil.copyfile(in_file, out_file)
                except IOError:
                    self.on_error('cache: Failed copy file \'' + in_file + '\' to \'' + out_file + '\'')
                    return False
        else:
            self.on_error('cache: File not found \'' + in_file + '\'')
            return False
        return True

    # Перемещает файл по абсолютным путям
    def move_file(self, in_file, out_file):
        if os.path.exists(in_file):
            if in_file != out_file:
                try:
                    ensure_path(os.path.dirname(out_file))
                    shutil.move(in_file, out_file)
                except IOError:
                    self.on_error('cache: Failed move file \'' + in_file + '\' to \'' + out_file + '\'')
                    return False
        else:
            self.on_error('cache: File not found \'' + in_file + '\'')
            return False
        return True

    # Включает кэширование, рассчитывает зависимости, пробует загрузить сохраненное состояние
    def init(self, deps_file, deps_platform=None):
        if self.inplace_cache:
            self.on_print('cache: init ' + self.in_cache_path)
        else:
            self.on_print('cache: init ' + self.in_cache_path + ' -> ' + self.out_cache_path)

        if os.path.exists(self.repo_path):
            ensure_path(self.out_cache_path)

        if deps_file:
            if os.path.exists(deps_file):
                doc = etree.parse(deps_file)

                for file_node in doc.getroot().findall('file'):
                    path = os.path.join(self.repo_path, file_node.get('path')).replace('\\', '/')
                    if os.path.exists(path):
                        xpath = file_node.get('xpath')
                        if xpath:
                            s = ''
                            for node in etree.parse(path).getroot().findall(xpath):
                                s += pyscript.string.hash_text(etree.tostring(node, pretty_print=False))
                            self.thumb += pyscript.string.hash(s)
                        elif file_node.get('text') == 'true':
                            if path not in global_utils_text_hashes:
                                global_utils_text_hashes[path] = pyscript.fs.hash_text(path)
                            self.thumb += global_utils_text_hashes[path]
                        else:
                            if path not in global_utils_binary_hashes:
                                global_utils_binary_hashes[path] = pyscript.fs.hash(path)
                            self.thumb += global_utils_binary_hashes[path]
                    else:
                        self.on_error('cache: absent dependency ' + path)
            else:
                self.on_error('cache: absent dependencies description ' + deps_file)

        if deps_platform:
            self.thumb += pyscript.string.hash(deps_platform)

        if self.thumb:
            self.thumb = pyscript.string.hash(self.thumb)

            self.on_print('cache: utils_hash=' + self.thumb)

        if os.path.exists(self.in_hashes_file):
            doc = etree.parse(self.in_hashes_file)

            utils_hash = doc.getroot().get('utils_hash')
            if utils_hash == self.thumb or not utils_hash or not self.thumb:
                count = 0
                for resource_node in doc.getroot().findall('resource'):
                    id = resource_node.get('id')
                    if id in self.resources:
                        resource = self.resources[id]
                    else:
                        resource = self.Resource(id)
                        self.resources[id] = resource

                    bucket = resource_node.get('bucket')
                    if bucket in resource.buckets:
                        group = resource.buckets[bucket]
                    else:
                        group = self.Bucket()
                        resource.buckets[bucket] = group

                    source_hash = resource_node.get('source_hash')
                    group.source_hash = source_hash

                    for file_node in resource_node.findall('file'):
                        path = file_node.get('path')
                        group.files.append(path)

                    count += 1
            elif self.in_cache_path == self.out_cache_path and self.out_cache_path != self.repo_path:
                count = 0
                for resource_node in doc.getroot().findall('resource'):
                    bucket = resource_node.get('bucket')
                    folder = os.path.join(self.out_cache_path, bucket) if bucket else self.out_cache_path

                    for file_node in resource_node.findall('file'):
                        path = file_node.get('path')

                        file = os.path.join(folder, path)
                        if os.path.exists(file):
                            os.remove(file)

                    count += 1

                self.on_print('cache: cleaned ' + plural(count, 'resource', 'resources') + ' from ' + self.in_hashes_file)
            else:
                self.on_print('cache: utils_hash mismatch: %r != %r' % (utils_hash, self.thumb))
        else:
            self.on_print('cache: no in_hash file: %r' % self.in_hashes_file)

        self.active = True
        self.dirty = False

    # Выключает кэширование, без сохранения
    def debug_done(self):
        self.active = False
        self.thumb = ''
        self.resources = {}
        self.dirty = False
        self.bucket = ''

    # Очищает кэш
    def clear(self):
        if len(self.resources):
            if self.in_cache_path == self.out_cache_path:
                for id in self.resources:
                    resource = self.resources[id]
                    for bucket in resource.buckets:
                        group = resource.buckets[bucket]
                        for name in group.files:
                            file = os.path.join(self.out_cache_path, bucket, name) if bucket else os.path.join(self.out_cache_path, name)
                            if os.path.exists(file):
                                os.remove(file)
            self.resources = {}
            self.dirty = True

    # Сохраняет кэш
    def save(self):
        root = etree.Element('cache', utils_hash=self.thumb)

        for id in sorted(self.resources):
            resource = self.resources[id]

            for bucket in sorted(resource.buckets):
                group = resource.buckets[bucket]

                record = etree.SubElement(root, 'resource', OrderedDict())
                record.attrib['bucket'] = bucket
                record.attrib['id'] = id
                record.attrib['source_hash'] = group.source_hash
                for file in sorted(group.files):
                    felem = etree.SubElement(record, 'file', OrderedDict())
                    felem.attrib['path'] = file

        etree.ElementTree(root).write(self.out_hashes_file, xml_declaration=True, encoding='utf-8', pretty_print=True)

        self.dirty = False

    # Задает текущий bucket
    def set_current_bucket(self, bucket):
        self.bucket = bucket

    # Возвращает массив всех id ресурсов, которые есть в кэше
    def debug_get_ids(self):
        return [id for id in sorted(self.resources)]

    # Возвращает путь относительно root для вычисления name
    # file обязательно с путем к root
    def get_name(self, file):
        return os.path.relpath(file, self.repo_path).replace('\\', '/')

    # Возвращает положение элемента в input кэше
    # name относительно root
    def get_in_location(self, name):
        if not self.active:
            return None

        return os.path.join(self.in_cache_path, self.bucket, name) if self.bucket else os.path.join(self.in_cache_path, name)

    # Возвращает положение элемента в output кэше
    # name относительно root
    def get_out_location(self, name):
        if not self.active:
            return None

        return os.path.join(self.out_cache_path, self.bucket, name) if self.bucket else os.path.join(self.out_cache_path, name)

    # Проверяет статус ресурса, возвращает None или массив относительных путей файлов
    def find(self, id, hash):
        if self.active:
            if id in self.resources:
                resource = self.resources[id]
                if self.bucket in resource.buckets:
                    group = resource.buckets[self.bucket]
                    if group.source_hash == hash:
                        group.useful = True
                        return [name for name in group.files]
        return None

    # Удаляет ресурс и его выходные файлы
    def delete(self, id):
        if self.active:
            if id in self.resources:
                resource = self.resources[id]
                if self.bucket in resource.buckets:
                    group = resource.buckets[self.bucket]
                    for name in group.files:
                        file = self.get_out_location(name)
                        if os.path.exists(file):
                            os.remove(file)

                    del resource.buckets[self.bucket]
                    self.dirty = True

                if not len(resource.buckets):
                    del self.resources[id]
                    self.dirty = True

    # Добавляет ресурс, предыдущие данные нужно было обязательно удалить
    def add(self, id, hash, names):
        if self.active:
            if id in self.resources:
                resource = self.resources[id]
            else:
                resource = self.Resource(id)
                self.resources[id] = resource

            if self.bucket in resource.buckets:
                self.on_error('cache: Please delete resource \'' + id + '\' from bucket \'' + self.bucket + '\' before calling add')
                resource.buckets[self.bucket].useful = True
            else:
                group = self.Bucket()
                group.source_hash = hash
                group.files = [name for name in names]
                group.useful = True
                resource.buckets[self.bucket] = group

                self.dirty = True

    # Удаляет неиспользуемые записи из кэша в текущем bucket
    def clean(self):
        if self.active:
            for id in self.resources:
                resource = self.resources[id]
                if self.bucket in resource.buckets:
                    group = resource.buckets[self.bucket]
                    if not group.useful:
                        for name in group.files:
                            file = self.get_out_location(name)
                            if os.path.exists(file):
                                os.remove(file)

                        del resource.buckets[self.bucket]
                        self.dirty = True

    # В деструкторе тоже вызываем save на всякий пожарный
    def __del__(self):
        if self.active and self.dirty:
            self.save()

    # Копирует файлы ресурса из входного кэша в репозиторий
    def peek_files(self, names):
        if self.active:
            if self.copy_to_repo:
                ok = True
                for name in names:
                    in_file = self.get_in_location(name)
                    out_file = os.path.join(self.repo_path, name)
                    if not self.copy_file(in_file, out_file):
                        ok = False
                return ok
            else:
                return self.test_files_exist(names)
        else:
            return False

    # Копирует файлы ресурса из выходного кэша в репозиторий
    def peek_out_files(self, names):
        if self.active:
            if self.copy_to_repo:
                ok = True
                for name in names:
                    in_file = self.get_out_location(name)
                    out_file = os.path.join(self.repo_path, name)
                    if not self.copy_file(in_file, out_file):
                        ok = False
                return ok
            else:
                return self.test_out_files_exist(names)
        else:
            return False

    # Проверяет наличие файлов ресурса в кеше
    def test_files_exist(self, names):
        if self.active:
            for name in names:
                in_file = self.get_in_location(name)
                if not os.path.exists(in_file):
                    self.on_error('cache: File not found \'' + in_file + '\'')
                    return False
        return True

    # Проверяет наличие файлов ресурса в кеше
    def test_out_files_exist(self, names):
        if self.active:
            for name in names:
                out_file = self.get_out_location(name)
                if not os.path.exists(out_file):
                    self.on_error('cache: File not found \'' + out_file + '\'')
                    return False
        return True

    # Проверяет статус ресурса, возвращает None если нужно пересоздать
    def checkout(self, id, hash):
        names = self.find(id, hash)
        if names is None:
            self.delete(id)
            return None

        if not self.test_files_exist(names):  # вызывает on_error внутри в случае чего
            return None

        if not self.inplace_cache:
            ok = True
            for name in names:
                in_file = self.get_in_location(name)
                out_file = self.get_out_location(name)
                if not self.copy_file(in_file, out_file):
                    ok = False
            if not ok:
                return None

        if self.copy_to_repo:
            ok = self.peek_files(names)
            if not ok:
                return None  # Не должно происходить, уже проверили всё выше. Но вдруг.

        self.on_print('cache: ok ' + id)

        return names

    # Перемещает файл в выходной кэш. Желательно их сразу там создавать
    def stage_file(self, names, name):
        in_file = os.path.join(self.repo_path, name)
        out_file = self.get_out_location(name)
        ok = self.move_file(in_file, out_file)
        if ok:
            names.append(name)
        return ok

    # Добавляет массив выходных файлов в список
    def append_out_files(self, names, files):
        # Check:
        for file in files:
            if not os.path.exists(file):
                self.on_error("cache: File not found %r" % file)
                return False

        folder = os.path.join(self.out_cache_path, self.bucket) if self.bucket else self.out_cache_path
        for file in files:
            name = os.path.relpath(file, folder).replace('\\', '/')
            names.append(name)

        return True

    # Обновляет ресурс
    def update(self, id, hash, names):
        if self.active:
            self.on_print('cache: ' + id + ' updated (' + hash + ')')

            self.add(id, hash, names)

            return self.peek_out_files(names)
        else:
            return False

    # Обновляет ресурс
    def update_files(self, id, hash, files):
        if self.active:
            names = []
            out_folder = os.path.join(self.out_cache_path, self.bucket) if self.bucket else self.out_cache_path

            for file in files:
                if not os.path.isabs(file):
                    self.on_error("relative file path not allowed " + file)
                    return False
                if not os.path.exists(file):
                    self.on_error('cache: File not found: %r' % file)
                    return False

            for file in files:
                if os.path.commonprefix([file, out_folder]) == out_folder:
                    name = os.path.relpath(file, out_folder).replace('\\', '/')
                    names.append(name)
                elif os.path.commonprefix([file, self.repo_path]) == self.repo_path:
                    name = os.path.relpath(file, self.repo_path).replace('\\', '/')
                    self.stage_file(names, name)
                else:
                    self.on_error("bad file location " + file)
                    continue

            return self.update(id, hash, names)
        else:
            return False
