#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
sys.dont_write_bytecode = True  # noqa: E402

import os
import importlib
import inspect

sys.path.insert(0, os.path.dirname(os.path.abspath(inspect.getsourcefile(lambda: None))))
importlib.import_module('pyscript')
