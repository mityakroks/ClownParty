#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
sys.dont_write_bytecode = True  # noqa: E402

import os
import subprocess
import argparse
import re
from lxml import etree

import pyscript
from pyscript import Shader, ShaderSourceType

# ----------------------------------------------------------------------
# Данный скрипт:
# 1) Конвертирует opengl шейдеры в metal.
# 2) Компилирует metallib. Для компиляции используется xcrun (часть Xcode), работает только на Mac.
# ----------------------------------------------------------------------


# Декоратор для однократного вызова функции
class Once:
    def __init__(self, f):
        self.f = f
        self.called = False

    def __call__(self, *args, **kwargs):
        if not self.called:
            self.called = True
            return self.f(*args, **kwargs)


def set_timestamp(timestamp, filename):
    if os.path.isfile(filename):
        os.utime(filename, (timestamp, timestamp))


# Вспомогательная функция для чтения булевых флагов из xml
def bool_attr(v, strict=True):
    if v is None:
        return v
    if type(v) == bool:
        return v
    if type(v) == str:
        vv = v.strip().lower()
        if vv == 'true' or vv == '1':
            return True
        if vv == 'false' or vv == '0':
            return False
    if strict:
        raise Exception("Bool value expected: '%r'" % (v))
    else:
        return v


# превращает список списков в плоский список: [[1,2],[3,4]] -> [1,2,3,4]
def flatten(v):
    res = []
    if isinstance(v, list) or isinstance(v, tuple) or isinstance(v, type({}.keys())) or isinstance(v, type({}.values())):
        for f in v:
            if isinstance(f, list) or isinstance(f, tuple) or isinstance(f, type({}.keys())) or isinstance(f, type({}.values())):
                res.extend(list(f))
            else:
                res.append(f)
    else:
        res.append(v)
    return res


def exec_cmd(cmd, filename_out, timestamp):
    if isinstance(cmd, list) or isinstance(cmd, tuple):
        cmd = flatten(cmd)
        rv = subprocess.call(cmd)
    else:
        rv = os.system(cmd)
    if rv != 0:
        raise Exception('Failed to run ' + str(cmd) + '\nExit code = ' + str(rv))
    if os.path.isfile(filename_out):
        set_timestamp(timestamp, filename_out)
    else:
        raise Exception('Missing output file \'' + filename_out + '\'. Command: ' + str(cmd))


# Вспомогательная функция для чтения xml
def xml_read(filename):
    doc = etree.parse(filename, parser=etree.XMLParser(
        remove_comments=True, remove_blank_text=True))
    doc.docinfo.URL = filename
    return doc


# Возвращает имя файла и номер строки для lxml ноды. Для сообщений об ошибках.
def lxml_cur_pos(node):
    if node is None:
        return ""
    return str(node.base) + ":" + str(node.sourceline)


def FileNameWithoutExt(path):
    (res, ext) = os.path.splitext(path)
    return res

# ----------------------------------------------------------------------


class ShaderProcessor:
    def __init__(self):
        self.current_platform = 'ios'  # android / ios / ...
        self.base_path = ""  # используется для поиска шейдеров
        self.out_path = self.base_path  # куда записывать результат
        self.check_timestamp = True  # Можно отключить для полной пересборки
        self.shader_inc_path = None  # для инклудов (относительно base_path)
        self.global_xml = None  # записывать информацию о шейдерах в один общий xml
        self.quiet = None  # не использовать print

        self.output_processed = None  # сохранять обработанный текст шейдера
        self.output_meta_xml = None  # сохранять мета-информацию в xml (см. также global_xml)
        self.output_metal = None  # сохранять metal шейдер
        self.output_metalair = None  # сохранять .air файлы (промежуточный этап компиляции metal)
        self.output_metallib = None  # генерировать .metallib
        self.output_metallib_sdk = 'iphoneos' # С какой SDK собираем: iphoneos / iphonesimulator / ...

        # По умолчанию генерируем один общий metallib (иначе установить None):
        self.global_lib = os.path.join(self.out_path, "default.metallib")

        self.cleanup_files = True  # удалять промежуточные файлы (False для отладки)

        self.cube_default = True  # Какие шейдеры генерить по умолчанию
        self.combined_default = True

        self.resources = {}
        self.global_xml_data = None  # информация о шейдерах (xml node)

        # timestamp используется для определения того, что файлы изменились
        self.tool_timestamp = os.path.getmtime(re.sub(r"\.py\w+$", ".py", os.path.realpath(__file__)))

    # Информация о шейдерной программе
    class ShaderResource:
        def __init__(self):
            self.id = None
            self.v_file = None  # vsh file
            self.f_file = None  # fsh file
            self.dbg_info = ""  # информация для сообщений об ошибке

            self.timestamp = 0

            self.variants = None

            self.f_parsed = None
            self.v_parsed = None
            self.inc_files = []

            self.defines = []
            self.meta = {}

    def on_print(self, msg):
        if self.quiet:
            return
        print(msg)

    def file_changed(self, timestamp, filename):
        if not self.check_timestamp:
            return True
        if not os.path.isfile(filename):
            return True
        if abs(os.path.getmtime(filename) - timestamp) >= 0.01:
            return True
        return False

    # Записываем в файл и сразу ставим timestamp
    def write_file(self, filename, text, timestamp):
        if sys.version_info[0] >= 3:  # py3
            text = text.encode('utf-8')
        f = open(filename, 'wb')
        f.write(text)
        f.close()
        self.on_print("write %r" % filename)
        if timestamp:
            set_timestamp(timestamp, filename)

    # Генерируем .metal, если есть изменения
    def make_metal(self, sh, filename_metal=None):
        if filename_metal is None:
            filename_metal = os.path.join(self.out_path, sh.id + ".metal")

        # Проверяем, были ли изменения
        if self.file_changed(sh.timestamp, filename_metal):
            if sh.variants is not None:
                cube_allowed = sh.variants.get('cube', self.cube_default)
                combined_allowed = sh.variants.get('combined', self.combined_default)
            else:
                cube_allowed = None
                combined_allowed = None

            # Prepare sources
            sources = []
            names = []
            source_v = self.get_source(sh, ShaderSourceType.Vertex, cube_allowed, combined_allowed)
            if self.output_processed:  # for debug
                self.write_file(os.path.join(self.out_path, sh.id + ".processed.vsh"), source_v, sh.timestamp)
            sources.append(source_v)
            names.append(sh.id + "_vertex")

            source_f = self.get_source(sh, ShaderSourceType.Fragment, cube_allowed, combined_allowed)
            if self.output_processed:  # for debug
                self.write_file(os.path.join(self.out_path, sh.id + ".processed.fsh"), source_f, sh.timestamp)
            sources.append(source_f)
            names.append(sh.id + "_fragment")

            try:
                out = Shader.TranslateMetal(sources, names, cube_allowed or combined_allowed)  # throws exception on error
                if not out:
                    raise Exception("Unknown error")
            except Exception as e:
                raise Exception("Failed to make metal from %r and %r @ %s: %r" % (sh.v_file, sh.f_file, sh.dbg_info, str(e)))

            self.write_file(filename_metal, out, sh.timestamp)

        return filename_metal

    # Генерируем .air, если есть изменения
    def make_air(self, sh, filename_air=None):
        if filename_air is None:
            filename_air = os.path.join(self.out_path, sh.id + ".air")

        # Проверяем, были ли изменения
        if self.file_changed(sh.timestamp, filename_air):
            # Пересобираем .metal
            filename_metal = self.make_metal(sh)

            self.make_air_impl(filename_metal, filename_air, sh.timestamp)

            # cleanup
            if self.cleanup_files and not self.output_metal:
                os.remove(filename_metal)

        return filename_air

    # Команда для генерации .air
    def make_air_impl(self, metal_files, filename_air, timestamp):
        cmd = [ 'xcrun',
                '--sdk', self.output_metallib_sdk,
                'metal',
                {
                    'iphoneos'        : '-mios-version-min=10.0',
                    'iphonesimulator' : '-mios-simulator-version-min=10.0'
                } [self.output_metallib_sdk],
                flatten(metal_files),
                '-c',
                '-o', filename_air]
        self.on_print("> %s" % str.join(" ", flatten(cmd)))
        exec_cmd(cmd, filename_air, timestamp)

    # Генерируем .metallib, если есть изменения
    def make_metallib(self, shs, filename_metallib):
        # Проверяем, были ли изменения хотя бы в одном из шейдеров.
        timestamp = self.tool_timestamp
        for sh in flatten(shs):
            timestamp = max(timestamp, sh.timestamp)
        if self.file_changed(timestamp, filename_metallib):
            # Если хотя бы один файл поменялся, то придётся пересобирать все .air файлы
            air_files = []
            for sh in flatten(shs):
                filename_air = self.make_air(sh)
                air_files.append(filename_air)

            self.make_metallib_impl(air_files, filename_metallib, timestamp)

            # cleanup
            if self.cleanup_files and not self.output_metalair:
                for f in air_files:
                    os.remove(f)

    # Команда для генерации metallib
    def make_metallib_impl(self, air_files, filename_metallib, timestamp):
        cmd = ['xcrun', '--sdk', self.output_metallib_sdk, 'metallib', flatten(air_files), '-o', filename_metallib]
        self.on_print("> %s" % str.join(" ", flatten(cmd)))
        exec_cmd(cmd, filename_metallib, timestamp)

    # оптимизируем шейдер при помощи glsl_optimizer
    def optimize_glsl(self, filename, sh_type, filename_out, timestamp=None, preprocess=False):
        with open(filename, 'rb') as f:
            source = f.read()
            if sys.version_info[0] >= 3:  # py3
                source = source.decode("utf-8")

        prepend = "#version 100\n"  # 100 обозначает GL ES

        inc_files = []

        if preprocess:
            pr = pyscript.ShaderPreprocessorGLSL()
            inc_files = pr.Init(source, sh_type, filename, self.shader_inc_path or "shaders")
            if pr.HasErrors():
                raise Exception("optimize_glsl errors in %s: %s" % (filename, pr.GetErrors()))
            # Генерируем текст шейдера
            settings = {}
            settings['ignore_platform'] = True  # Нам нужна указанная платформа, а не текущая
            if self.current_platform == 'win':
                prepend += "#define ENGINE_TARGET_WIN32\n"
                prepend += "#define ENGINE_OS_WINDOWS\n"
            elif self.current_platform == 'mac':
                prepend += "#define ENGINE_TARGET_MACOS\n"
                prepend += "#define ENGINE_OS_MACOS\n"
            elif self.current_platform == 'ios':
                prepend += "#define ENGINE_TARGET_IPHONE\n"
                prepend += "#define ENGINE_OS_IOS\n"
            elif self.current_platform == 'android':
                prepend += "#define ENGINE_TARGET_ANDROID\n"
                prepend += "#define ENGINE_OS_ANDROID\n"
            elif self.current_platform == 'linux':
                prepend += "#define ENGINE_TARGET_LINUX\n"
                prepend += "#define ENGINE_OS_LINUX\n"
            else:
                raise Exception("Unexpected platform %r" % self.current_platform)
            source = pr.GetShaderText(settings, "")
            if pr.HasErrors():
                raise Exception("optimize_glsl errors in %s: %s" % (filename, pr.GetErrors()))

        source = prepend + source

        res = Shader.GlslOptimize(source, sh_type)
        if not res:
            raise Exception("Failed to optimize shader: %r" % filename)

        if timestamp is None:
            timestamp = max(self.tool_timestamp, os.path.getmtime(filename))

        if inc_files:
            # Учитываем все заинклуженные файлы в timestamp
            for f in inc_files:
                timestamp = max(timestamp, os.path.getmtime(os.path.join(self.base_path, f)))

        self.write_file(filename_out, res, timestamp)

    # Парсим шейдер, получаем метаинформацию
    def parse(self, filename, sh_type, sh):
        # Читаем файл целиком
        with open(os.path.join(self.base_path, filename), 'rb') as f:
            source = f.read()
            if sys.version_info[0] >= 3:  # py3
                source = source.decode("utf-8")

        pr = pyscript.ShaderPreprocessorGLSL()
        inc_files = pr.Init(source, sh_type, filename, self.shader_inc_path or "shaders")
        if pr.HasErrors():
            raise Exception("%s @ %s" % (pr.GetErrors(), sh.dbg_info))

        if inc_files:
            # Учитываем все заинклуженные файлы в timestamp
            for f in inc_files:
                sh.timestamp = max(sh.timestamp, os.path.getmtime(os.path.join(self.base_path, f)))

        sh.inc_files.extend(inc_files)
        meta = pr.GetMetadata()
        if pr.HasErrors():
            raise Exception("%s @ %s" % (pr.GetErrors(), sh.dbg_info))
        # Merge meta into sh.meta
        if meta.get('supportsMultiblend') is True:
            sh.meta['supportsMultiblend'] = True
        if meta.get('constants'):
            if 'constants' not in sh.meta:
                sh.meta['constants'] = {}
            # TODO: здесь можно проверять, чтобы не было конфликтов в метаинформации
            sh.meta['constants'].update(meta['constants'])

        if sh_type == ShaderSourceType.Vertex:
            sh.v_parsed = pr
        if sh_type == ShaderSourceType.Fragment:
            sh.f_parsed = pr

    # Генерируем текст шейдера
    def get_source(self, sh, sh_type, cube_allowed, combined_allowed):
        if sh_type == ShaderSourceType.Vertex:
            pr = sh.v_parsed
        if sh_type == ShaderSourceType.Fragment:
            pr = sh.f_parsed
        if not pr:
            raise Exception("Not parsed @ %s", sh.dbg_info)

        # Добавляем пользовательские дефайны из xml
        user_defines = ""
        for elem in sh.defines:
            user_defines += '#define ' + elem + '\n'

        # Генерируем текст шейдера
        settings = {}
        settings['ignore_platform'] = True  # Добавим сами как надо
        if cube_allowed or combined_allowed:
            settings['advanced'] = True
            settings['template_metal'] = True
            settings['template_metal_cube'] = cube_allowed
            settings['template_metal_combined'] = combined_allowed
        source = pr.GetShaderText(settings, user_defines)
        if pr.HasErrors():
            raise Exception("%s @ %s" % (pr.GetErrors(), sh.dbg_info))

        # version must appear on the first line
        prepend = "#version 100\n"  # 100 обозначает GL ES

        if self.output_metal or self.output_metalair or self.output_metallib:
            # Добавляем #define GLSL_TO_METAL при преобразовании шейдеров в metal.
            # Этот макрос может использоваться для изменения шейдера для большей совместимости с metal.
            prepend += '#define METAL_API\n'
            # Чтобы не было коллизии с ключевым словом sampler при компиляции Metal
            prepend += "#define sampler sampler_\n"

        if self.current_platform == 'ios':
            prepend += "#define ENGINE_TARGET_IPHONE\n"
            prepend += "#define ENGINE_OS_IOS\n"
        else:
            raise Exception("Unexpected platform @ %s" % sh.dbg_info)

        source = prepend + source

        return source

    # Сохраняем информацию о шейдере в xml файл.
    def make_meta_xml(self, shs, filename_meta):
        # Проверяем, были ли изменения хотя бы в одном из шейдеров.
        timestamp = self.tool_timestamp
        for sh in flatten(shs):
            timestamp = max(timestamp, sh.timestamp)
        if self.file_changed(timestamp, filename_meta):
            if os.path.exists(filename_meta):
                doc = xml_read(filename_meta)
                root = doc.getroot()
            else:
                root = etree.Element('root')

            for sh in flatten(shs):
                # Удаляем, если такая нода уже есть
                to_remove = []
                for node in root.findall('shader'):
                    if node.get('name') == sh.id:
                        to_remove.append(node)
                for node in to_remove:
                    root.remove(node)

                # Добавляем ноду
                node = etree.Element('shader')
                node.attrib['name'] = sh.id

                metas = {}  # Информация от ShaderPreprocessorGLSL
                if 'constants' in sh.meta:
                    metas = sh.meta['constants']

                if metas.get('supportsMultiblend'):
                    pragma = doc.createElement('pragma')
                    pragma.attrib['v'] = 'supports_multiblend'
                    node.append(pragma)

                auto_constants = set(pyscript.GetAutoShaderConstantNames())

                for name, meta in sorted(metas.items()):
                    if name in auto_constants:
                        continue
                    elem = etree.Element('uniform')
                    elem.attrib['name'] = name

                    is_texture = False
                    if meta.excludeFromShaderConstants:
                        elem.attrib['excludeFromShaderConstants'] = "true"

                    if meta.type == pyscript.ShaderConstantParamType.Float:
                        elem.attrib['type'] = "float"
                    elif meta.type == pyscript.ShaderConstantParamType.Int:
                        elem.attrib['type'] = "int"
                    else:
                        is_texture = True

                    if not is_texture:
                        elem.attrib['elementCount'] = str(meta.elementCount)
                        elem.attrib['size'] = str(meta.size)

                    # Метаинформация из комментариев:
                    if meta.isColor:
                        elem.attrib['color'] = "true"

                    if meta.rangeMin or meta.rangeMax:
                        elem.attrib['range'] = "%.6g,%.6g" % (meta.rangeMin, meta.rangeMax)

                    defaultValue = meta.defaultValue
                    while defaultValue and defaultValue[-1] == 0:  # выкидываем лишние нули
                        defaultValue.pop()
                    if defaultValue:
                        elem.attrib['default'] = str.join(",", ["%.6g" % (x) for x in defaultValue])

                    if len(elem.attrib) <= 1:  # ничего, кроме name
                        continue  # пропускаем атрибуты без всякой информации (обычно это сэмплеры)

                    node.append(elem)

                if len(node) > 0:
                    root.append(node)

            if len(root) > 0:
                etree.ElementTree(root).write(filename_meta, xml_declaration=True, encoding='utf-8', pretty_print=True)

    # Читаем из описания advanced шейдеров в xml атрибуты вариантов (regular, combined, ...)
    def read_variants(self, node, result=None):
        if result is None:
            result = {}

        # Фильтр по платформе (<variant platform="android" combined="true"/>)
        node_platform = node.get('platform')
        if node_platform and self.current_platform:
            if node_platform != self.current_platform:
                return

        variant_attrs = ('combined', 'cube')

        # Синтаксис <shader variants="combined,cube"/>
        attr_variants = node.get('variants')
        if attr_variants:
            if result:
                raise Exception("Conflicting variants declaration at %s" % (lxml_cur_pos(node)))
            result = {}  # в variants="..." полное перечисление, поэтому очищаем
            for attr in attr_variants.split(','):
                if attr not in variant_attrs:
                    raise Exception("Unexpected variant: %r at %s" % (attr, lxml_cur_pos(node)))
                result[attr] = 1
            for attr in variant_attrs:
                if attr not in result:
                    result[attr] = 0

        for attr in variant_attrs:
            v = node.get(attr)
            if v is not None:
                v = bool_attr(v)
                if v and attr in result and not result[attr]:  # нельзя объявлять =true, если уже было =false
                    raise Exception("Conflicting variant declaration: %r at %s" % (attr, lxml_cur_pos(node)))
                result[attr] = v

        return result

    # Создаём объект ShaderResource
    def create_shader_resource(self, sh_id, v_file, f_file):
        sh = ShaderProcessor.ShaderResource()
        sh.id = sh_id
        sh.v_file = v_file
        sh.f_file = f_file

        sh.timestamp = max(self.tool_timestamp,
                           os.path.getmtime(os.path.join(self.base_path, sh.v_file)),
                           os.path.getmtime(os.path.join(self.base_path, sh.f_file)))

        # Сразу парсим. Нам нужно знать все заинклуженные файлы, чтобы понять, нужно ли пересобирать шейдер.
        self.parse(sh.v_file, ShaderSourceType.Vertex, sh)
        self.parse(sh.f_file, ShaderSourceType.Fragment, sh)
        pyscript.ShaderPreprocessorGLSL.LinkShaders(sh.v_parsed, sh.f_parsed)

        return sh

    # Обрабатываем ноду <shader> из ресурсного xml
    def process_resources_node(self, elem, xml_timestamp):
        sh_id = elem.get('id')
        if not re.match(r'^[\w_]+$', sh_id):
            raise Exception("Shader id isn't valid: '{}' @ {}".format(sh_id, lxml_cur_pos(elem)))

        v_file = FileNameWithoutExt(elem.get('vs')) + '.vsh'
        f_file = FileNameWithoutExt(elem.get('ps')) + '.fsh'

        sh = self.create_shader_resource(sh_id, v_file, f_file)
        sh.dbg_info = lxml_cur_pos(elem)  # номер строки в xml файле
        sh.timestamp = max(sh.timestamp, xml_timestamp)  # Чтобы учесть изменения в настройках

        variants = self.read_variants(elem)

        # Парсим <define> и прочие дочерние теги
        for child in elem:
            if child.tag == 'define':
                if child.text:
                    sh.defines.append(child.text)
                else:
                    raise Exception('Can\'t parse <define> tag %r @ %s' % (child.toprettyxml(), lxml_cur_pos(child)))
            elif child.tag == 'supports_multiblend':
                sh.meta['supportsMultiblend'] = True
            elif child.tag == 'variants':
                self.read_variants(child, variants)
            else:
                raise Exception('Unsupported shader child %r @ %s' % (child.tag, lxml_cur_pos(child)))

        if elem.tag == 'advancedShader':
            sh.variants = variants
        else:
            assert len(variants) == 0, "Variants are allowed for advancedShader only: %s" % lxml_cur_pos(elem)

        # Проверяем дубликаты по id
        if sh_id in self.resources:
            raise Exception('Duplicate shader resource %r: %s VS %s' % (sh_id, self.resources[sh_id].dbg_info, lxml_cur_pos(elem)))

        self.resources[sh_id] = sh

    def process_resources_xml(self, filename_xml):
        xmldoc = xml_read(filename_xml)
        elems = xmldoc.xpath('/Resources/Shaders/shader|/Resources/Shaders/advancedShader')
        if not elems:
            return
        xml_timestamp = os.path.getmtime(filename_xml)
        for elem in elems:
            self.process_resources_node(elem, xml_timestamp)

    def process_base(self):
        if self.base_path is None:
            raise Exception("Please specify search path")
        resources_xml = gather_resource_files(os.path.join(self.base_path, "."))
        for f in resources_xml:
            self.process_resources_xml(f)

    def finish(self):
        output_meta_xml = self.output_meta_xml
        if output_meta_xml is None:
            output_meta_xml = self.output_metallib
        shs = [sh for key, sh in sorted(self.resources.items())]
        for sh in shs:
            if self.output_metal:
                self.make_metal(sh)
            if self.output_metalair:
                self.make_air(sh)
            if self.output_metallib and not self.global_lib:
                filename_metallib = os.path.join(self.out_path, sh.id + ".metallib")
                self.make_metallib(sh, filename_metallib)
            if output_meta_xml and not self.global_xml:
                filename_meta = os.path.join(self.out_path, sh.id + ".meta.xml")
                if os.path.exists(filename_meta):
                    os.remove(filename_meta)
                self.make_meta_xml(sh, filename_meta)

        # Собираем общий .metallib
        if self.output_metallib and self.global_lib:
            self.make_metallib(shs, self.global_lib)

        # Записываем общий .meta.xml
        if output_meta_xml and self.global_xml:
            if os.path.exists(self.global_xml):
                os.remove(self.global_xml)
            self.make_meta_xml(shs, self.global_xml)


# ----------------------------------------------------------------------


# Обходит указанный каталог (base) и находит все ресурсные файлы
def gather_resource_files(path):
    res = []
    for root, dirs, items in os.walk(path):
        for name in items:
            if name.endswith('.xml'):
                file = os.path.join(root, name)

                with open(file, 'rb') as f:
                    head = f.read(4096)
                    f.close()

                if head.find(b'<Resources>') >= 0:
                    res.append(file)
    return res


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('in_file', nargs="*", help='xml file or shader file')
    parser.add_argument('--base-path', help='path to base')
    parser.add_argument('--out-path', help='where to put files')
    parser.add_argument('--inc-path', help='shader include path (relating to base, default: "shaders")')
    parser.add_argument('--processed', action='store_true', help='write .processed file')
    parser.add_argument('--meta', action='store_true', help='write .meta.xml')
    parser.add_argument('--no-meta', action='store_true', help='don\'t write .meta.xml')
    parser.add_argument('--no-combined', action='store_true', help='don\'t write .meta.xml')
    parser.add_argument('--no-cube', action='store_true', help='don\'t write .meta.xml')
    parser.add_argument('--metal', action='store_true', help='convert to metal source')
    parser.add_argument('--metalair', action='store_true', help='compile metal shader to intermediate representation')
    parser.add_argument('--metallib', nargs="?", const=True, help='compile metallib')
    parser.add_argument('--metallib-sdk', choices=['iphoneos', 'iphonesimulator'], default='iphoneos', help='Metallib SDK variant')
    parser.add_argument('--id', help="Shader name. Is used to make function name in metal shader")
    parser.add_argument('--optgl', action='store_true', help='optimize glsl shader')
    parser.add_argument('--global-xml', help='write meta-info to global xml file')
    parser.add_argument('-f', dest='check_timestamp', action='store_false', default=True, help='don\'t check timestamps')
    parser.add_argument('--no-cleanup', dest='cleanup_files', action='store_false', default=True, help='don\'t clean intermediate files')
    parser.add_argument('-q', dest='quiet', action='store_true', help='don\'t print messages')
    parser.add_argument('--scanres', action='store_true', help='scan base dir for Resources xml')  # TODO: base path as parameter?
    parser.add_argument('--platform', help='Platform: ios or android')
    args = parser.parse_args()

    if args.base_path is None:
        if args.in_file:
            if os.path.isdir(args.in_file[0]):
                args.base_path = args.in_file[0]
                args.in_file.pop(0)

    if args.base_path:
        args.base_path = os.path.abspath(args.base_path)
        pyscript.MountDirectory(args.base_path)

    sp = ShaderProcessor()
    sp.base_path = args.base_path
    if args.out_path:
        sp.out_path = args.out_path
    if args.inc_path:
        sp.shader_inc_path = args.inc_path

    sp.output_processed = args.processed
    if args.meta:
        sp.output_meta_xml = True
    if args.no_meta:
        sp.output_meta_xml = False
    sp.output_metal = args.metal
    sp.output_metalair = args.metalair
    sp.output_metallib_sdk = args.metallib_sdk
    if args.metallib:
        sp.output_metallib = True
        if type(args.metallib) is str:
            sp.global_lib = args.metallib
        else:
            sp.global_lib = None
    sp.global_xml = args.global_xml
    sp.check_timestamp = args.check_timestamp
    sp.cleanup_files = args.cleanup_files
    sp.quiet = args.quiet
    if args.platform:
        sp.current_platform = args.platform

    if args.no_cube:
        sp.cube_default = False
    if args.no_combined:
        sp.combined_default = False

    if args.scanres:
        if args.base_path is None:
            raise Exception("Please specify search path")
        resources_xml = gather_resource_files(os.path.join(args.base_path, "."))
        for f in resources_xml:
            sp.process_resources_xml(f)

    filename_vsh = None
    filename_fsh = None
    air_files = []
    metal_files = []
    for filename in args.in_file:
        # Обрабатываем файл в зависимости от его расширения
        if re.search(r'\.xml$', filename):
            sp.process_resources_xml(filename)
        elif re.search(r'\.(vsh|vert\w*)$', filename):
            filename_vsh = filename
        elif re.search(r'\.(fsh|frag\w*)$', filename):
            filename_fsh = filename
        elif re.search(r'\.air$', filename):
            air_files.append(filename)
        elif re.search(r'\.metal$', filename):
            metal_files.append(filename)
        else:
            raise Exception('Unsupported file type: ' + filename)

    if filename_vsh or filename_fsh:
        if filename_vsh and sp.base_path and os.path.exists(filename_vsh):
            filename_vsh = os.path.relpath(filename_vsh, sp.base_path)
        if filename_fsh and sp.base_path and os.path.exists(filename_fsh):
            filename_fsh = os.path.relpath(filename_fsh, sp.base_path)

        if sp.output_metal or sp.output_metalair or sp.output_metallib:
            if not filename_vsh or not filename_fsh:
                raise Exception("Expected both vsh and fsh files to process")
            sh_id = (args.id or FileNameWithoutExt(filename_vsh))
            sp.resources[sh_id] = sp.create_shader_resource(sh_id, filename_vsh, filename_fsh)

        if args.optgl:
            # Укажите опцию --processed, чтобы разруливать #include и прочий процессинг из ShaderPreprocessorGLSL.
            if filename_vsh:
                sp.optimize_glsl(filename_vsh, ShaderSourceType.Vertex, os.path.join(args.out_path or "", filename_vsh + ".opt"), None, args.processed)
            if filename_fsh:
                sp.optimize_glsl(filename_fsh, ShaderSourceType.Fragment, os.path.join(args.out_path or "", filename_fsh + ".opt"), None, args.processed)

    sp.finish()


if __name__ == '__main__':
    main()
