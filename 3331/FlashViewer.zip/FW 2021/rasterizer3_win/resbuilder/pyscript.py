#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
sys.dont_write_bytecode = True  # noqa: E402

import importlib
import platform
import x86cpu

if sys.version_info[0] != 3 or sys.version_info[1] < 7:
    raise Exception('Python 3.7+ is required')
if not sys.maxsize > 2**32:
    raise Exception('Python 64 bit is required')
if not x86cpu.info.supports_avx:
    raise Exception('CPU with AVX instuction set is required')

pyscript_suffix = {
    'Windows': '_win',
    'Darwin': '_macos',
    'Linux': '_linux'
}

pyscript_lib = importlib.import_module('pyscript' + str(sys.version_info[0]) + pyscript_suffix[platform.system()])

for key in dir(pyscript_lib):
    if not key.startswith("_"):
        globals()[key] = getattr(pyscript_lib, key)
