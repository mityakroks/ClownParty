#!/usr/bin/env python
# -*- coding: utf-8 -*-
import sys
sys.dont_write_bytecode = True  # noqa: E402

import os
import argparse
import logging
import glob

from lxml import etree
from lxml import objectify

import PIL.Image
import PIL.ImageDraw
import PIL.ImageFont
import PIL.ImageFilter
import PIL.ImageOps

SUPPORTED_PLATFORMS = ['ios', 'android', 'mac']


class IconsGeneratorStyles:
    def __init__(self, styles, input_path):
        self.font_name = os.path.join(input_path, styles.Font.attrib['name'])
        self.text_color = tuple([int(c) for c in styles.Font.attrib['textColor'].split()])
        self.stroke_color = tuple([int(c) for c in styles.Font.attrib['strokeColor'].split()])
        self.stroke_width = float(styles.Font.attrib['strokeWidth'])
        self.label_x = float(styles.Label.attrib['x'])
        self.label_y = float(styles.Label.attrib['y'])
        self.label_font_size = float(styles.Label.attrib['fontSize'])
        self.version_x = float(styles.Version.attrib['x'])
        self.version_y = float(styles.Version.attrib['y'])
        self.version_font_size = float(styles.Version.attrib['fontSize'])
        self.corner_radius = int(styles.Corner.attrib['radius'])


class IconsGenerator:
    def __init__(self, source_file, styles):
        self.source_file = source_file
        self.source_image = None
        self.styles = styles

    @staticmethod
    def _resize(img, size):
        return img.resize(size, resample=PIL.Image.BOX)

    def _adjust_source_image_size(self, size):
        if self.source_image.size != size:
            logging.warning(
                'Source image and applying image sizes not match - source image will be resized from %s to %s'
                % (str(self.source_image.size), str(size)))
            self.source_image = self._resize(self.source_image, size)

    @staticmethod
    def _draw_stroke_text(img, pos_x, pos_y, text, font, color, stroke_width, stroke_color):
        logging.debug('_draw_stroke_text %i %i' % (pos_x, pos_y))
        bg_color = list(stroke_color)
        if len(bg_color) < 4:
            bg_color.append(0)
        else:
            bg_color[3] = 0

        bg_color = tuple(bg_color)
        text_img = PIL.Image.new('RGBA', img.size, bg_color)

        draw = PIL.ImageDraw.Draw(text_img)
        draw.text((pos_x - stroke_width, pos_y - stroke_width), text, font=font, fill=stroke_color)
        draw.text((pos_x - stroke_width, pos_y + stroke_width), text, font=font, fill=stroke_color)
        draw.text((pos_x + stroke_width, pos_y - stroke_width), text, font=font, fill=stroke_color)
        draw.text((pos_x + stroke_width, pos_y + stroke_width), text, font=font, fill=stroke_color)

        text_img = text_img.filter(PIL.ImageFilter.GaussianBlur(2))

        draw = PIL.ImageDraw.Draw(text_img)
        draw.text((pos_x, pos_y), text, font=font, fill=color)

        return PIL.Image.alpha_composite(img, text_img)

    def apply_label_mark(self, label_txt):
        if label_txt == '':
            logging.debug('skipping apply_label_mark() because label mark is empty')
            return
        logging.debug('start apply_label_mark()')

        w, h = self.source_image.size
        font = PIL.ImageFont.truetype(self.styles.font_name, int(round(self.styles.label_font_size * h)))
        self.source_image = self._draw_stroke_text(
            self.source_image,
            round(self.styles.label_x * w), round(self.styles.label_y * h),
            label_txt, font, self.styles.text_color,
            round(self.styles.stroke_width * h), self.styles.stroke_color)

    def apply_version_mark(self, version_txt):
        if version_txt == '':
            logging.debug('skipping apply_version_mark() because version is empty')
            return
        logging.debug('start apply_version_mark()')

        w, h = self.source_image.size
        font = PIL.ImageFont.truetype(self.styles.font_name, int(round(self.styles.version_font_size * h)))
        self.source_image = self._draw_stroke_text(
            self.source_image,
            round(self.styles.version_x * w), round(self.styles.version_y * h),
            version_txt, font, self.styles.text_color,
            round(self.styles.stroke_width * h), self.styles.stroke_color)

    def apply_overlay_mark(self, overlay_file):
        if overlay_file == '':
            logging.debug('skipping apply_overlay_mark() because overlay_file is empty')
            return

        logging.debug('start apply_overlay_mark()')

        overlay_img = PIL.Image.open(overlay_file)
        self._adjust_source_image_size(overlay_img.size)
        self.source_image = PIL.Image.alpha_composite(self.source_image, overlay_img)

    def apply_mask(self):
        rad = self.styles.corner_radius
        circle = PIL.Image.new('L', (rad * 2, rad * 2), 0)
        draw = PIL.ImageDraw.Draw(circle)
        draw.ellipse((0, 0, rad * 2, rad * 2), fill=255)
        alpha = PIL.Image.new('L', self.source_image.size, "white")
        w, h = self.source_image.size
        alpha.paste(circle.crop((0, 0, rad, rad)), (0, 0))
        alpha.paste(circle.crop((0, rad, rad, rad * 2)), (0, h - rad))
        alpha.paste(circle.crop((rad, 0, rad * 2, rad)), (w - rad, 0))
        alpha.paste(circle.crop((rad, rad, rad * 2, rad * 2)), (w - rad, h - rad))
        self.source_image.putalpha(alpha)

    def remove_alpha(self):
        self.source_image = self.source_image.convert('RGB')

    def create_new_icon(self):
        logging.debug('start create_new_icon()')
        img = PIL.Image.open(self.source_file)

        if img.mode not in ['RGBA', 'RGB']:
            logging.error('Source image must have RGBA or RGB format')
            return

        if img.mode == 'RGB':
            img = img.convert('RGBA')

        self.source_image = img

    def _save_icon(self, output_file, size):
        logging.debug('save icon file=% size=%s' % (output_file, str(size)))

        if list(self.source_image.size)[0] < list(size)[0] or list(self.source_image.size)[1] < list(size)[1]:
            logging.warning(
                'Source image size is not optimal: original size is %s, enlarged to %s'
                % (str(self.source_image.size), str(size)))

        img = self._resize(self.source_image, size)
        if not os.path.isdir(os.path.dirname(output_file)):
            os.makedirs(os.path.dirname(output_file))
        img.save(output_file)

    def save_icons(self, icon_files, output_dir):
        logging.debug('start save_icons() output_dir=%s' % output_dir)
        for file in icon_files:
            output_file = os.path.join(output_dir, file['name'] + '.png')
            if 'size' in file:
                self._save_icon(output_file, (file['size'], file['size']))
            else:
                self._save_icon(output_file, (file['sizeX'], file['sizeY']))


# Удаляет файлы в указанной директории по маске
def remove_files_by_pattern(dir_path, pattern):
    for fl in glob.glob(os.path.join(dir_path, pattern)):
        os.remove(fl)


def make_icon(icon_gen, settings, version_mark):
    icon_gen.create_new_icon()
    if settings['overlay'] != '':
        icon_gen.apply_overlay_mark(settings['overlay'])
    if settings['mask']:
        icon_gen.apply_mask()
    if settings['label'] != '':
        icon_gen.apply_label_mark(settings['label'])
    if settings['version']:
        if version_mark:
            icon_gen.apply_version_mark(version_mark)
        else:
            error = 'version_mark is empty'
            logging.error(error)
            raise Exception(error)
    if not settings['alpha']:
        icon_gen.remove_alpha()


def generate(input_path, output_path, config_file=None, platforms=SUPPORTED_PLATFORMS, version_mark='', debug=False):

    # Configurate logging
    log_level = logging.DEBUG if debug else logging.INFO
    logging.basicConfig(format='[%(levelname)s]: %(message)s', handlers=[logging.StreamHandler()], level=log_level)
    logging.debug('Logging level now is ' + logging.getLevelName(log_level))

    script_dir = os.path.abspath(os.path.dirname(__file__))
    if not config_file:
        config_file = os.path.join(script_dir, 'icons_generator.xml')

    config_schema_file = os.path.join(script_dir, 'icons_generator.xsd')

    if version_mark:
        version_mark = version_mark.replace('.', '')

    logging.debug('using config file: {}'.format(config_file))
    logging.debug('using config schema file: {}'.format(config_schema_file))
    logging.debug('version mark: {}'.format(version_mark))

    schema = etree.XMLSchema(file=config_schema_file)
    parser = objectify.makeparser(remove_blank_text=True, schema=schema)
    config = objectify.parse(config_file, parser).getroot()

    styles = IconsGeneratorStyles(config.Styles, input_path)

    sources = {}
    for source in config.Sources.Source:
        source_path = os.path.join(input_path, source.attrib['path'])
        if not os.path.exists(source_path):
            error = 'source icon file {} not found'.format(source_path)
            logging.error(error)
            raise Exception(error)
        sources[source.attrib['name']] = source_path

    for group in config.Groups.Group:
        if group.attrib['platform'] not in platforms:
            continue
        source_path = sources[group.attrib['source']]
        icon_gen = IconsGenerator(source_path, styles)

        for file in group.Files.File:
            output_file = os.path.join(output_path, file.attrib['name'] + '.png')
            if os.path.exists(output_file):
                os.remove(output_file)

        for location in group.Locations.Location:
            locationDict = {}
            locationDict['label'] = location.attrib.get('label', '')
            locationDict['version'] = location.attrib.get('version', 'False') == 'True'
            locationDict['overlay'] = '' if 'overlay' not in location.attrib else sources[location.attrib['overlay']]
            locationDict['mask'] = location.attrib.get('mask', 'False') == 'True'
            locationDict['alpha'] = location.attrib.get('alpha', 'False') == 'True'
            make_icon(icon_gen, locationDict, version_mark)

            filesArray = []
            for file in group.Files.File:
                fileDict = {}
                fileDict['name'] = os.path.normpath(file.attrib['name'])
                size = file.attrib['size'].split(' ')
                if len(size) == 1:
                    fileDict['size'] = int(size[0])
                elif len(size) == 2:
                    fileDict['sizeX'] = int(size[0])
                    fileDict['sizeY'] = int(size[1])
                else:
                    logging.error('Too many file size components')
                    sys.exit(1)
                filesArray.append(fileDict)
            location_path = os.path.join(output_path, os.path.normpath(location.attrib['path']))
            if not os.path.isdir(location_path):
                os.makedirs(location_path)
            icon_gen.save_icons(filesArray, location_path)


if __name__ == '__main__':

    parser = argparse.ArgumentParser(description='Prepare game icons')

    parser.add_argument('-i', '--input-path',
                        required=True,
                        help='Input data directory')

    parser.add_argument('-o', '--output-path',
                        required=True,
                        help='Output base dir')

    parser.add_argument('-c', '--config-file',
                        default=None,
                        help='Config file absolute path, default internal file: icons_generator.xml')

    parser.add_argument('-v', '--version',
                        default=None,
                        help='Game version text')

    parser.add_argument('-p', '--platform',
                        nargs='+',
                        choices=SUPPORTED_PLATFORMS,
                        default=SUPPORTED_PLATFORMS,
                        help='Platform: ios, android, mac')

    parser.add_argument('-d', '--debug',
                        action='store_true',
                        help='Use debug output')

    args = parser.parse_args()

    try:
        generate(input_path=args.input_path,
                 output_path=args.output_path,
                 config_file=args.config_file,
                 platforms=args.platform,
                 version_mark=args.version,
                 debug=args.debug)
    except Exception as e:
        print(str(e))
        sys.exit(1)
